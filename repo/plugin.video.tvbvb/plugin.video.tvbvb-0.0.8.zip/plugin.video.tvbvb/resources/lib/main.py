# -*- coding: utf-8 -*-
import sys
import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin
from urllib.parse import parse_qs

from resources.lib.tvbvb import TvBvb
from resources.lib.logger import get_logger

class Main:
    def __init__(self):
        self.addon = xbmcaddon.Addon()
        self.handle = int(sys.argv[1])
        self.url = sys.argv[0]
        self.args = self._parse_args()
        self.logger = get_logger()

    def _parse_args(self):
        return parse_qs(sys.argv[2][1:])

    def get_arg(self, name):
        v = self.args.get(name)
        return v[0] if v else None

    def _notify(self, title: str, message: str, icon: int = xbmcgui.NOTIFICATION_INFO, time_ms: int = 3000):
        xbmcgui.Dialog().notification(title, message, icon, time_ms)

    def _filters(self) -> dict:
        return {
            'only_free': self.addon.getSetting("filter_paid") == "true",
            'show_paid_marker': self.addon.getSetting("show_paid_marker") == "true"
        }

    def run(self):
        self.logger.log_main("=== BVB TV Addon gestartet ===", "INFO")
        
        email = self.addon.getSetting("email")
        password = self.addon.getSetting("password")
        auto_login = self.addon.getSetting("auto_login") == "true"
        debug = self.addon.getSetting("debug_logging") == "true"
        
        self.logger.log_main(f"Einstellungen - Auto-Login: {auto_login}, Debug: {debug}")

        tvb = TvBvb(email or None, password or None, debug)

        if auto_login and email and password:
            self.logger.log_main("Versuche Auto-Login...")
            res = tvb.login()
            if res['success']:
                self._notify("BVB TV", "Automatisch angemeldet")
                self.logger.log_main("Auto-Login erfolgreich", "INFO")
            else:
                self.logger.log_main(f"Auto-Login fehlgeschlagen: {res['message']}", "WARNING")

        kind = self.get_arg('type')
        url_arg = self.get_arg('url')
        season = self.get_arg('season') == '2025-2026'

        self.logger.log_main(f"Navigation - Kind: {kind}, URL: {url_arg}, Season: {season}")

        xbmcplugin.setContent(self.handle, 'video')

        if not kind and not url_arg:
            self._menu()
        elif kind == 'season' and season:
            self._list_groups(tvb, True)
        elif kind == 'all_categories':
            self._list_groups(tvb, False)
        elif kind == 'group':
            self._list_videos(tvb, url_arg, season)
        elif kind == 'play':
            self._play(tvb, url_arg)
        elif kind == 'settings':
            self.addon.openSettings()

        xbmcplugin.addSortMethod(self.handle, xbmcplugin.SORT_METHOD_NONE)
        xbmcplugin.endOfDirectory(self.handle)

    def _menu(self):
        email = self.addon.getSetting("email")
        status = f"Angemeldet als: {email}" if email else "Nicht angemeldet"
        item = xbmcgui.ListItem(label=f"[COLOR yellow]{status}[/COLOR]")
        item.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(self.handle, f"{self.url}?type=settings", item, False)

        item = xbmcgui.ListItem(label="🏆 Saison 2025/2026")
        item.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(self.handle, f"{self.url}?type=season&season=2025-2026", item, True)

        item = xbmcgui.ListItem(label="⚙️ Einstellungen")
        item.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(self.handle, f"{self.url}?type=settings", item, False)

    def _list_groups(self, tvb: TvBvb, season: bool):
        groups = tvb.get_video_groups(use_current_season=season)
        if not groups:
            self._notify("BVB TV", "Keine Kategorien gefunden", xbmcgui.NOTIFICATION_WARNING)
            self.logger.log_main("Keine Video-Gruppen gefunden", "WARNING")
            return
            
        for g in groups:
            item = xbmcgui.ListItem(label=g)
            item.setProperty('IsPlayable', 'false')
            suffix = "&season=2025-2026" if season else ""
            xbmcplugin.addDirectoryItem(self.handle, f"{self.url}?type=group&url={g}{suffix}", item, True)

    def _list_videos(self, tvb: TvBvb, group: str, season: bool):
        vids = tvb.get_videos(group, filter_options=self._filters(), use_current_season=season)
        if not vids:
            self._notify("BVB TV", f"Keine Videos in '{group}' gefunden", xbmcgui.NOTIFICATION_WARNING)
            self.logger.log_main(f"Keine Videos in Gruppe '{group}' gefunden", "WARNING")
            return
            
        for v in vids:
            li = xbmcgui.ListItem(label=v['title'])
            li.setInfo('video', {'title': v['title'], 'plot': v['description'], 'genre': 'Sport'})
            if v['image']:
                li.setArt({'thumb': v['image'], 'icon': v['image'], 'fanart': v['image']})
            li.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(self.handle, f"{self.url}?type=play&url={v['url']}", li, False)

    def _play(self, tvb: TvBvb, url_arg: str):
        """Spielt Video ab - erst ohne Login, dann mit Login falls erforderlich"""
        self.logger.log_main(f"=== WIEDERGABE GESTARTET ===", "INFO")
        self.logger.log_main(f"Video URL: {url_arg}")

        # 1) Zuerst IMMER ohne Login versuchen
        self.logger.log_main("SCHRITT 1: Versuche Stream ohne Login...")
        stream = tvb.get_stream_without_auth(url_arg)
        
        if stream:
            self.logger.log_main("Stream ohne Login erfolgreich - starte Wiedergabe", "INFO")
            self._start_playback(stream)
            return
       
        # 3) Falls Anmeldedaten vorhanden, Login versuchen
        if tvb.email and tvb.password:
            self.logger.log_main("SCHRITT 3: Anmeldedaten vorhanden - versuche Login...")
            
            login_result = tvb.login()
            if login_result['success']:
                self.logger.log_main("Login erfolgreich - versuche Stream erneut", "INFO")
                stream = tvb.get_stream(url_arg)
                if stream:
                    self.logger.log_main("Stream nach Login erfolgreich gefunden", "INFO")
                    self._start_playback(stream)
                    return
                else:
                    self.logger.log_main("Auch nach Login kein Stream verfügbar", "ERROR")
            else:
                self.logger.log_main(f"Login fehlgeschlagen: {login_result['message']}", "ERROR")
                self._notify("BVB TV", f"Login fehlgeschlagen: {login_result['message']}", xbmcgui.NOTIFICATION_ERROR)
                return
        else:
            self.logger.log_main("SCHRITT 3: Keine Anmeldedaten verfügbar", "WARNING")

        # 4) Definitiv kein Stream verfügbar
        self.logger.log_main("=== WIEDERGABE FEHLGESCHLAGEN ===", "ERROR")
        self._notify("BVB TV", "Stream nicht verfügbar", xbmcgui.NOTIFICATION_ERROR)

    def _start_playback(self, stream_url: str):
        """Startet die Wiedergabe mit inputstreamhelper"""
        try:
            self.logger.log_main(f"=== STARTE WIEDERGABE ===", "INFO")
            self.logger.log_main(f"Stream URL: {stream_url[:100]}...")
            
            import inputstreamhelper
            
            # ListItem erstellen
            play_item = xbmcgui.ListItem(path=stream_url)
            
            # Inputstream Helper für HLS
            is_helper = inputstreamhelper.Helper('hls')
            if is_helper.check_inputstream():
                play_item.setProperty('inputstream', is_helper.inputstream_addon)
                play_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
                self.logger.log_main("Inputstream Helper aktiviert")
            else:
                self.logger.log_main("Inputstream Helper nicht verfügbar - Standard-Player", "WARNING")
            
            # Video-Properties setzen
            play_item.setProperty('IsPlayable', 'true')
            
            # Wiedergabe starten
            xbmcplugin.setResolvedUrl(self.handle, True, play_item)
            self.logger.log_main("=== WIEDERGABE GESTARTET ===", "INFO")
            
        except Exception as e:
            self.logger.log_error("Fehler bei der Wiedergabe", e)
            self._notify("BVB TV", f"Wiedergabe-Fehler: {str(e)}", xbmcgui.NOTIFICATION_ERROR)
            
            # Fallback: Fehlgeschlagene Wiedergabe signalisieren
            xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
