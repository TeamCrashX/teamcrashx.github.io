# -*- coding: utf-8 -*-
from typing import TypedDict, Optional

class Config(TypedDict, total=False):
    addon_url: str
    addon_handle: int
    addon_args: dict[str, list[str]]
    thumbnail_resolution: int
    debug_enabled: bool
    session_timeout: int
