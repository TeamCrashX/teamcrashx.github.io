# -*- coding: utf-8 -*-
import requests
import time
from bs4 import BeautifulSoup
from xml.etree import ElementTree
from typing import TypedDict, List, Optional, Dict
import re
import xbmc

# Logging System
from resources.lib.logger import get_logger

# Import des Auth-Moduls
try:
    from resources.lib.authbvb import BVBAuth, BVBAuthError
except ImportError:
    BVBAuth = None
    BVBAuthError = Exception

class Video(TypedDict):
    title: str
    description: str
    paid: bool
    image: str
    url: str

class LoginResult(TypedDict):
    success: bool
    message: str

class TvBvb:
    URL_ROOT = 'https://tv.bvb.de'
    URL_VIDEOS = 'https://tv.bvb.de/de/'
    URL_VIDEOS_2025_2026 = 'https://tv.bvb.de/de/videos/2025-2026/'

    def __init__(self, email: Optional[str]=None, password: Optional[str]=None, debug: bool=False):
        self.email = email
        self.password = password
        self.debug = debug
        self.logger = get_logger()
        
        # Standard Session für öffentliche Inhalte
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        })
        
        # BVB Auth (nur bei Bedarf)
        self.bvb_auth: Optional[BVBAuth] = None
        self.logged_in = False
        
        self.logger.log(f"TvBvb initialisiert - Email: {bool(email)}, Password: {bool(password)}", "INFO")

    def _log(self, msg: str, level: str = "DEBUG"):
        """Wrapper für Logger"""
        self.logger.log(msg, level, "TVBVB")

    def _is_video_url(self, url: str) -> bool:
        """Prüft ob URL eine direkte Video-URL ist"""
        try:
            self.logger.log_request(url, "GET")
            response = self.session.get(url, timeout=15)
            self.logger.log_request(url, "GET", response.status_code)
            
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Suche nach Video-Player Elementen
            video_indicators = [
                soup.find('div', class_='videoPlayerLoader'),
                soup.find('video'),
                soup.find('div', {'id': 'video-player'}),
                soup.find('iframe', src=re.compile(r'player|video', re.I)),
                soup.find('script', text=re.compile(r'videoPlayer|streamData', re.I))
            ]
            
            has_video = any(indicator for indicator in video_indicators)
            
            # Zusätzlich: Prüfe auf Abo-Hinweise (zeigt an, dass es Video-Content gibt)
            abo_hints = [
                'BVB-TV abo', 'Jetzt BVB-TV Abo', 'kostenpflichtig', 'premium'
            ]
            has_premium_content = any(hint in response.text for hint in abo_hints)
            
            is_video = has_video or has_premium_content
            
            self.logger.log_stream(f"URL-Check: {url} -> Video: {has_video}, Premium: {has_premium_content}, Result: {is_video}")
            
            return is_video
            
        except Exception as e:
            self.logger.log_error(f"Fehler bei Video-URL-Check: {url}", e)
            # Bei Fehlern konservativ annehmen, dass es sich um Video handelt
            return True

    def _extract_videos_from_category(self, url: str) -> List[Video]:
        """Extrahiert Videos aus einer Kategorie-Seite"""
        try:
            self.logger.log_stream(f"Extrahiere Videos aus Kategorie: {url}")
            
            response = self.session.get(url, timeout=30)
            soup = BeautifulSoup(response.text, 'html.parser')
            
            videos: List[Video] = []
            
            # Suche nach Video-Links in der Kategorie
            video_links = soup.find_all('a', href=re.compile(r'/videos?/.*'))
            
            for link in video_links:
                try:
                    href = link.get('href')
                    if not href:
                        continue
                        
                    # Vollständige URL bilden
                    if href.startswith('/'):
                        video_url = self.URL_ROOT + href
                    else:
                        video_url = href
                    
                    # Titel extrahieren
                    title_elem = link.find(['strong', 'h3', 'h4']) or link
                    title = title_elem.get_text(strip=True) if title_elem else "Unbekannter Titel"
                    
                    # Beschreibung suchen
                    desc_elem = link.find_next(['p', 'div'], class_=['desc', 'description'])
                    description = desc_elem.get_text(strip=True) if desc_elem else ""
                    
                    # Bild suchen
                    img_elem = link.find('img') or link.find_next('img')
                    image = ""
                    if img_elem:
                        image = img_elem.get('data-src') or img_elem.get('src') or ""
                        if image and image.startswith('/'):
                            image = self.URL_ROOT + image
                    
                    # Premium-Status (konservativ annehmen)
                    paid = True  # Kategorie-Videos sind meist Premium
                    
                    videos.append(Video(
                        title=title,
                        description=description,
                        paid=paid,
                        image=image,
                        url=video_url
                    ))
                    
                except Exception as e:
                    self.logger.log_error(f"Fehler beim Extrahieren einzelner Video-Info", e)
                    continue
            
            self.logger.log_stream(f"Aus Kategorie extrahiert: {len(videos)} Videos")
            return videos
            
        except Exception as e:
            self.logger.log_error(f"Fehler beim Extrahieren aus Kategorie: {url}", e)
            return []

    def _get_authenticated_session(self) -> requests.Session:
        """Sichere Methode um authentifizierte Session zu bekommen"""
        if self.bvb_auth and self.bvb_auth.is_logged_in():
            try:
                return self.bvb_auth.get_authenticated_session()
            except Exception as e:
                self.logger.log_auth(f"Fehler beim Abrufen der Auth-Session: {e}", "WARNING")
        return self.session

    def login(self, force_relogin: bool = False) -> LoginResult:
        """Login mit BVB Auth"""
        if not self.email or not self.password:
            return LoginResult(success=False, message="E-Mail und Passwort erforderlich")
        
        self.logger.log_auth(f"Login-Versuch - Force: {force_relogin}")
        
        # BVB Auth erstellen falls nicht vorhanden
        if not self.bvb_auth and BVBAuth:
            self.logger.log_auth("Erstelle BVB Auth Instanz")
            self.bvb_auth = BVBAuth(self.email, self.password, self.debug)
        
        if not self.bvb_auth:
            return LoginResult(success=False, message="BVB Auth nicht verfügbar")
        
        try:
            result = self.bvb_auth.login(force_relogin)
            
            if result['success']:
                self.logged_in = True
                self.logger.log_auth("Login erfolgreich - Session aktiv", "INFO")
            else:
                self.logged_in = False
                self.logger.log_auth(f"Login fehlgeschlagen: {result['message']}", "ERROR")
            
            return LoginResult(success=result['success'], message=result['message'])
            
        except Exception as e:
            self.logger.log_error(f"Login-Fehler in TvBvb", e)
            return LoginResult(success=False, message=f"Login-Fehler: {str(e)}")

    def is_logged_in(self) -> bool:
        """Login-Status prüfen"""
        if self.bvb_auth:
            status = self.bvb_auth.is_logged_in()
            self.logged_in = status
            self.logger.log_auth(f"Login-Status: {status}")
            return status
        return False

    def get_stream_without_auth(self, url: str) -> Optional[str]:
        """Stream OHNE Authentifizierung laden (für kostenlose Videos)"""
        try:
            self.logger.log_stream(f"Versuche Stream ohne Auth: {url}")
            
            # Prüfe ob es eine direkte Video-URL ist
            if not self._is_video_url(url):
                self.logger.log_stream("URL ist keine Video-URL - extrahiere Videos aus Kategorie")
                videos = self._extract_videos_from_category(url)
                if videos:
                    # Nimm das erste Video
                    first_video = videos[0]
                    self.logger.log_stream(f"Verwende erstes Video aus Kategorie: {first_video['title']}")
                    return self.get_stream_without_auth(first_video['url'])
                else:
                    self.logger.log_stream("Keine Videos in Kategorie gefunden")
                    return None
            
            # Standard Stream-Extraktion
            r = self.session.get(url, timeout=30)
            soup = BeautifulSoup(r.text, 'html.parser')
            
            loader = soup.find('div', class_='videoPlayerLoader')
            if not loader:
                self.logger.log_stream("Kein videoPlayerLoader gefunden")
                return None
                
            ajax_url = f"{self.URL_ROOT}{loader['data-ajaxurl']}"
            ajax_data = {'pageId': loader['data-page'], 'videoId': loader['data-video']}
            
            self.logger.log_stream(f"AJAX-Request (ohne Auth): {ajax_url}")
            ajax_resp = self.session.post(ajax_url, data=ajax_data, timeout=30)
            data = ajax_resp.json()
            
            stream_url = self._extract_stream_from_data(data, self.session)
            
            if stream_url:
                self.logger.log_stream("Stream ohne Auth erfolgreich extrahiert", "INFO")
            else:
                self.logger.log_stream("Stream-Extraktion ohne Auth fehlgeschlagen")
            
            return stream_url
            
        except Exception as e:
            self.logger.log_error("Fehler bei Stream ohne Auth", e)
            return None

    def get_stream(self, url: str) -> Optional[str]:
        """Stream MIT Authentifizierung laden (für Premium-Videos)"""
        try:
            self.logger.log_stream(f"Versuche Stream mit Auth: {url}")
            
            # Prüfe ob es eine direkte Video-URL ist
            if not self._is_video_url(url):
                self.logger.log_stream("URL ist keine Video-URL - extrahiere Videos aus Kategorie")
                videos = self._extract_videos_from_category(url)
                if videos:
                    first_video = videos[0]
                    self.logger.log_stream(f"Verwende erstes Video aus Kategorie: {first_video['title']}")
                    return self.get_stream(first_video['url'])
                else:
                    self.logger.log_stream("Keine Videos in Kategorie gefunden")
                    return None
            
            # Authentifizierte Session verwenden
            session = self._get_authenticated_session()
            
            r = session.get(url, timeout=30)
            soup = BeautifulSoup(r.text, 'html.parser')
            
            loader = soup.find('div', class_='videoPlayerLoader')
            if not loader:
                self.logger.log_stream("Kein videoPlayerLoader gefunden (mit Auth)")
                return None
                
            ajax_url = f"{self.URL_ROOT}{loader['data-ajaxurl']}"
            ajax_data = {'pageId': loader['data-page'], 'videoId': loader['data-video']}
            
            self.logger.log_stream(f"AJAX-Request (mit Auth): {ajax_url}")
            ajax_resp = session.post(ajax_url, data=ajax_data, timeout=30)
            data = ajax_resp.json()
            
            stream_url = self._extract_stream_from_data(data, session)
            
            if stream_url:
                self.logger.log_stream("Stream mit Auth erfolgreich extrahiert", "INFO")
            else:
                self.logger.log_stream("Stream-Extraktion mit Auth fehlgeschlagen")
            
            return stream_url
            
        except Exception as e:
            self.logger.log_error("Fehler bei Stream mit Auth", e)
            return None

    def _extract_stream_from_data(self, data: dict, session: requests.Session) -> Optional[str]:
        """Extrahiert Stream-URL aus AJAX-Daten"""
        try:
            part_0 = ""
            params: List[str] = []
            
            html_content = data.get('html', '')
            self.logger.log_stream(f"HTML-Content Länge: {len(html_content)} Zeichen")
            
            for line in html_content.split('\n'):
                m1 = re.match(r'^\s*(configUrl)\s*\+=\s*"(.*)"', line)
                if m1 and m1.group(2).startswith('fa'):
                    part_0 = m1.group(2)
                    self.logger.log_stream(f"ConfigUrl gefunden: {part_0[:20]}...")
                    
                m2 = re.match(r'^\s*(videoid|partnerid|language):\s*"(.*)"', line)
                if m2:
                    param = f"{m2.group(1)}={m2.group(2)}"
                    params.append(param)
                    self.logger.log_stream(f"Parameter gefunden: {param}")
            
            if not part_0:
                self.logger.log_stream("Keine Stream-Konfiguration gefunden", "WARNING")
                return None
                
            url_sd = f"{self.URL_ROOT}/videoPlayer/streamData.php?{part_0}&{'&'.join(params)}&format=iphone&device=desktop"
            self.logger.log_stream(f"StreamData URL: {url_sd}")
            
            sd_resp = session.get(url_sd, timeout=30)
            sd = sd_resp.json()
            
            if 'streamAccess' not in sd:
                self.logger.log_stream("Keine streamAccess in Response", "WARNING")
                return None
                
            sa_url = f"https:{sd['streamAccess']}"
            sa_resp = session.get(sa_url, timeout=30)
            sa = sa_resp.json()
            
            stream_access_list = sa.get('data', {}).get('stream-access', [])
            self.logger.log_stream(f"Stream-Access URLs gefunden: {len(stream_access_list)}")
            
            for i, p in enumerate(stream_access_list):
                try:
                    stream_xml_url = f"https:{p}"
                    self.logger.log_stream(f"Teste Stream {i+1}/{len(stream_access_list)}: {stream_xml_url}")
                    
                    xml_resp = session.get(stream_xml_url, timeout=15)
                    root = ElementTree.fromstring(xml_resp.content)
                    
                    for node in root:
                        if node.tag == 'token':
                            stream_url = f"{node.attrib['url']}?hdnea={node.attrib['auth']}"
                            self.logger.log_stream(f"Stream-URL erfolgreich extrahiert: {stream_url[:50]}...", "INFO")
                            return stream_url
                            
                except Exception as e:
                    self.logger.log_stream(f"Fehler bei Stream {i+1}: {e}")
                    continue
                    
            self.logger.log_stream("Keine gültigen Streams in stream-access gefunden", "WARNING")
            return None
            
        except Exception as e:
            self.logger.log_error("Fehler bei Stream-Extraktion", e)
            return None

    def requires_login_for_video(self, video_url: str) -> bool:
        """Prüft ob Video Login benötigt (deprecated)"""
        return False

    # Restliche Methoden bleiben unverändert...
    def get_video_groups(self, use_current_season: bool = False) -> List[str]:
        url = self.URL_VIDEOS_2025_2026 if use_current_season else self.URL_VIDEOS
        try:
            r = self.session.get(url, timeout=30)
            soup = BeautifulSoup(r.text, 'html.parser')
            groups: List[str] = []
            for lane in soup.find_all('section', {'class': 'video-lane'}):
                h2 = lane.find('h2')
                if h2 and h2.text.strip():
                    groups.append(h2.text.strip())
            self.logger.log(f"Video-Gruppen geladen: {len(groups)}")
            return groups
        except Exception as e:
            self.logger.log_error("Fehler beim Laden der Gruppen", e)
            return []

    def get_videos(self, video_group: str, filter_options: Dict = None, page: int = 1, use_current_season: bool = False) -> List[Video]:
        if filter_options is None:
            filter_options = {}
        
        only_free = filter_options.get('only_free', False)
        show_paid_marker = filter_options.get('show_paid_marker', True)
        url = self.URL_VIDEOS_2025_2026 if use_current_season else self.URL_VIDEOS
        
        self.logger.log(f"Lade Videos für Gruppe: {video_group}")
        
        try:
            r = self.session.get(url, timeout=30)
            soup = BeautifulSoup(r.text, 'html.parser')
            vids: List[Video] = []
            
            for lane in soup.find_all('section', {'class': 'video-lane'}):
                h2 = lane.find('h2')
                if not (h2 and h2.text.strip() == video_group):
                    continue
                
                slider = lane.find('div', {'class': 'video-lane-slider'})
                if slider and slider.get('data-contelpage') and slider.get('data-loadurl'):
                    vids.extend(self._load_ajax(slider, page, only_free, show_paid_marker))
                else:
                    vids.extend(self._parse_static(lane, only_free, show_paid_marker))
                break
            
            self.logger.log(f"Videos geladen für '{video_group}': {len(vids)}")
            return vids
            
        except Exception as e:
            self.logger.log_error(f"Fehler beim Laden der Videos für {video_group}", e)
            return []

    def _load_ajax(self, slider, page: int, only_free: bool, show_paid_marker: bool) -> List[Video]:
        try:
            contel_page = slider['data-contelpage']
            ajax_url = f"{self.URL_ROOT}{slider['data-loadurl']}"
            resp = self.session.post(ajax_url, data={
                'contelPageId': contel_page,
                'teaserIndex': 12 * page,
                'teaserLoaded': '{}',
                'preDefinedIndex': page
            }, timeout=30)
            js = resp.json()
            out: List[Video] = []
            for html in js.get('teaserHtmls', []):
                v = self._parse_video_html(html, only_free, show_paid_marker)
                if v:
                    out.append(v)
            return out
        except Exception as e:
            self.logger.log_error("AJAX-Fehler", e)
            return []

    def _parse_video_html(self, html: str, only_free: bool, show_paid_marker: bool) -> Optional[Video]:
        try:
            soup = BeautifulSoup(html, 'html.parser')
            art = soup.find('article')
            access_attr = art.get('data-access', '1') if art else '1'
            paid = bool(int(access_attr)) if access_attr.isdigit() else True
            if only_free and paid:
                return None
            t = soup.find('strong', class_='title')
            d = soup.find('p', class_='desc')
            i = soup.find('img', class_='teaser')
            a = soup.find('a', class_='teaserlink')
            if not (t and a):
                return None
            title = t.text.strip()
            if paid and show_paid_marker:
                title = f"€ {title}"
            return Video(
                paid=paid,
                title=title,
                description=d.text.strip() if d else '',
                image=i.get('data-src', i.get('src', '')) if i else '',
                url=f"{self.URL_ROOT}{a.get('data-href', a.get('href', ''))}"
            )
        except:
            return None

    def _parse_static(self, lane, only_free: bool, show_paid_marker: bool) -> List[Video]:
        out: List[Video] = []
        for art in lane.find_all('article'):
            try:
                access_attr = art.get('data-access', '1')
                paid = bool(int(access_attr)) if access_attr.isdigit() else True
                if only_free and paid:
                    continue
                t = art.find(['strong', 'h3'])
                a = art.find('a')
                if not (t and a):
                    continue
                title = t.text.strip()
                if paid and show_paid_marker:
                    title = f"€ {title}"
                d = art.find(['p', 'div'], class_=['desc', 'description'])
                i = art.find('img')
                out.append(Video(
                    paid=paid,
                    title=title,
                    description=d.text.strip() if d else '',
                    image=i.get('data-src', i.get('src', '')) if i else '',
                    url=f"{self.URL_ROOT}{a.get('href', a.get('data-href', ''))}"
                ))
            except:
                continue
        return out
