# -*- coding: utf-8 -*-
"""
Spezialisiertes BVB Account Login-Modul für https://account.bvb.de/
"""

import requests
import time
import hashlib
import os
from bs4 import BeautifulSoup
from typing import Optional, Dict, Any, Tuple
import re
import json
import xbmc
import xbmcvfs
import xbmcaddon

class BVBAuthError(Exception):
    """Custom Exception für BVB Authentication Fehler"""
    pass

class BVBAuth:
    """Spezialisierte BVB Account Authentifizierung"""
    
    # BVB Account URLs - korrigiert
    LOGIN_URL = "https://account.bvb.de/s/login/"
    BASE_URL = "https://account.bvb.de/"
    TV_URL = "https://tv.bvb.de/"
    
    def __init__(self, email: str, password: str, debug: bool = False):
        self.email = email
        self.password = password
        self.debug = debug
        
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'de-DE,de;q=0.9,en;q=0.8',
            'Referer': 'https://tv.bvb.de/'
        })
        
        self.logged_in = False
        self.login_time: Optional[float] = None
        self.session_timeout = 7200
        self.user_info: Dict[str, Any] = {}

    def _log(self, message: str, level: int = xbmc.LOGDEBUG):
        if self.debug or level > xbmc.LOGDEBUG:
            xbmc.log(f"[BVB Auth] {message}", level)

    def _get_login_form_data(self) -> Tuple[str, Dict[str, str]]:
        """Vereinfachte Login-Form Extraktion"""
        self._log("Lade Login-Seite...")
        
        try:
            # Erst BVB TV besuchen um Cookies zu setzen
            self.session.get(self.TV_URL, timeout=20)
            
            # Dann Login-Seite
            response = self.session.get(self.LOGIN_URL, timeout=20)
            
            if response.status_code != 200:
                raise BVBAuthError(f"Login-Seite nicht erreichbar: {response.status_code}")
            
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Verschiedene Form-Selektoren versuchen
            form_selectors = [
                'form[action*="login"]',
                'form#login',
                'form.login',
                'form[method="post"]',
                'form'
            ]
            
            login_form = None
            for selector in form_selectors:
                login_form = soup.select_one(selector)
                if login_form:
                    self._log(f"Login-Form gefunden mit Selector: {selector}")
                    break
            
            if not login_form:
                self._log("Kein Login-Formular gefunden - verwende Standard-Login")
                return self.LOGIN_URL, {
                    'email': self.email,
                    'password': self.password
                }
            
            # Form Action
            action_url = login_form.get('action', self.LOGIN_URL)
            if action_url.startswith('/'):
                action_url = self.BASE_URL.rstrip('/') + action_url
            
            # Form-Daten sammeln
            form_data = {
                'email': self.email,
                'password': self.password
            }
            
            # Hidden Fields
            for hidden in login_form.find_all('input', {'type': 'hidden'}):
                name = hidden.get('name')
                value = hidden.get('value')
                if name and value:
                    form_data[name] = value
                    self._log(f"Hidden field: {name} = {value[:10]}...")
            
            # CSRF Token aus Meta Tags
            csrf_meta = soup.find('meta', {'name': 'csrf-token'})
            if csrf_meta:
                form_data['csrf_token'] = csrf_meta.get('content')
            
            return action_url, form_data
            
        except Exception as e:
            self._log(f"Fehler beim Laden der Login-Form: {e}", xbmc.LOGWARNING)
            # Fallback
            return self.LOGIN_URL, {
                'email': self.email,
                'password': self.password
            }

    def login(self, force_relogin: bool = False) -> Dict[str, Any]:
        """Vereinfachter BVB Login"""
        if not self.email or not self.password:
            return {'success': False, 'message': 'E-Mail und Passwort erforderlich'}
        
        if self.logged_in and not force_relogin:
            if self._verify_login():
                return {'success': True, 'message': 'Bereits angemeldet'}
        
        try:
            self._log("Starte BVB Login...")
            
            # Login-Form Daten laden
            action_url, form_data = self._get_login_form_data()
            
            self._log(f"Login an: {action_url}")
            self._log(f"Form-Felder: {list(form_data.keys())}")
            
            # Login-Request
            login_response = self.session.post(
                action_url,
                data=form_data,
                timeout=30,
                allow_redirects=True
            )
            
            # Login-Erfolg prüfen
            if self._verify_login_response(login_response):
                self.logged_in = True
                self.login_time = time.time()
                self._log("BVB Login erfolgreich!")
                return {'success': True, 'message': 'Login erfolgreich'}
            else:
                self._log("BVB Login fehlgeschlagen")
                return {'success': False, 'message': 'Login fehlgeschlagen - Bitte Zugangsdaten prüfen'}
                
        except Exception as e:
            self._log(f"Login-Fehler: {e}", xbmc.LOGERROR)
            return {'success': False, 'message': f'Login-Fehler: {str(e)}'}

    def _verify_login_response(self, response: requests.Response) -> bool:
        """Vereinfachte Login-Verifikation"""
        try:
            response_text = response.text.lower()
            
            # Erfolg-Indikatoren
            success_patterns = [
                'dashboard', 'profil', 'willkommen', 'welcome',
                'logout', 'abmelden', 'mitglied', 'member',
                'premium', 'abo'
            ]
            
            # Fehler-Indikatoren
            error_patterns = [
                'error', 'fehler', 'invalid', 'ungültig',
                'wrong', 'falsch', 'incorrect'
            ]
            
            has_success = any(pattern in response_text for pattern in success_patterns)
            has_error = any(pattern in response_text for pattern in error_patterns)
            
            # URL-Check
            good_url = any(domain in response.url for domain in ['account.bvb.de', 'tv.bvb.de'])
            
            # Cookie-Check
            has_cookies = len(self.session.cookies) > 2
            
            result = (has_success and not has_error) or good_url or has_cookies
            
            self._log(f"Login-Verifikation: Success={has_success}, Error={has_error}, URL={good_url}, Cookies={has_cookies} -> {result}")
            
            return result
            
        except Exception as e:
            self._log(f"Fehler bei Login-Verifikation: {e}")
            return False

    def _verify_login(self) -> bool:
        """Session-Verifikation"""
        try:
            if not self.login_time or (time.time() - self.login_time) > self.session_timeout:
                return False
                
            # Quick check
            test_response = self.session.get(self.TV_URL, timeout=10)
            text = test_response.text.lower()
            
            indicators = ['logout', 'abmelden', 'premium', 'mitglied']
            return any(ind in text for ind in indicators)
            
        except:
            return False

    def is_logged_in(self) -> bool:
        """Login-Status prüfen"""
        return self.logged_in and self._verify_login()

    def get_authenticated_session(self) -> requests.Session:
        """Authentifizierte Session zurückgeben"""
        if not self.is_logged_in():
            raise BVBAuthError("Nicht angemeldet")
        return self.session

    def logout(self):
        """Logout"""
        try:
            self.session.get(f"{self.BASE_URL}logout/", timeout=10)
        except:
            pass
        
        self.session.cookies.clear()
        self.logged_in = False
        self.login_time = None
