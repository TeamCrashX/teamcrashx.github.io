# -*- coding: utf-8 -*-
"""
BVB TV Addon Logging System
Erstellt separate bvb.log Datei für detailliertes Debugging
"""

import os
import time
import threading
from typing import Optional
import xbmc
import xbmcvfs
import xbmcaddon

class BVBLogger:
    """Separate BVB TV Log-Datei System"""
    
    def __init__(self):
        self.addon = xbmcaddon.Addon('plugin.video.tvbvb')
        
        # Log-Datei Pfad
        log_dir = xbmcvfs.translatePath('special://logpath/')
        self.log_file = os.path.join(log_dir, 'bvb.log')
        
        # Thread-Lock für gleichzeitiges Schreiben
        self._lock = threading.Lock()
        
        # Log-Level
        self.debug_enabled = self.addon.getSetting("debug_logging") == "true"
        
        # Initialer Log-Eintrag
        self.log("BVB TV Logger initialisiert", level="INFO")
        self.log(f"Log-Datei: {self.log_file}", level="INFO")

    def _get_timestamp(self) -> str:
        """Erstellt Zeitstempel für Log-Einträge"""
        return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())

    def _write_to_file(self, message: str):
        """Thread-sicheres Schreiben in Log-Datei"""
        try:
            with self._lock:
                with open(self.log_file, 'a', encoding='utf-8') as f:
                    f.write(f"{message}\n")
                    f.flush()
        except Exception as e:
            # Fallback auf Kodi-Log bei Dateifehler
            xbmc.log(f"[BVB TV Logger] Fehler beim Schreiben in Log-Datei: {e}", xbmc.LOGERROR)

    def log(self, message: str, level: str = "DEBUG", component: Optional[str] = None):
        """
        Hauptlogging-Methode
        
        Args:
            message: Log-Nachricht
            level: Log-Level (DEBUG, INFO, WARNING, ERROR)
            component: Komponente (z.B. "AUTH", "STREAM", "MAIN")
        """
        timestamp = self._get_timestamp()
        
        # Component-Prefix
        comp_prefix = f"[{component}] " if component else ""
        
        # Formatierte Nachricht
        formatted_msg = f"{timestamp} [{level}] {comp_prefix}{message}"
        
        # In Datei schreiben
        self._write_to_file(formatted_msg)
        
        # Auch an Kodi-Log senden (basierend auf Level)
        kodi_level = xbmc.LOGDEBUG
        if level == "INFO":
            kodi_level = xbmc.LOGINFO
        elif level == "WARNING":
            kodi_level = xbmc.LOGWARNING
        elif level == "ERROR":
            kodi_level = xbmc.LOGERROR
            
        if self.debug_enabled or kodi_level > xbmc.LOGDEBUG:
            xbmc.log(f"[BVB TV] {comp_prefix}{message}", kodi_level)

    def log_auth(self, message: str, level: str = "DEBUG"):
        """Authentifizierungs-spezifisches Logging"""
        self.log(message, level, "AUTH")

    def log_stream(self, message: str, level: str = "DEBUG"):
        """Stream-spezifisches Logging"""
        self.log(message, level, "STREAM")

    def log_main(self, message: str, level: str = "DEBUG"):
        """Main-Navigation spezifisches Logging"""
        self.log(message, level, "MAIN")

    def log_error(self, message: str, exception: Optional[Exception] = None):
        """Fehler-Logging mit Exception-Details"""
        error_msg = message
        if exception:
            error_msg += f" - Exception: {str(exception)}"
        self.log(error_msg, "ERROR")

    def log_request(self, url: str, method: str = "GET", status_code: Optional[int] = None):
        """HTTP-Request Logging"""
        msg = f"{method} {url}"
        if status_code:
            msg += f" -> {status_code}"
        self.log(msg, "DEBUG", "HTTP")

    def clear_log(self):
        """Löscht die Log-Datei"""
        try:
            if os.path.exists(self.log_file):
                os.remove(self.log_file)
                self.log("Log-Datei gelöscht", "INFO")
        except Exception as e:
            self.log(f"Fehler beim Löschen der Log-Datei: {e}", "ERROR")

# Global Logger Instance
_logger_instance: Optional[BVBLogger] = None

def get_logger() -> BVBLogger:
    """Singleton Logger Instance"""
    global _logger_instance
    if _logger_instance is None:
        _logger_instance = BVBLogger()
    return _logger_instance
