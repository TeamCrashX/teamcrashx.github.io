# -*- coding: utf-8 -*-

"""Service entry point"""

if __name__ == '__main__':
    from lib.restart_pvr import run
    run()