# Welcome to your addon by Eragon

# German

MBI 2.0 dient als zentraler Installer und Manager für Builds, die als Bundles über Kurzlink-Hoster bereitgestellt werden.

Der Nutzer kann Bundle-URLs aus unterstützten Kurzlink-Hostern im Addon hinterlegen und diese jeweils mit einer kurzen Beschreibung versehen. Diese Informationen werden lokal gespeichert, sodass die Builds jederzeit erneut installiert oder verwaltet werden können.

Die Builds selbst sind systemunabhängig. Während der Installation erkennt MBI 2.0 automatisch die Systemarchitektur (32 Bit oder 64 Bit) und installiert nach Abschluss des Builds die jeweils passenden Abhängigkeiten. Dadurch ist sichergestellt, dass der Build auf dem verwendeten System korrekt und vollständig funktioniert.

Zusätzlich zur Installation über Bundle-URLs können Builds auch lokal installiert werden. In diesem Fall wird ein bereits vorhandenes Build-Archiv oder Verzeichnis ausgewählt und über MBI 2.0 eingebunden und eingerichtet.

MBI 2.0 verändert keine systemkritischen Einstellungen und führt alle Installationsschritte kontrolliert und nachvollziehbar aus. Abhängigkeiten werden ausschließlich dann installiert, wenn sie für den jeweiligen Build erforderlich sind.

## Lizenz

Dieses Addon ist **nur für den privaten Gebrauch** bestimmt.  
Weitergabe, Rebranding oder kommerzielle Nutzung nur nach Absprache.

---

## Viel Spaß mit MBI 2.0!

Wenn dir das Addon gefällt, teile es gern oder hinterlasse Feedback.  
Weitere Updates und Erweiterungen sind geplant.




## Englisch

MBI 2.0 acts as a central installer and manager for builds distributed as bundles via shortlink hosting services.

Users can add bundle URLs from supported shortlink hosters directly into the addon and assign a short description to each build. These entries are stored locally, allowing builds to be installed again or managed at any time.

The builds themselves are system-independent. During installation, MBI 2.0 automatically detects the system architecture (32-bit or 64-bit) and installs the required dependencies after the build installation is completed. This ensures that each build runs correctly on the current system.

In addition to installing builds from bundle URLs, MBI 2.0 also supports local installations. Existing build archives or directories can be selected and installed directly through the addon.

MBI 2.0 does not modify critical system settings. All installation steps are executed in a controlled manner, and dependencies are only installed when they are required for the selected build.


## License

This addon is intended **for private use only**.  
Redistribution, rebranding, or commercial use is only permitted with prior permission.

---

## Enjoy MBI 2.0!

If you like the addon, feel free to share it or leave feedback.  
Further updates and enhancements are planned.





