# -*- coding: utf-8 -*-
import xbmc
import xbmcaddon
import time

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")

xbmc.log("[MBI 2.0 Service] Service gestartet.", xbmc.LOGDEBUG)

def run():
    monitor = xbmc.Monitor()

    # Kodi hochfahren lassen
    if monitor.waitForAbort(8):
        return

    # First-Run: Quick Install automatisch starten (nur einmal)
    try:
        if ADDON.getSetting("firstrun") != "done":
            xbmc.log("[MBI 2.0 Service] First-Run erkannt – starte Quick Install.", xbmc.LOGDEBUG)
            # Marker sofort setzen, damit es nicht bei jedem Start erneut läuft
            ADDON.setSetting("firstrun", "done")
            xbmc.executebuiltin(f"RunPlugin(plugin://{ADDON_ID}/?action=quick_install)")
            # kurzer Puffer, damit GUI starten kann
            xbmc.sleep(1000)
    except Exception as e:
        xbmc.log(f"[MBI 2.0 Service] First-Run Quick Install Fehler: {e}", xbmc.LOGERROR)

    # Binary-Restore (WORKING-Logik)
    try:
        from core import restore_binary
        restore_binary()
        xbmc.log("[MBI 2.0 Service] Binary-Restore ausgeführt.", xbmc.LOGDEBUG)
    except Exception as e:
        xbmc.log(f"[MBI 2.0 Service] restore_binary Fehler: {e}", xbmc.LOGERROR)

if __name__ == "__main__":
    run()
