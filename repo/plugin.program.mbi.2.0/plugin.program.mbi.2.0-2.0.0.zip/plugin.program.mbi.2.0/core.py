# -*- coding: utf-8 -*-
import os
import sys
import json
import shutil
import sqlite3
import glob
from datetime import datetime
import time
from zipfile import ZipFile
from xml.etree import ElementTree as ET
from xml.dom.minidom import parse
from pathlib import Path
from urllib.request import Request, urlopen

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

# =============================================================================
#   Grund-Globals
# =============================================================================

translatePath = xbmcvfs.translatePath
addon = xbmcaddon.Addon()
addon_id = addon.getAddonInfo('id')

addon_info = addon.getAddonInfo
addon_version = addon_info('version')
addon_name = addon_info('name')
addon_icon = addon_info("icon")
addon_fanart = addon_info("fanart")
addon_profile = translatePath(addon_info('profile'))
addon_path = translatePath(addon_info('path'))
addon_data = addon_profile

setting = addon.getSetting
setting_set = addon.setSetting

home = translatePath('special://home/')
addons_path = os.path.join(home, 'addons/')
user_path = os.path.join(home, 'userdata/')
data_path = os.path.join(user_path, 'addon_data/')
db_path = translatePath('special://database/')
packages = os.path.join(addons_path, 'packages/')
zippath = os.path.join(packages, 'tempzip.zip')
resources = os.path.join(addon_path, 'resources/')
texts_path = os.path.join(resources, 'texts/')
notify_file = os.path.join(addon_profile, 'notify.txt')
authorize = os.path.join(texts_path, 'authorize.json')
installed_date = str(datetime.now())[:-7]

dialog = xbmcgui.Dialog()
dp = xbmcgui.DialogProgress()

user_agent = 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.101 Safari/537.36'
headers = {'User-Agent': user_agent}
sleep = xbmc.sleep


def local_string(i):
    try:
        return addon.getLocalizedString(int(i))
    except Exception:
        return str(i)


# =============================================================================
#   DB / Pfade herausfinden
# =============================================================================

def get_latest_db(db_type: str) -> str:
    highest_number = -1
    highest_file = None
    for file in os.listdir(db_path):
        if file.startswith(db_type) and file.endswith('.db'):
            try:
                number = int(file[len(db_type):file.index('.db')])
                if number > highest_number:
                    highest_number = number
                    highest_file = file
            except ValueError:
                pass
    if highest_file is not None:
        return os.path.join(db_path, highest_file)
    return ''


textures_db = get_latest_db('Textures')
addons_db = get_latest_db('Addons')


def currSkin():
    return xbmc.getSkinDir()


# =============================================================================
#   Whitelist / Excludes
# =============================================================================

excludes = []

file_path = os.path.join(addon_data, 'whitelist.json')

EXCLUDES_BASIC = excludes + [addon_id, 'kodi.log', 'Addons33.db', 'packages', 'backups']
EXCLUDES_FRESH = [addon_id, 'Addons33.db', 'kodi.log',
                  'script.module.certifi', 'script.module.chardet',
                  'script.module.idna', 'script.module.requests',
                  'script.module.urllib3']


def add_whitelist(_excludes):
    """
    Liest eine bestehende whitelist.json (falls vorhanden) und fügt
    dort eingetragene Addons zu den Excludes hinzu.
    """
    if xbmcvfs.exists(file_path):
        try:
            with open(file_path, 'r') as wl:
                whitelist = json.load(wl).get('whitelist', [])
            for x in whitelist:
                if x not in _excludes:
                    _excludes.append(x)
        except Exception:
            pass
        return _excludes
    else:
        return _excludes


EXCLUDES_INSTALL = add_whitelist(EXCLUDES_BASIC)


# =============================================================================
#   Skin-Switch / Settings JSON-RPC
# =============================================================================

def getOld(old):
    try:
        old = '"%s"' % old
        query = '{"jsonrpc":"2.0", "method":"Settings.GetSettingValue","params":{"setting":%s}, "id":1}' % old
        response = xbmc.executeJSONRPC(query)
        data = json.loads(response)
        if 'result' in data and 'value' in data['result']:
            return data['result']['value']
    except Exception:
        pass
    return None


def setNew(new, value):
    try:
        new = '"%s"' % new
        value = '"%s"' % value
        query = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue","params":{"setting":%s,"value":%s}, "id":1}' % (new, value)
        xbmc.executeJSONRPC(query)
    except Exception:
        pass
    return None


def swapSkins(skin):
    """
    Wechselt auf den angegebenen Skin (z. B. 'skin.estuary').
    """
    if skin == 'skin.confluence':
        HOME = xbmcvfs.translatePath('special://home/')
        skinfold = os.path.join(HOME, 'userdata', 'addon_data', 'skin.confluence')
        settings = os.path.join(skinfold, 'settings.xml')
        if not os.path.exists(settings):
            string = '<settings>\n    <setting id="FirstTimeRun" type="bool">true</setting>\n</settings>'
            os.makedirs(skinfold, exist_ok=True)
            with open(settings, 'w') as f:
                f.write(string)
        else:
            xbmcaddon.Addon(id='skin.confluence').setSetting('FirstTimeRun', 'true')
    old = 'lookandfeel.skin'
    value = skin
    current = getOld(old)
    new = old
    setNew(new, value)


# =============================================================================
#   Downloader (mit Speed / Prozent / file:// Support)
# =============================================================================

ADDON_NAME = addon_name
ICON = addon_icon


class Downloader:
    def __init__(self, url):
        self.url = url
        self.user_agent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        self.headers = {"User-Agent": self.user_agent}

    def get_urllib(self, decoding=True):
        url = str(self.url)
        if url.lower().startswith('file://'):
            path = url[8:] if url.lower().startswith('file:///') else url[7:]
            return open(path, 'rb')
        req = Request(self.url, headers=self.headers)
        if decoding:
            return urlopen(req).read().decode('utf-8')
        return urlopen(req)

    def get_length(self, response):
        try:
            return response.getheader('content-length')
        except Exception:
            pass
        try:
            if str(self.url).lower().startswith('file://'):
                p = str(self.url)
                p = p[8:] if p.lower().startswith('file:///') else p[7:]
                return str(os.path.getsize(p))
            if hasattr(response, 'name'):
                return str(os.path.getsize(response.name))
        except Exception:
            return None
        return None

    def download_build(self, name, zippath):
        dp = xbmcgui.DialogProgress()

        # Lokale Datei (file://)
        if str(self.url).lower().startswith('file://'):
            path = self.url[8:] if self.url.lower().startswith('file:///') else self.url[7:]
            total = os.path.getsize(path)
            mb = int(total / 1000000) if total else 0
            dp.create(f'Build Download: {name} - {mb}MB', local_string(30212))

            copied = 0
            start_time = time.time()
            chunk_size = 1024 * 1024  # 1 MB

            with open(path, 'rb') as src, open(zippath, 'wb') as dst:
                while True:
                    chunk = src.read(chunk_size)
                    if not chunk:
                        break
                    dst.write(chunk)
                    copied += len(chunk)

                    if total:
                        size_info = f"Size: {int(copied/1000000)} MB of {mb} MB"
                    else:
                        size_info = f"Size: {int(copied/1000000)} MB"

                    elapsed = time.time() - start_time
                    if elapsed > 0:
                        speed_mb = (copied / elapsed) / (1024.0 * 1024.0)
                        eta_seconds = (total - copied) / (copied / elapsed) if copied > 0 else 0
                        eta = time.strftime("%H:%M:%S", time.gmtime(eta_seconds))
                        speed_info = f"Speed: {speed_mb:.2f} MB/s | ETA: {eta}"
                    else:
                        speed_info = "Speed: calculating... | ETA: calculating..."

                    msg = f"Build Download: {name}[CR]{size_info}[CR]{speed_info}"
                    dp.update(int(copied * 100 / total) if total else 0, msg)
                    xbmc.sleep(10)

                    if dp.iscanceled():
                        try:
                            dst.close()
                            os.unlink(zippath)
                        except Exception:
                            pass
                        xbmcgui.Dialog().notification(ADDON_NAME, local_string(30214), icon=ICON)
                        dp.close()
                        sys.exit()

            final_info = f"{int(total/1000000)}/{mb} MB"
            msg = f"{local_string(30213)}[CR]{final_info}[CR]Download abgeschlossen."
            dp.update(100, msg)
            xbmc.sleep(500)
            dp.close()
            return

        # HTTP/HTTPS Download
        response = self.get_urllib(decoding=False)
        length = self.get_length(response)
        total = int(length) if length else 0
        mb = int(total / 1000000) if total else 0
        dp.create(f'Build Download: {name} - {mb}MB', local_string(30215))

        size = 0
        start_time = time.time()
        chunk_size = 1024 * 1024  # 1 MB

        with open(zippath, 'wb') as out:
            while True:
                chunk = response.read(chunk_size)
                if not chunk:
                    break

                out.write(chunk)
                size += len(chunk)

                if total:
                    size_info = f"Size: {int(size/1000000)} MB of {mb} MB"
                else:
                    size_info = f"Size: {int(size/1000000)} MB"

                elapsed = time.time() - start_time
                if elapsed > 0:
                    speed_mb = (size / elapsed) / (1024.0 * 1024.0)
                    eta_seconds = (total - size) / (size / elapsed) if size > 0 else 0
                    eta = time.strftime("%H:%M:%S", time.gmtime(eta_seconds))
                    speed_info = f"Speed: {speed_mb:.2f} MB/s | ETA: {eta}"
                else:
                    speed_info = "Speed: calculating... | ETA: calculating..."

                msg = f"Build Download: {name}[CR]{size_info}[CR]{speed_info}"
                dp.update(int(100 * size / total) if total else 0, msg)
                xbmc.sleep(10)

                if dp.iscanceled():
                    dp.close()
                    try:
                        out.close()
                        os.unlink(zippath)
                    except Exception:
                        pass
                    sys.exit()

        if total:
            final_info = f"{int(total/1000000)}/{mb} MB"
        else:
            final_info = f"{int(size/1000000)} MB"

        msg = f"{local_string(30217)}[CR]{final_info}[CR]Download abgeschlossen."
        dp.update(100, msg)
        xbmc.sleep(500)
        dp.close()


# =============================================================================
#   Maintenance / Fresh Start / DB-Cleanup
# =============================================================================

def fresh_start(standalone=False):
    """
    Löscht das Kodi-Userverzeichnis (mit Whitelist) für Build-Installationen.
    """
    if standalone:
        yesFresh = dialog.yesno(local_string(30012), local_string(30042),
                                nolabel=local_string(30032), yeslabel=local_string(30012))
        if not yesFresh:
            return

    # Skin auf Estuary zurück, damit keine Fremd-Skin-Reste crasht
    if currSkin() not in ['skin.estuary']:
        swapSkins('skin.estuary')
        x = 0
        xbmc.sleep(100)
        while not xbmc.getCondVisibility("Window.isVisible(yesnodialog)") and x < 150:
            x += 1
            xbmc.sleep(100)
            xbmc.executebuiltin('SendAction(Select)')
        if xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
            xbmc.executebuiltin('SendClick(11)')
        else:
            xbmc.log('Fresh Install: Skin Swap Timed Out!', xbmc.LOGDEBUG)
            return False
        xbmc.sleep(100)
    if currSkin() not in ['skin.estuary']:
        xbmc.log('Fresh Install: Skin Swap failed.', xbmc.LOGDEBUG)
        return

    dp.create(addon_name, local_string(30043))
    xbmc.sleep(100)
    dp.update(30, local_string(30043))
    xbmc.sleep(100)

    # Dateien/Ordner löschen – je nach Modus mit unterschiedlicher Exclude-Liste
    excludes_now = EXCLUDES_FRESH if standalone else EXCLUDES_INSTALL

    for root, dirs, files in os.walk(home, topdown=True):
        dirs[:] = [d for d in dirs if d not in excludes_now]
        for name in files:
            if name not in excludes_now:
                try:
                    os.remove(os.path.join(root, name))
                except Exception:
                    xbmc.log('Unable to delete ' + name, xbmc.LOGDEBUG)

    dp.update(60, local_string(30043))
    xbmc.sleep(100)

    for root, dirs, files in os.walk(home, topdown=True):
        dirs[:] = [d for d in dirs if d not in excludes_now]
        for name in dirs:
            if name not in ['addons', 'userdata', 'Database', 'addon_data', 'backups', 'temp']:
                try:
                    shutil.rmtree(os.path.join(root, name), ignore_errors=True)
                except Exception:
                    xbmc.log('Unable to delete ' + name, xbmc.LOGDEBUG)

    dp.update(60, local_string(30043))
    xbmc.sleep(100)
    if not os.path.exists(packages):
        os.mkdir(packages)
    dp.update(100, local_string(30044))
    xbmc.sleep(1000)

    if standalone:
        setting_set('firstrun', 'true')
        setting_set('buildname', 'No Build Installed')
        setting_set('buildversion', '0')
        truncate_tables()
        dialog.ok(addon_name, local_string(30045))
        os._exit(1)


def clear_packages():
    if not os.path.isdir(packages):
        return
    file_count = len(os.listdir(packages))
    for filename in os.listdir(packages):
        file_path = os.path.join(packages, filename)
        try:
            if os.path.isfile(file_path) or os.path.islink(file_path):
                os.unlink(file_path)
            elif os.path.isdir(file_path):
                shutil.rmtree(file_path)
        except Exception as e:
            xbmc.log('Failed to delete %s. Reason: %s' % (file_path, e), xbmc.LOGDEBUG)
    xbmcgui.Dialog().notification(addon_name, f'{file_count} ' + local_string(30046), addon_icon, 5000, sound=False)


def truncate_tables():
    if not addons_db:
        return
    try:
        con = sqlite3.connect(addons_db)
        cursor = con.cursor()
        cursor.execute('DELETE FROM addonlinkrepo;',)
        cursor.execute('DELETE FROM addons;',)
        cursor.execute('DELETE FROM package;',)
        cursor.execute('DELETE FROM repo;',)
        cursor.execute('DELETE FROM update_rules;',)
        cursor.execute('DELETE FROM version;',)
        con.commit()
    except sqlite3.Error as e:
        xbmc.log('There was an error reading the database - %s' % e, xbmc.LOGDEBUG)
    finally:
        try:
            if con:
                con.close()
        except Exception:
            pass
    try:
        con = sqlite3.connect(addons_db)
        cursor = con.cursor()
        cursor.execute('VACUUM;',)
        con.commit()
    except sqlite3.Error as e:
        xbmc.log(f"Failed to vacuum data from the sqlite table: {e}", xbmc.LOGDEBUG)
    finally:
        if con:
            con.close()


# =============================================================================
#   Backup / Restore
# =============================================================================

skin_path = xbmcvfs.translatePath('special://skin/')
text_path = os.path.join(addon_path, 'resources', 'texts')
skin = ET.parse(os.path.join(skin_path, 'addon.xml'))
root_skin = skin.getroot()
skin_id = root_skin.attrib['id']
gui_file = 'guisettings.xml'
skinsc = 'script.skinshortcuts'


def backup(path, file):
    src = os.path.join(path, file)
    dst = os.path.join(packages, file)
    if os.path.exists(src):
        try:
            if os.path.isfile(src):
                xbmcvfs.copy(src, dst)
            elif os.path.isdir(src):
                shutil.copytree(src, dst, dirs_exist_ok=True)
        except Exception as e:
            xbmc.log('Failed to backup %s. Reason: %s' % (dst, e), xbmc.LOGDEBUG)


def restore(path, file):
    src = os.path.join(packages, file)
    dst = os.path.join(path, file)
    if os.path.exists(src):
        try:
            if os.path.isfile(src):
                if os.path.exists(dst):
                    os.unlink(dst)
                shutil.move(src, dst)
            elif os.path.isdir(src):
                shutil.copytree(src, dst, dirs_exist_ok=True)
        except Exception as e:
            xbmc.log('Failed to restore %s. Reason: %s' % (dst, e), xbmc.LOGDEBUG)


def restore_gui(gui_save):
    """
    Wird von save_backup_restore('restore_gui') verwendet, wenn das Build
    denselben Namen hat wie vorher und GUI-Settings zurückgespielt werden sollen.
    """
    if os.path.exists(os.path.join(gui_save, gui_file)):
        try:
            xbmcvfs.copy(os.path.join(gui_save, gui_file), os.path.join(user_path, gui_file))
        except Exception as e:
            xbmc.log('Failed to restore %s. Reason: %s' % (os.path.join(user_path, gui_file), e), xbmc.LOGDEBUG)
    dialog.ok(addon_name, local_string(30108))
    os._exit(1)


def save_backup_restore(_type: str) -> None:
    """
    Zentrale Backup/Restore-Steuerung über backup_restore.json.
    _type: 'backup' | 'restore' | 'restore_gui'
    """
    json_path = os.path.join(text_path, 'backup_restore.json')
    if not os.path.exists(json_path):
        xbmc.log(f"[MBI 2.0] backup_restore.json not found at {json_path} – skipping backup/restore.", xbmc.LOGDEBUG)
        return
    with open(json_path, 'r', encoding='utf-8', errors='ignore') as f:
        item_list = json.loads(f.read())
        for item in item_list.keys():
            setting_id = item_list[item]['setting']
            path = item_list[item]['path']
            data = item + '/settings.xml'
            realizer = item + '/rdauth.json'
            youtube = item + '/api_keys.json'
            if path == 'user_path':
                path_use = user_path
            elif path == 'data_path':
                path_use = data_path
            else:
                path_use = path
            try:
                if setting(setting_id) == 'true':
                    if _type == 'backup':
                        backup(path_use, data)
                        backup(user_path, item)
                        backup(path_use, realizer)
                        backup(path_use, youtube)
                    elif _type == 'restore':
                        if item != 'guisettings.xml':
                            restore(path_use, item)
                    elif _type == 'restore_gui':
                        restore(path_use, item)
            except Exception as e:
                xbmc.log(f'Error= {e}', xbmc.LOGDEBUG)
                continue


# =============================================================================
#   Addons Enable
# =============================================================================

addon_xmls = []


def enable_addons():
    for name in glob.glob(os.path.join(addons_path, '*/addon.xml')):
        addon_xmls.append(name)
    addon_xmls.sort()
    addon_ids = []
    for xml in addon_xmls:
        try:
            root = parse(xml)
            tag = root.documentElement
            _id = tag.getAttribute('id')
            addon_ids.append(_id)
        except Exception:
            pass
    disabled = []
    for x in addon_ids:
        try:
            xbmcaddon.Addon(id=x)
        except Exception:
            disabled.append(x)
    for y in disabled:
        try:
            enable_db(y)
        except Exception:
            pass
    xbmc.executebuiltin('UpdateLocalAddons')
    xbmc.executebuiltin('UpdateAddonRepos')


def enable_db(d_addon):
    if not addons_db:
        return
    conn = sqlite3.connect(addons_db)
    c = conn.cursor()
    try:
        c.execute("SELECT id, addonID, enabled FROM installed WHERE addonID = ?", (d_addon,))
        found = c.fetchone()
        if found is None:
            c.execute('INSERT INTO installed (addonID , enabled, installDate) VALUES (?,?,?)',
                      (d_addon, '1', installed_date))
        else:
            c.execute('UPDATE installed SET enabled = ? WHERE addonID = ? ', (1, d_addon,))
    except Exception as e:
        xbmc.log('Failed to enable %s. Reason: %s' % (d_addon, e), xbmc.LOGDEBUG)
    conn.commit()
    conn.close()


# =============================================================================
#   Build-Install (inkl. Markerfile und Binary-Handling)
# =============================================================================

addons_path_path = Path(xbmcvfs.translatePath('special://home/addons'))
user_data_path = Path(xbmcvfs.translatePath('special://userdata'))
binaries_path = Path(addon_profile) / 'binaries.json'


def download_build(name, url):
    if os.path.exists(zippath):
        os.unlink(zippath)
    d = Downloader(url)
    d.download_build(name, zippath)


# =============================================================================
#   EXTRACT BUILD (bundle_name Parameter + Anzeige im Dialog)
# =============================================================================
def extract_build(bundle_name: str):
    if os.path.exists(zippath):
        dp.create(addon_name, f'Extracting Bundle: {bundle_name}')

        counter = 1
        with ZipFile(zippath, 'r') as z:
            files = z.infolist()
            total_files = len(files)
            for file in files:
                filename = file.filename
                filename_path = os.path.join(home, filename)
                progress_percentage = int(counter / total_files * 100)

                try:
                    if not os.path.exists(filename_path) or 'Addons33.db' in filename:
                        z.extract(file, home)
                except Exception as e:
                    xbmc.log(f'Error extracting {filename} - {e}', xbmc.LOGDEBUG)

                dp.update(
                    progress_percentage,
                    f'Extracting {bundle_name}\n{progress_percentage}%\n{filename}'
                )
                counter += 1

        dp.update(100, f'Extracting {bundle_name}\nDone')
        xbmc.sleep(500)
        dp.close()
        os.unlink(zippath)


def install_addon(plugin_id):
    if xbmc.getCondVisibility(f'System.HasAddon({plugin_id})'):
        return True
    xbmc.executebuiltin(f'InstallAddon({plugin_id})')
    clicked = False
    start = time.time()
    timeout = 120
    while not xbmc.getCondVisibility(f'System.HasAddon({plugin_id})'):
        if time.time() >= start + timeout:
            return False
        xbmc.sleep(500)
        if xbmc.getCondVisibility('Window.IsTopMost(yesnodialog)') and not clicked:
            xbmc.executebuiltin('SendClick(yesnodialog, 11)')
            clicked = True
    return True


def check_binary():
    """
    Entfernt Binary-Addons vor dem Build-Install und speichert deren IDs in binaries.json,
    damit sie später über restore_binary() wieder installiert werden können.
    """
    binary_list = []
    for folder in addons_path_path.iterdir():
        if folder.is_dir():
            addon_xml = folder / 'addon.xml'
            if addon_xml.exists():
                with open(addon_xml, 'r', encoding='utf-8', errors='ignore') as f:
                    _xml = f.read()
                if 'kodi.binary' in _xml:
                    try:
                        root = ET.fromstring(_xml)
                        binary_list.append(root.attrib['id'])
                    except Exception:
                        binary_list.append(folder.name)
                    try:
                        shutil.rmtree(folder)
                    except PermissionError as e:
                        xbmc.log(f'Unable to delete binary {folder} - {e}')
    if binary_list:
        try:
            binaries_path.parent.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
        with open(binaries_path, 'w', encoding='utf-8') as f:
            json.dump({'items': binary_list}, f, indent=4)


def restore_binary():
    """
    Wird typischerweise von einem separaten Service aufgerufen,
    um nach einem Build-Install die Binary-Addons wiederherzustellen.
    """
    if not binaries_path.exists():
        return
    with open(binaries_path, 'r', encoding='utf-8', errors='ignore') as f:
        binaries_list = json.loads(f.read())['items']
    failed = []
    for plugin_id in binaries_list:
        install = install_addon(plugin_id)
        if install is not True:
            failed.append(plugin_id)
    if not failed:
        binaries_path.unlink()
    else:
        try:
            binaries_path.parent.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
        with open(binaries_path, 'w', encoding='utf-8') as f:
            json.dump({'items': failed}, f, indent=4)


def enable_wizard():
    if not addons_db:
        return
    try:
        timestamp = str(datetime.now())[:-7]
        con = sqlite3.connect(addons_db)
        cursor = con.cursor()
        cursor.execute('INSERT or IGNORE into installed (addonID , enabled, installDate) VALUES (?,?,?)',
                       (addon_id, 1, timestamp,))
        cursor.execute('UPDATE installed SET enabled = ? WHERE addonID = ? ', (1, addon_id,))
        con.commit()
    except sqlite3.Error as e:
        xbmc.log('There was an error writing to the database - %s' % e, xbmc.LOGDEBUG)
    finally:
        try:
            if con:
                con.close()
        except Exception:
            pass


def build_install(name, name2, version, url):
    """
    Haupt-Installroutine, wird von addon.py aufgerufen.
    """
    # Sicherheitsabfrage (OHNE Farben)
    if not dialog.yesno(
        name,
        local_string(30028),
        nolabel=local_string(30029),
        yeslabel=local_string(30030)
    ):
        return

    # Download Build (remote oder local file://)
    download_build(name, url)


    # Binary-Addons sichern (VOR dem Wipe), damit sie nach dem Neustart wieder installiert werden können    # Backup vor Fresh Start
    save_backup_restore('backup')

    # System leeren (Fresh Start mit Whitelist)
    fresh_start()

    # Build entpacken
    extract_build(name)

    # Binary-Addons NACH Build erfassen (SimpleWizard Verhalten)
    try:
        check_binary()
    except Exception as e:
        xbmc.log("[MBI 2.0] check_binary() failed: %s" % e, xbmc.LOGDEBUG)

    # Build entpacken (Bundle-Name im Dialog anzeigen)
    extract_build(name)

    # Backup wiederherstellen
    if name2 == setting('buildname'):
        save_backup_restore('restore_gui')
    else:
        save_backup_restore('restore')

    # Paketordner leeren
    clear_packages()

    # Build-Infos in Settings schreiben
    setting_set('buildname', name2)
    setting_set('buildversion', version)
    setting_set('update_passed', 'false')
    setting_set('firstrun', 'true')

    # Addons aktivieren
    try:
        enable_addons()
    except Exception as e:
        xbmc.log(f"[MBI 2.0] enable_addons() failed: {e}", xbmc.LOGDEBUG)

    # Wizard in DB aktivieren
    enable_wizard()

    # Addon-DB bereinigen
    truncate_tables()

    # Markerdatei für installierten Build, damit addon.py Reinstall abfragen kann
    try:
        marker_file = os.path.join(home, 'build_installed')
        with open(marker_file, 'w', encoding='utf-8') as f:
            f.write('1')
    except Exception as e:
        xbmc.log(f"[MBI 2.0] Unable to write build_installed marker: {e}", xbmc.LOGDEBUG)

    dialog.ok(addon_name, local_string(30036) % name)
    os._exit(1)
