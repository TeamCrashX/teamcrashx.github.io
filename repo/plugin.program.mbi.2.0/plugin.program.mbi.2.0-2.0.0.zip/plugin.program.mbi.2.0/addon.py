def build_url(**params):
    base=sys.argv[0]
    query=urllib.parse.urlencode(params)
    return base + ('?' + query if query else '')

# -*- coding: utf-8 -*-
import os
import ssl
import sys
import traceback
import urllib.request
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

from core import build_install

# ---------------------------------------------------------------------------
# Basis-Infos & Pfade
# ---------------------------------------------------------------------------

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
ADDON_NAME = ADDON.getAddonInfo("name")
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
HOME = xbmcvfs.translatePath("special://home/")
LOG_PREFIX = "[MBIUltimateBuildLoader] "

SPLASH_PATH = os.path.join(ADDON_PATH, "resources", "media", "splash_installer.jpg")
SHORTLINK_FILE = os.path.join(PROFILE, "kurz_link.txt")

local_string = ADDON.getLocalizedString


def log(msg, level=xbmc.LOGDEBUG):
    xbmc.log(f"{LOG_PREFIX}{msg}", level)


def ok(title, message):
    xbmcgui.Dialog().ok(title, message)


# ---------------------------------------------------------------------------
# Splash-Fenster für Installationen
# ---------------------------------------------------------------------------

class InstallerSplash(xbmcgui.WindowDialog):
    def __init__(self):
        super().__init__()

        try:
            screen_w = self.getWidth()
            screen_h = self.getHeight()
        except Exception:
            screen_w, screen_h = 1280, 720

        if not screen_w or not screen_h:
            screen_w, screen_h = 1280, 720

        if os.path.exists(SPLASH_PATH):
            img = xbmcgui.ControlImage(0, 0, screen_w, screen_h, SPLASH_PATH)
            self.addControl(img)

        # 30359: "MBI 2.0 wird gestartet..."
        self.label = xbmcgui.ControlLabel(
            60,
            screen_h - 140,
            screen_w - 120,
            40,
            local_string(30359),
            alignment=0x00000002,  # center
        )
        self.addControl(self.label)

    def set_text(self, text):
        try:
            self.label.setLabel(text)
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Kurzlink-Datei (kurz_link.txt) – Laden / Speichern / Parser
# ---------------------------------------------------------------------------

def ensure_profile_dir():
    if not os.path.exists(PROFILE):
        try:
            os.makedirs(PROFILE, exist_ok=True)
            log("Profilverzeichnis erstellt: %s" % PROFILE)
        except Exception as e:
            log("Profilverzeichnis konnte nicht erstellt werden: %s" % e, xbmc.LOGWARNING)


def _parse_shortlink_line(line):
    line = line.strip()
    if not line:
        return None
    if "|" in line:
        code, desc = line.split("|", 1)
        return code.strip(), desc.strip()
    return line.strip(), ""


def load_shortlink_entries():
    ensure_profile_dir()
    entries = []
    if not os.path.exists(SHORTLINK_FILE):
        return entries
    try:
        with open(SHORTLINK_FILE, "r", encoding="utf-8") as f:
            for line in f:
                parsed = _parse_shortlink_line(line)
                if not parsed:
                    continue
                code, desc = parsed
                if not code:
                    continue
                entries.append({"code": code, "desc": desc})
    except Exception as e:
        log("Fehler beim Lesen der kurz_link.txt: %s" % e, xbmc.LOGWARNING)
    return entries


def save_shortlink_entries(entries):
    ensure_profile_dir()
    try:
        with open(SHORTLINK_FILE, "w", encoding="utf-8") as f:
            for e in entries:
                code = (e.get("code") or "").strip()
                desc = (e.get("desc") or "").strip()
                if not code:
                    continue
                if desc:
                    f.write(f"{code}|{desc}\n")
                else:
                    f.write(f"{code}\n")
        log("Kurzlink-Liste gespeichert (%d Einträge)." % len(entries))
    except Exception as e:
        log("Fehler beim Schreiben der kurz_link.txt: %s" % e, xbmc.LOGWARNING)


def add_or_update_shortlink(code, desc=""):
    code = (code or "").strip()
    desc = (desc or "").strip()
    if not code:
        return
    entries = load_shortlink_entries()
    updated = False
    for e in entries:
        if e["code"].lower() == code.lower():
            e["code"] = code
            e["desc"] = desc
            updated = True
            break
    if not updated:
        entries.append({"code": code, "desc": desc})
    save_shortlink_entries(entries)
    log("Kurzlink hinzugefügt/aktualisiert: %s | %s" % (code, desc))


# ---------------------------------------------------------------------------
# Kurzlink-Auswahl (Build installieren – Standard-Flow)
# ---------------------------------------------------------------------------

def choose_shortlink_for_install():
    dialog = xbmcgui.Dialog()
    entries = load_shortlink_entries()

    # 30300: "Build-Auswahl"
    # 30304: "Neuen Kurzlink eingeben"
    # 30305: "Gespeicherten Kurzlink auswählen"
    options = [local_string(30304), local_string(30305)]
    idx = dialog.select(local_string(30300), options)
    if idx == -1:
        return None

    # Neuer Kurzlink
    if idx == 0:
        # 30306: "Bitte Build-Kurzlink-Code eingeben"
        code = dialog.input(
            local_string(30306),
            type=xbmcgui.INPUT_ALPHANUM,
        )
        if not code:
            return None
        # 30307: "Optionale Beschreibung eingeben"
        desc = dialog.input(
            local_string(30307),
            defaultt="",
        )
        add_or_update_shortlink(code, desc)
        return code

    # Gespeicherte Auswahl
    if not entries:
        # 30308 + 30309
        ok(
            local_string(30308),
            local_string(30309),
        )
        code = dialog.input(
            local_string(30306),
            type=xbmcgui.INPUT_ALPHANUM,
        )
        if not code:
            return None
        desc = dialog.input(
            local_string(30307),
            defaultt="",
        )
        add_or_update_shortlink(code, desc)
        return code

    labels = []
    for e in entries:
        if e["desc"]:
            labels.append(f"{e['code']}  -  {e['desc']}")
        else:
            labels.append(e["code"])
    # 30310: "Gespeicherte Kurzlinks"
    idx2 = dialog.select(local_string(30310), labels)
    if idx2 == -1:
        return None
    return entries[idx2]["code"]


# ---------------------------------------------------------------------------
# Kurzlink-Favoriten – mit Mini-Manager
# ---------------------------------------------------------------------------

def raw_edit_shortlinks():
    """
    RAW-Editor: gesamte kurz_link.txt in einem großen Textfeld bearbeiten.
    30323: "RAW-Bearbeitung der kurz_link.txt"
    """
    ensure_profile_dir()
    existing = ""
    if os.path.exists(SHORTLINK_FILE):
        try:
            with open(SHORTLINK_FILE, "r", encoding="utf-8") as f:
                existing = f.read()
        except Exception as e:
            log("Fehler beim Lesen der kurz_link.txt im RAW-Editor: %s" % e, xbmc.LOGWARNING)

    kb = xbmc.Keyboard(existing, local_string(30323))
    kb.doModal()
    if not kb.isConfirmed():
        return
    new_text = kb.getText()
    if new_text is None:
        return
    new_text = new_text.replace("\r\n", "\n").replace("\r", "\n")
    try:
        with open(SHORTLINK_FILE, "w", encoding="utf-8") as f:
            f.write(new_text)
        log("RAW-Editor: kurz_link.txt gespeichert.")
        # 30324 / 30325
        ok(local_string(30324), local_string(30325))
    except Exception as e:
        log("Fehler beim Schreiben in RAW-Editor: %s" % e, xbmc.LOGERROR)
        # 30326 / 30327
        ok(local_string(30326), local_string(30327))


def choose_favorite_shortlink():
    """
    Öffnet die gespeicherten Kurzlinks als Favoritenliste
    und erlaubt:
      - Build installieren
      - Kurzlink umbenennen
      - Beschreibung ändern
      - Eintrag löschen
      - RAW-Editor öffnen
    Gibt bei 'Build installieren' den gewählten Code zurück, sonst None.
    """
    dialog = xbmcgui.Dialog()

    while True:
        entries = load_shortlink_entries()
        if not entries:
            # 30328 / 30329
            ok(
                local_string(30328),
                local_string(30329),
            )
            return None

        labels = []
        for e in entries:
            if e["desc"]:
                labels.append(f"{e['code']}  -  {e['desc']}")
            else:
                labels.append(e["code"])

        # 30311: "Kurzlink-Favoriten"
        idx = dialog.select(local_string(30311), labels)
        if idx == -1:
            return None

        entry = entries[idx]

        # 30312: "Kurzlink: {0}"
        # 30313–30318: Menü-Aktionen
        action_idx = dialog.select(
            local_string(30312).format(entry["code"]),
            [
                local_string(30313),  # Build installieren
                local_string(30314),  # Kurzlink umbenennen
                local_string(30315),  # Beschreibung ändern
                local_string(30316),  # Eintrag löschen
                local_string(30317),  # RAW-Editor öffnen
                local_string(30318),  # Zurück
            ],
        )
        # Zurück zur Favoritenliste
        if action_idx in (-1, 5):
            continue

        # Build installieren
        if action_idx == 0:
            return entry["code"]

        # Kurzlink umbenennen
        if action_idx == 1:
            # 30319: "Neuer Kurzlink-Code"
            new_code = dialog.input(local_string(30319), defaultt=entry["code"])
            if new_code:
                entry["code"] = new_code.strip()
                save_shortlink_entries(entries)
            continue

        # Beschreibung ändern
        if action_idx == 2:
            # 30320: "Neue Beschreibung"
            new_desc = dialog.input(local_string(30320), defaultt=entry["desc"])
            entry["desc"] = (new_desc or "").strip()
            save_shortlink_entries(entries)
            continue

        # Eintrag löschen
        if action_idx == 3:
            # 30321 / 30322
            if dialog.yesno(
                local_string(30321),
                local_string(30322).format(entry["code"]),
            ):
                del entries[idx]
                save_shortlink_entries(entries)
            continue

        # RAW-Editor
        if action_idx == 4:
            raw_edit_shortlinks()
            continue


# ---------------------------------------------------------------------------
# Shortlink-Auflösung (tinyurl / bit.ly / t1p.de)
# ---------------------------------------------------------------------------

def resolve_shortlink(code):
    """
    Versucht nacheinander:
      - https://tinyurl.com/CODE
      - https://bit.ly/CODE
      - https://t1p.de/CODE
    und gibt die finale URL zurück.
    """
    if not code:
        return None

    urls = [
        f"https://tinyurl.com/{code}",
        f"https://bit.ly/{code}",
        f"https://t1p.de/{code}",
    ]
    ctx = ssl._create_unverified_context()

    for u in urls:
        try:
            log(f"Teste URL: {u}")
            with urllib.request.urlopen(u, timeout=5, context=ctx) as r:
                final_url = r.geturl()
                log(f"Erfolgreich: {u} -> {final_url}")
                return final_url
        except Exception as e:
            log(f"URL nicht erreichbar: {u} ({e})", xbmc.LOGWARNING)

    return None


# ---------------------------------------------------------------------------
# Lokales Build auswählen & installieren
# ---------------------------------------------------------------------------

def choose_local_build():
    """
    Nutzt Kodi-Standarddialog, um eine .zip auszuwählen.
    Ein Dialog, in dem man durch Ordner navigiert
    und ZIP-Dateien direkt sieht und wählen kann.
    """
    dialog = xbmcgui.Dialog()
    start_folder = xbmcvfs.translatePath("special://home/")

    zip_path = dialog.browseSingle(
        1,                       # ShowAndGetFile
        local_string(30341),     # "Build.zip auswählen"
        "files",                 # Bereich
        ".zip",                  # nur ZIPs anzeigen
        False,                   # useThumbs
        False,                   # treatAsFolder
        start_folder
    )
    if not zip_path:
        return None

    if not zip_path.lower().endswith(".zip"):
        ok(local_string(30344), local_string(30345))
        return None

    return zip_path


def install_local_build():
    """
    Startet den Installationsablauf für eine lokale Build-ZIP-Datei.
    Flow identisch zur Kurzlink-Installation:
      ZIP wählen -> (optional) Reinstall bestätigen -> Build-Install (inkl. Wipe/Extrahieren/Quit im core)
    """
    splash = InstallerSplash()
    splash.show()
    splash.set_text(local_string(30346))  # "Lokales Build wird vorbereitet..."

    try:
        zip_path = choose_local_build()
        if not zip_path:
            ok(local_string(30342), local_string(30343))  # Abgebrochen / Keine lokale Build-ZIP
            return

        # Kodi kann sowohl "file://..." als auch lokale Pfade liefern.
        if zip_path.lower().startswith("file://"):
            url = zip_path
        else:
            real_path = xbmcvfs.translatePath(zip_path)
            real_path = real_path.replace("\\", "/")
            url = "file:///" + real_path.lstrip("/")

        # Optional: Wenn bereits ein Build installiert ist, fragen ob neu installiert werden soll
        if not confirm_reinstall_if_needed():
            return

        # Name wie beim Kurzlink-Flow (nur Anzeige)
        name = local_string(30347).format(os.path.basename(zip_path))  # "Lokales Build: {0}"

        # Gleicher Call wie bei Kurzlink-Installation (core kümmert sich um Wipe/Extract/Quit)
        build_install(name, name, "", url)

    finally:
        try:
            splash.close()
        except Exception:
            pass

# ---------------------------------------------------------------------------
# Installations-Flow (für Kurzlinks)
# ---------------------------------------------------------------------------

def local_install():
    # Menüpunkt: Ordner wählen -> ZIP wählen -> installieren
    install_local_build()



def run_install_flow(code_provider, abort_message_id, confirm=True, preset=None, advanced_opts=None):
    """
    Führt den Splash-Bildschirm und die eigentliche Build-Installation aus.
    code_provider: Funktion, die einen Kurzlink-Code zurückgibt oder None.
    abort_message_id: String-ID für Abbruchmeldung.
    """
    splash = InstallerSplash()
    splash.show()
    splash.set_text(local_string(30354))  # "MBI 2.0 wird vorbereitet..."

    try:
        code = code_provider()
        if not code:
            ok(local_string(30342), local_string(abort_message_id))  # "Abgebrochen", Meldung
            return

        splash.set_text(local_string(30354))
        url = resolve_shortlink(code)
        if not url:
            # 30356 / 30355
            ok(local_string(30356), local_string(30355))
            return

        # 30357: "Bundle: {0}"
        name = local_string(30357).format(code)
        splash.set_text(local_string(30215))  # "Downloading Build..." – aus core-Strings
        build_install(name, name, "", url)
    finally:
        try:
            splash.close()
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Reinstall-Abfrage (falls bereits ein Build installiert ist)
# ---------------------------------------------------------------------------

def confirm_reinstall_if_needed():
    """
    Prüft, ob eine Markerdatei 'build_installed' existiert.
    Falls ja, fragt nach, ob ein neues Build installiert werden soll.
    """
    marker_file = os.path.join(HOME, "build_installed")
    if not os.path.exists(marker_file):
        return True

    dialog = xbmcgui.Dialog()
    # 30348 / 30349 / 30350 / 30351
    if dialog.yesno(
        local_string(30348),
        local_string(30349),
        nolabel=local_string(30350),
        yeslabel=local_string(30351),
    ):
        return True
    return False


# ---------------------------------------------------------------------------
# Hauptmenü / Einstieg
# ---------------------------------------------------------------------------

def main():
    main_menu()


def main_menu():
    handle = int(sys.argv[1])
    xbmcplugin.setPluginCategory(handle, local_string(30300))
    xbmcplugin.setContent(handle, "files")

    # Helper to add an item
    def _add(label, action, icon_name=None, is_folder=False):
        li = xbmcgui.ListItem(label)
        # minimal: keine Emojis. Setze Fanart + optionales Icon pro Menüpunkt
        try:
            fanart = FANART if 'FANART' in globals() else os.path.join(ADDON_PATH, "fanart.jpg")
            art = {"fanart": fanart}
            if icon_name:
                icon_path = os.path.join(ADDON_PATH, "resources", "media", icon_name)
                art.update({"icon": icon_path, "thumb": icon_path, "poster": icon_path})
            li.setArt(art)
        except Exception:
            pass
        url = build_url(action=action)
        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=is_folder)

    _add(local_string(30360), "quick_install", "menu_quick.png", False)
    _add(local_string(30361), "shortlink_favorites", "menu_shortlinks.png", True)
    _add(local_string(30362), "local_install", "menu_local.png", False)
    _add(local_string(30363), "advanced_install", "menu_advanced.png", False)

    xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)

def quick_install():
    # Quick Install = Kurzlink eingeben -> speichern -> sofort installieren
    from shortlinks import add_or_update_shortlink
    d = xbmcgui.Dialog()

    code = d.input(local_string(30352))  # Kurzlink-Code
    if not code:
        return

    desc = d.input(local_string(30366))
    add_or_update_shortlink(code.strip(), (desc or "").strip())

    # Direkt Installation starten (ohne extra Bestätigungsdialog)
    run_install_flow(
        lambda: code.strip(),
        30352,
        confirm=False,
        preset="quick",
    )

def shortlink_favorites():
    # Kurzlink-Favoriten anzeigen -> Auswahl / Manager
    d = xbmcgui.Dialog()
    options = [
        local_string(30364),
        local_string(30365),
    ]
    idx = d.select(local_string(30361), options)
    if idx == -1:
        return

    if idx == 0:
        from shortlinks import choose_shortlink_for_install
        code = choose_shortlink_for_install()
        if not code:
            return
        run_install_flow(
            lambda: code,
            30352,
            confirm=False,
            preset="quick",
        )
        return

    if idx == 1:
        from shortlinks import manage_shortlinks
        manage_shortlinks()
        return


def advanced_install():
    opts = get_advanced_options()
    if opts is None:
        return
    run_install_flow(
        choose_shortlink_for_install,
        30352,
        confirm=True,
        preset="advanced",
        advanced_opts=opts,
    )


def get_advanced_options():
    dialog = xbmcgui.Dialog()
    options = [
        local_string(30375),
        local_string(30376),
        local_string(30377),
    ]
    preselect = [0, 1, 2]
    selected = dialog.multiselect("Advanced Optionen", options, preselect=preselect)
    if selected is None:
        return None
    return {
        "backup": 0 in selected,
        "wipe": 1 in selected,
        "clear_pkgs": 2 in selected,
    }


def manage_shortlink_favorites():
    # Favoriten verwalten/aufrufen ohne zusätzliche Checks
    show_shortlink_menu()

# ---------------------------------------------------------------------------
# Einstiegspunkt
# ---------------------------------------------------------------------------


if __name__ == "__main__":
    try:
        action = ""
        if len(sys.argv) >= 3 and sys.argv[2]:
            try:
                params = urllib.parse.parse_qs(sys.argv[2].lstrip("?"))
                action = params.get("action", [""])[0]
            except Exception:
                action = ""

        if action in ("manage_links", "manage_shortlinks"):
            # Direkt aus Einstellungen: Kurzlink-Manager
            from shortlinks import manage_shortlinks
            manage_shortlinks()
        elif action == "quick_install":
            quick_install()
        elif action == "shortlink_favorites":
            shortlink_favorites()
        elif action == "local_install":
            local_install()
        elif action == "advanced_install":
            advanced_install()
        else:
            # Standard: Hauptmenü als Kodi-Directory
            main_menu()

    except Exception as e:
        log("Unerwarteter Fehler in addon.py: %s" % e, xbmc.LOGERROR)
        try:
            log(traceback.format_exc(), xbmc.LOGERROR)
        except Exception:
            pass
        ok(ADDON_NAME, local_string(30379))

