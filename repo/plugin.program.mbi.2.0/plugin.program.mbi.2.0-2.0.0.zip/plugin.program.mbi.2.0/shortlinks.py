# -*- coding: utf-8 -*-
import os
import ssl
import urllib.request

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))

def local_string(string_id):
    try:
        return ADDON.getLocalizedString(string_id)
    except Exception:
        return str(string_id)

LOG_PREFIX = "[BuildLink] "

SHORTLINK_FILE = os.path.join(PROFILE, "kurz_link.txt")


def log(msg, level=xbmc.LOGDEBUG):
    xbmc.log(f"{LOG_PREFIX}{msg}", level)


def ok(title, message):
    xbmcgui.Dialog().ok(title, message)


def ensure_profile_dir():
    if not os.path.exists(PROFILE):
        try:
            os.makedirs(PROFILE, exist_ok=True)
            log("Profilverzeichnis erstellt: %s" % PROFILE)
        except Exception as e:
            log("Profilverzeichnis (Addon-Ordner) konnte nicht erstellt werden: %s" % e, xbmc.LOGWARNING)


def _parse_shortlink_line(line):
    line = line.strip()
    if not line:
        return None
    if "|" in line:
        code, desc = line.split("|", 1)
        return code.strip(), desc.strip()
    return line.strip(), ""


def load_shortlink_entries():
    ensure_profile_dir()
    entries = []
    if not os.path.exists(SHORTLINK_FILE):
        return entries
    try:
        with open(SHORTLINK_FILE, "r", encoding="utf-8") as f:
            for line in f:
                parsed = _parse_shortlink_line(line)
                if not parsed:
                    continue
                code, desc = parsed
                if not code:
                    continue
                entries.append({"code": code, "desc": desc})
    except Exception as e:
        log("Fehler beim Lesen der kurz_link.txt: %s" % e, xbmc.LOGWARNING)
    return entries


def save_shortlink_entries(entries):
    ensure_profile_dir()
    try:
        with open(SHORTLINK_FILE, "w", encoding="utf-8") as f:
            for e in entries:
                code = (e.get("code") or "").strip()
                desc = (e.get("desc") or "").strip()
                if not code:
                    continue
                if desc:
                    f.write(f"{code}|{desc}\n")
                else:
                    f.write(f"{code}\n")
        log("Kurzlink-Liste gespeichert (%d Einträge)." % len(entries))
    except Exception as e:
        log("Fehler beim Schreiben der kurz_link.txt: %s" % e, xbmc.LOGWARNING)


def add_or_update_shortlink(code, desc=""):
    code = (code or "").strip()
    desc = (desc or "").strip()
    if not code:
        return
    entries = load_shortlink_entries()
    updated = False
    for e in entries:
        if e["code"].lower() == code.lower():
            e["code"] = code
            e["desc"] = desc
            updated = True
            break
    if not updated:
        entries.append({"code": code, "desc": desc})
    save_shortlink_entries(entries)
    log("Kurzlink hinzugefügt/aktualisiert: %s | %s" % (code, desc))


def choose_shortlink_for_install():
    """Zeigt ausschließlich die gespeicherten Kurzlinks zur Auswahl (kein 'Neuen Kurzlink eingeben')."""
    dialog = xbmcgui.Dialog()
    entries = load_shortlink_entries()
    if not entries:
        dialog.ok(local_string(30361), local_string(30391))
        return None

    labels = []
    for e in entries:
        if e.get("desc"):
            labels.append(f"{e['code']}  -  {e['desc']}")
        else:
            labels.append(e["code"])

    idx = dialog.select(local_string(30369), labels)
    if idx == -1:
        return None
    return entries[idx]["code"]

def raw_edit_shortlinks():
    """
    RAW-Editor: gesamte kurz_link.txt in einem großen Textfeld bearbeiten.
    Format pro Zeile: code|beschreibung oder nur code.
    """
    ensure_profile_dir()
    existing = ""
    if os.path.exists(SHORTLINK_FILE):
        try:
            with open(SHORTLINK_FILE, "r", encoding="utf-8") as f:
                existing = f.read()
        except Exception as e:
            log("Fehler beim Lesen der kurz_link.txt im RAW-Editor: %s" % e, xbmc.LOGWARNING)

    kb = xbmc.Keyboard(existing, local_string(30387))
    kb.doModal()
    if not kb.isConfirmed():
        return
    new_text = kb.getText()
    if new_text is None:
        return
    new_text = new_text.replace("\r\n", "\n").replace("\r", "\n")
    try:
        with open(SHORTLINK_FILE, "w", encoding="utf-8") as f:
            f.write(new_text)
        log("RAW-Editor: kurz_link.txt gespeichert.")
        ok(local_string(30384), local_string(30385))
    except Exception as e:
        log("Fehler beim Schreiben in RAW-Editor: %s" % e, xbmc.LOGERROR)
        ok(local_string(30380), local_string(30386))


def resolve_shortlink(code):
    """
    Nimmt NUR den Code und versucht ihn nacheinander als:
    - https://tinyurl.com/CODE
    - https://bit.ly/CODE
    - https://t1p.de/CODE
    aufzulösen. Gibt die finale URL zurück.
    """
    if not code:
        return None

    urls = [
        f"https://tinyurl.com/{code}",
        f"https://bit.ly/{code}",
        f"https://t1p.de/{code}",
    ]
    ctx = ssl._create_unverified_context()

    for u in urls:
        try:
            log(f"Teste URL: {u}")
            with urllib.request.urlopen(u, timeout=5, context=ctx) as r:
                final_url = r.geturl()
                log(f"Erfolgreich: {u} -> {final_url}")
                return final_url
        except Exception as e:
            log(f"URL nicht erreichbar: {u} ({e})", xbmc.LOG_WARNING)

    return None

def manage_shortlinks():
    entries = load_shortlink_entries()
    dialog = xbmcgui.Dialog()

    while True:
        if not entries:
            options = [local_string(30389), local_string(30390)]
        else:
            options = [f"{e['code']} - {e['desc']}" if e['desc'] else e['code'] for e in entries]
            options.extend([local_string(30388), local_string(30389), local_string(30390)])

        idx = dialog.select(local_string(30370), options)
        if idx == -1 or (entries and idx == len(options) - 1) or (not entries and idx == 1):
            break

        if not entries:
            if idx == 0:
                raw_edit_shortlinks()
                entries = load_shortlink_entries()
            continue

        if idx == len(options) - 3:
            # Neuer Eintrag
            code = dialog.input(local_string(30392))
            if not code:
                continue
            desc = dialog.input(local_string(30366))
            add_or_update_shortlink(code, desc)
            entries = load_shortlink_entries()
        elif idx == len(options) - 2:
            raw_edit_shortlinks()
            entries = load_shortlink_entries()
        else:
            # Bestehenden Eintrag bearbeiten/löschen
            entry = entries[idx]
            action_idx = dialog.select(
                local_string(30393) % entry["code"],
                [local_string(30371), local_string(30372), local_string(30373), local_string(30374)]
            )
            if action_idx == -1 or action_idx == 3:
                continue

            if action_idx == 0:
                new_code = dialog.input(local_string(30381), defaultt=entry["code"])
                if new_code:
                    entry["code"] = new_code.strip()
                    save_shortlink_entries(entries)
            elif action_idx == 1:
                new_desc = dialog.input(local_string(30382), defaultt=entry["desc"])
                entry["desc"] = (new_desc or "").strip()
                save_shortlink_entries(entries)
            elif action_idx == 2:
                if dialog.yesno(local_string(30373), f"{local_string(30383)}\n{entry['code']}"):
                    del entries[idx]
                    save_shortlink_entries(entries)


