# -*- coding: utf-8 -*-
#py3
from resources.lib import kodiutils
from resources.lib import kodilogging
import io
import os
import sys
import time
import zipfile
import urllib
import urllib.request
import logging
import xbmcaddon
import xbmcgui
import xbmc
import xbmcvfs


       
ADDON = xbmcaddon.Addon()
logger = logging.getLogger(ADDON.getAddonInfo('id'))


class Canceled(Exception):
    pass


class MyProgressDialog():
    def __init__(self, process):
        self.dp = xbmcgui.DialogProgress()
        self.dp.create("","".join((process,' bitte warten.....')))

    def __call__(self, block_num, block_size, total_size):
        if self.dp.iscanceled():
            self.dp.close()
            raise Canceled
        percent = (block_num * block_size * 100) / total_size
        if percent < total_size:
            self.dp.update(int(percent))
        else:
            self.dp.close()

def exists(path):
    try:
        f = urllib.request.urlopen(path).getcode()
        return True
    except:
        return False


def read(response, progress_dialog):
    data = b""
    total_size = response.getheader('Content-Length').strip()
    total_size = int(total_size)
    bytes_so_far = 0
    chunk_size = 1024 * 1024
    reader = lambda: response.read(chunk_size)
    for index, chunk in enumerate(iter(reader, b"")):
        data += chunk
        progress_dialog(index, chunk_size, total_size)
    return data


def extract(zip_file, output_directory, progress_dialog):
    zin = zipfile.ZipFile(zip_file)
    files_number = len(zin.infolist())
    for index, item in enumerate(zin.infolist()):
        try:
            progress_dialog(index, 1, files_number)
        except Canceled:
            return False
        else:
            zin.extract(item, output_directory)
    return True


def get_build_kb():
    addon_name = ADDON.getAddonInfo('name')
    build = "build-name"

    bundle_url = xbmcgui.Dialog().input("Bitte Bundle-URL eingeben:")

    url_patterns = [f'https://tinyurl.com/{bundle_url}', f'https://bitly.com/{bundle_url}', f'https://t1p.de/{bundle_url}']
    full_url = None
       #Edit By Thunderv3
    for url in url_patterns:
        if exists(url):
            full_url = url
            break
            
    if not full_url:
        xbmcgui.Dialog().ok('', 'Keine URL eingegeben. Beende...')
        os._exit(0)
       
    if not exists(full_url):
        xbmcgui.Dialog().ok('', 'Aktuell leider nicht verfügbar. :(')
        os._exit(0)

    try:
        response = urllib.request.urlopen(full_url)
        data = read(response, MyProgressDialog("wird heruntergeladen..."))
        
    except Exception as e:
        xbmcgui.Dialog().ok('', 'Aktuell leider nicht verfügbar. :(')
        os._exit(0)

    try:
        addon_folder = xbmcvfs.translatePath(os.path.join('special://', 'home'))
        if extract(io.BytesIO(data), addon_folder, MyProgressDialog("Installation ...")):
            xbmc.sleep(3000)
        else:
            xbmcgui.Dialog().ok('', "Die Installation wurde abgebrochen );.....")
    except Canceled:
        os._exit(0)

    xbmcgui.Dialog().ok('', "Installation erfolgreich abgeschlossen...")
    d = open(os.path.join(xbmcvfs.translatePath('special://home'), 'build_installed'), "w")
    d.write(str(build))
    d.close()
    xbmc.sleep(3000)
    os._exit(0)