# -*- coding: utf-8 -*-

#from resources.lib import kodilogging
from resources.lib import script
import os
import logging
import xbmcaddon
import xbmcvfs
# Keep this file to a minimum, as Kodi
# doesn't keep a compiled copy of this
ADDON = xbmcaddon.Addon()
#kodilogging.config()

if os.path.exists(os.path.join(xbmcvfs.translatePath('special://home'), 'build_installed')):
    pass
else: 
    script.get_build_kb()