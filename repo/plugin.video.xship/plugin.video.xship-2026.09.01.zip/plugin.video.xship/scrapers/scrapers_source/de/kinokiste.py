
# kinokiste
# 2026-04-10

import json
import time
import re
from concurrent.futures import ThreadPoolExecutor, as_completed, TimeoutError as FutureTimeoutError
from urllib.parse import quote_plus
from scrapers.modules import cleantitle
from resources.lib.utils import isBlockedHoster
from resources.lib.control import getSetting
from resources.lib.requestHandler import cRequestHandler
from resources.lib import log_utils

SITE_IDENTIFIER = 'kinokiste'
SITE_DOMAIN = 'kinokiste.club'
SITE_NAME       = SITE_IDENTIFIER.upper()

# Kinokiste/Cloudflare bindet Sitzungs-Cookies häufig an den User-Agent.
# Deshalb innerhalb dieses Scrapers einen stabilen Browser-Header verwenden,
# statt bei jeder cRequestHandler-Instanz einen zufälligen UA zu senden.
SESSION_USER_AGENT = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
    'AppleWebKit/537.36 (KHTML, like Gecko) '
    'Chrome/137.0.0.0 Safari/537.36'
)


_REQUEST_ERROR_MARKERS = (
    'CLOUDFLARE-SCHUTZ AKTIV',
    'DDOS GUARD SCHUTZ',
    'SEITE NICHT ERREICHBAR',
    'URL FEHLER',
    'TIMEOUT',
)


def _klog(message, level=log_utils.LOGDEBUG):
    # Aufgeräumter Produktionslog: nur Warnungen und Fehler.
    if level in (log_utils.LOGWARNING, log_utils.LOGERROR, log_utils.LOGFATAL):
        log_utils.log(message, level)



def _hoster_limit_settings():
    """Liest das vorhandene xShip-Hosterlimit."""
    enabled = str(getSetting('hosts.limit', 'false')).strip().lower() in (
        'true', '1', 'yes', 'on'
    )
    try:
        limit = max(1, int(float(getSetting('hosts.limit.num', '15'))))
    except (TypeError, ValueError):
        limit = 15
    return enabled, limit

class source:
    def __init__(self):
        self.priority  = 1
        self.language  = ['de']
        # Kodi-Enum liefert den gewählten Index. Bereits gespeicherte
        # Domaintexte älterer Installationen werden weiterhin unterstützt.
        domain_setting = getSetting('provider.' + SITE_IDENTIFIER + '.domain', '0')
        domain_options = {
            '0': 'kinokiste.club',
            '1': 'kinokiste.eu',
        }
        selected = domain_options.get(
            str(domain_setting).strip(),
            str(domain_setting).strip()
        )
        selected = selected.replace('https://', '').replace('http://', '').strip().strip('/')
        self.domain = selected or SITE_DOMAIN
        self.base_link = 'https://' + self.domain
        self.sources   = []

    def _fetch(self, url, timeout=3, caching=True):
        """Ruft die Kinokiste-API mit stabiler Sitzung und einem Retry ab.

        Der globale RequestHandler liefert Netzwerk-/Cloudflare-Fehler als
        Text zurück. Diese Texte dürfen nicht als JSON weiterverarbeitet werden.
        Bei einem solchen Fehler wird ausschließlich der Kinokiste-Opener
        verworfen und die Anfrage genau einmal mit einer frischen Sitzung
        wiederholt. Andere Provider bleiben davon unberührt.
        """
        def _request_once(use_cache):
            oRequest = cRequestHandler(url, caching=use_cache)
            oRequest.requestTimeout = max(1, int(timeout))
            oRequest.cacheTime = 60 * 60 * 6
            oRequest.addHeaderEntry('User-Agent',       SESSION_USER_AGENT)
            oRequest.addHeaderEntry('Origin',           self.base_link)
            oRequest.addHeaderEntry('Referer',          self.base_link + '/')
            oRequest.addHeaderEntry('Accept',           'application/json, text/plain, */*')
            oRequest.addHeaderEntry('Accept-Language',  'de-DE,de;q=0.9,en-US;q=0.8,en;q=0.7')
            oRequest.addHeaderEntry('X-Requested-With', 'XMLHttpRequest')
            return oRequest.request()

        try:
            result = _request_once(caching)
            if result not in _REQUEST_ERROR_MARKERS:
                return result

            _klog('[%s] Request fehlgeschlagen (%s), Sitzung wird einmal erneuert' %
                  (SITE_NAME, result), log_utils.LOGWARNING)

            # Nur den Opener dieser Kinokiste-Domain zurücksetzen. Der Cookie-
            # Speicher auf der Festplatte bleibt erhalten und kann beim neuen
            # Opener wieder eingelesen werden. Beim Retry Cache umgehen, damit
            # keine Fehlerantwort aus einem alten Eintrag zurückkommt.
            cRequestHandler.persistent_openers.pop(self.domain, None)
            retry_result = _request_once(False)
            if retry_result in _REQUEST_ERROR_MARKERS:
                _klog('[%s] Request auch nach Sitzungsneustart fehlgeschlagen: %s' %
                      (SITE_NAME, retry_result), log_utils.LOGWARNING)
                return ''
            return retry_result
        except Exception as exc:
            _klog('[%s] Request-Ausnahme: %s' % (SITE_NAME, str(exc)[:180]),
                  log_utils.LOGWARNING)
            return ''

    PAGE_SIZE = 100
    MAX_INPUT_STREAMS_TO_SCAN = 100
    MAX_SOURCES_PER_SCRAPER = 8
    MAX_PROCESS_SECONDS = 10
    MAX_FALLBACK_PAGES = 2
    MAX_SEARCH_SECONDS = 10
    MAX_SLUG_VARIANTS = 5
    MAX_KEYWORD_QUERIES = 2
    MAX_WATCH_PAGE_PROBES = 4
    MAX_SERIES_API_QUERIES = 4
    MAX_SERIES_CATALOG_PAGES = 3
    MAX_SERIES_TITLE_QUERIES = 4

    @staticmethod
    def _movies_from_json(data):
        if not data:
            return []
        try:
            obj = json.loads(data)
        except Exception:
            return []
        if isinstance(obj, list):
            return obj
        if not isinstance(obj, dict):
            return []
        for key in ('movies', 'results', 'items', 'data'):
            value = obj.get(key)
            if isinstance(value, list):
                return value
            if isinstance(value, dict):
                for subkey in ('movies', 'results', 'items'):
                    nested = value.get(subkey)
                    if isinstance(nested, list):
                        return nested
        return []

    @staticmethod
    def _slug(value):
        # Kompatibler Einzel-Slug fuer bestehenden Code. Anders als
        # cleantitle.get() bleiben Wortgrenzen erhalten.
        raw = str(value or '').strip().lower()
        raw = raw.replace('&', ' and ')
        raw = re.sub(r'[^a-z0-9]+', '-', raw).strip('-')
        return raw

    @staticmethod
    def _series_title_variants(title, season):
        """Gezielte Kinokiste-Varianten für eigenständige Staffel-Datensätze."""
        base = str(title or '').strip()
        try:
            s = int(season)
        except Exception:
            s = 0

        if not base or s <= 0:
            return []

        variants = [
            '%s Staffel %d' % (base, s),
            '%s - Staffel %d' % (base, s),
            '%s Season %d' % (base, s),
            '%s S%02d' % (base, s),
        ]

        result = []
        seen = set()
        for item in variants:
            key = cleantitle.get(item)
            if not key or key in seen:
                continue
            seen.add(key)
            result.append(item)
        return result

    @staticmethod
    def _keyword_variants(value):
        """Erzeugt wenige robuste Varianten fuer die Kinokiste-keyword-Suche."""
        raw = str(value or '').strip()
        if not raw:
            return []

        variants = [raw]

        # Satzzeichen als Worttrenner: "Spider-Man" -> "Spider Man".
        spaced = re.sub(r'[-–—_:./\\]+', ' ', raw)
        spaced = re.sub(r'\s+', ' ', spaced).strip()
        if spaced:
            variants.append(spaced)

        # Titel mit "&" zusätzlich in verbreiteten Schreibweisen testen.
        if '&' in raw:
            and_variant = re.sub(r'\s*&\s*', ' and ', raw)
            and_variant = re.sub(r'\s+', ' ', and_variant).strip()
            if and_variant:
                variants.append(and_variant)

            no_amp = re.sub(r'\s*&\s*', ' ', raw)
            no_amp = re.sub(r'\s+', ' ', no_amp).strip()
            if no_amp:
                variants.append(no_amp)

        # Kompakte Form: "Spider-Man" -> "spiderman".
        compact = cleantitle.get(raw)
        if compact:
            variants.append(compact)

        # Fortsetzungsnummern: Bei Titeln wie "Toy Story 5" kann die API mit
        # dem vollständigen Titel zu eng filtern. Zusätzlich den Basistitel
        # abfragen. Akzeptiert wird später weiterhin nur ein exakter Titel-/
        # Jahr-Treffer, daher kann z. B. "Toy Story 4" nicht durchrutschen.
        sequel = re.match(r'^(.*?)[\s._:-]+(\d{1,2})\s*$', raw)
        if sequel:
            base_title = sequel.group(1).strip(' -–—_:./\\')
            if base_title:
                variants.append(base_title)

        result = []
        seen = set()
        for item in variants:
            item = str(item or '').strip()
            key = item.lower()
            if not item or key in seen:
                continue
            seen.add(key)
            result.append(item)
        return result

    @classmethod
    def _slug_variants(cls, value, year='', season=0):
        """Erzeugt wenige, gezielte URL-Varianten ohne grossen Katalogscan.

        Kinokiste verwendet je nach Datensatz Bindestriche, kompakte Slugs oder
        Staffelzusätze. Die Reihenfolge bevorzugt den normalen Web-Slug.
        """
        raw = str(value or '').strip().lower()
        if not raw:
            return []

        hyphen = cls._slug(raw)
        compact = cleantitle.get(raw)
        underscore = hyphen.replace('-', '_') if hyphen else ''
        variants = [hyphen, compact, underscore]

        # Jahres- und Staffelvarianten nur ergänzen, wenn noch Platz ist.
        if hyphen and year:
            variants.append('%s-%s' % (hyphen, str(year).strip()))
        if hyphen and season:
            variants.extend([
                '%s-staffel-%s' % (hyphen, int(season)),
                '%s-season-%s' % (hyphen, int(season)),
                '%s-s%02d' % (hyphen, int(season)),
            ])

        # Bei langen Mehrworttiteln kann eine gebräuchliche Abkürzung helfen,
        # ohne zusätzliche Netzlast zu verursachen.
        words = re.findall(r'[a-z0-9]+', raw)
        if len(words) >= 3:
            acronym = ''.join(word[0] for word in words if word)
            if len(acronym) >= 3:
                variants.append(acronym)

        result = []
        seen = set()
        for item in variants:
            item = str(item or '').strip('-_ ')
            if not item or item in seen:
                continue
            seen.add(item)
            result.append(item)
            if len(result) >= cls.MAX_SLUG_VARIANTS:
                break
        return result

    @staticmethod
    def _extract_watch_id(html, slug=''):
        """Extrahiert eine Kinokiste-ID aus einer erreichbaren Watch-Seite."""
        data = str(html or '')
        if not data:
            return ''

        patterns = [
            r'["\']_id["\']\s*[:=]\s*["\']([a-fA-F0-9]{24})["\']',
            r'["\']id["\']\s*[:=]\s*["\']([a-fA-F0-9]{24})["\']',
            r'/watch/[^"\'>\s]+/([a-fA-F0-9]{24})(?:["\'/?#<\s]|$)',
            r'\b([a-fA-F0-9]{24})\b',
        ]
        for pattern in patterns:
            match = re.search(pattern, data, re.I)
            if match:
                return match.group(1)
        return ''

    def _watch_page_fallback(self, titles, year='', deadline=None, season=0):
        """Versucht die öffentliche Watch-Seite, wenn die Daten-API blockiert ist.

        Die Film-ID wird nur aus einer tatsächlich erreichbaren Watch-Seite
        extrahiert. Es gibt keinen lokalen ID-Cache und keine fest verdrahteten IDs.
        """
        if deadline is None:
            deadline = time.time() + self.MAX_SEARCH_SECONDS

        slugs = []
        seen = set()
        for title in titles:
            for slug in self._slug_variants(title, year=year, season=season):
                # Jahresvarianten sind für öffentliche /watch/-URLs meist ungeeignet.
                if year and slug.endswith('-' + str(year).strip()):
                    continue
                key = slug.lower()
                if not slug or key in seen:
                    continue
                seen.add(key)
                slugs.append(slug)
                if len(slugs) >= self.MAX_WATCH_PAGE_PROBES:
                    break
            if len(slugs) >= self.MAX_WATCH_PAGE_PROBES:
                break

        for slug in slugs:
            if (deadline - time.time()) <= 0.6:
                break
            # Zuerst ohne ID. Einige Installationen leiten auf die kanonische
            # Watch-Seite um bzw. betten die ID bereits im HTML ein.
            for suffix in ('', '/'):
                if (deadline - time.time()) <= 0.6:
                    break
                url = self.base_link + '/watch/' + quote_plus(slug) + suffix
                html = self._fetch(url, timeout=2, caching=False)
                movie_id = self._extract_watch_id(html, slug)
                _klog('[%s] DIAG watch slug="%s" response=%s id=%s' %
                      (SITE_NAME, slug, 'OK' if html else 'LEER', movie_id or '-'),
                      log_utils.LOGWARNING)
                if movie_id:
                    _klog('[%s] Watch-Seiten-Fallback: slug=%s _id=%s' %
                          (SITE_NAME, slug, movie_id), log_utils.LOGINFO)
                    return movie_id
        return ''

    def _search_series(self, titles, season, originaltitle='', deadline=None):
        """Seriensuche nach dem funktionierenden Kinokiste-Suchprinzip.

        Ablauf:
          /data/browse/?lang=2&keyword=<Titel>&page=1
          -> Treffer "Serientitel - Staffel X"
          -> passende _id
          -> /data/watch/?_id=...
        """
        if deadline is None:
            deadline = time.time() + self.MAX_SEARCH_SECONDS

        try:
            wanted_season = int(season)
        except Exception:
            return []

        # Kinokiste sucht mit dem normalen Suchtext. Den unveränderten
        # originaltitle bevorzugen; Kurz-Aliase wie bb/brba ignorieren.
        search_terms = []
        seen = set()

        canonical = str(originaltitle or '').strip()
        if canonical:
            # Wenn xShip einen echten Originaltitel kennt, exakt nur diesen
            # verwenden. Dadurch entfallen unzuverlässige Alias-Suchen wie
            # "brba", ohne kurze echte Titel wie "FROM" auszuschließen.
            search_terms.append(canonical)
        else:
            # Nur ohne Originaltitel auf den ersten brauchbaren Haupttitel
            # zurückfallen. Keine Acronym-/Alias-Kaskade.
            for raw in titles:
                value = str(raw or '').strip()
                if not value:
                    continue
                key = value.casefold()
                if key in seen:
                    continue
                seen.add(key)
                search_terms.append(value)
                break

        expected_titles = {
            cleantitle.get(str(value or '').strip())
            for value in ([originaltitle] + list(titles or []))
            if value and len(str(value).strip()) >= 4
        }

        for term in search_terms[:1]:
            if time.time() >= deadline:
                break

            # Kinokiste-Suchweg: lang=2, keyword, page=1, kein type=tvseries.
            url = (
                self.base_link +
                '/data/browse/?lang=2&keyword=%s&page=1' %
                quote_plus(term)
            )

            raw = self._fetch(url, timeout=3, caching=False)
            movies = self._movies_from_json(raw)

            # Suchergebnisse werden auf 16 gültige Einträge.
            movies = [
                item for item in movies
                if isinstance(item, dict) and item.get('_id')
            ][:16]

            _klog('[%s] Seriensuche keyword="%s": response=%s kandidaten=%d' %
                  (SITE_NAME, term, 'OK' if raw else 'LEER', len(movies)),
                  log_utils.LOGWARNING)

            for movie in movies:
                title = str(movie.get('title', '') or '').strip()
                if not title:
                    continue

                # Kinokiste erkennt Serien anhand "Staffel"/"Season" im Titel.
                match = re.search(
                    r'(?i)\s*[-–—:]?\s*(?:staffel|season)\s*0*(\d+)\s*$',
                    title
                )
                if not match:
                    # Zusätzlich vorhandenes s-Feld akzeptieren, falls der
                    # Titel selbst keinen Staffelzusatz enthält.
                    item_season = movie.get('s', '')
                    if item_season in ('', None, 0, '0'):
                        continue
                    base_title = title
                else:
                    item_season = movie.get('s', '') or match.group(1)
                    base_title = title[:match.start()].strip(' -–—:')

                if not self._same_number(item_season, wanted_season):
                    continue

                base_clean = cleantitle.get(base_title)
                if expected_titles and base_clean not in expected_titles:
                    continue

                _klog('[%s] Staffeltreffer: "%s" Staffel=%s _id=%s' %
                      (SITE_NAME, title, item_season, movie.get('_id')),
                      log_utils.LOGWARNING)
                return [movie]

        return []

    def _search_series_catalog_fallback(self, titles, season, originaltitle='', deadline=None):
        """Kleiner tvseries-Katalog-Fallback nur wenn die Keyword-Suche leer bleibt."""
        if deadline is None:
            deadline = time.time() + self.MAX_SEARCH_SECONDS

        try:
            wanted_season = int(season)
        except Exception:
            return []

        expected_titles = {
            cleantitle.get(str(v or '').strip())
            for v in ([originaltitle] + list(titles or []))
            if v
        }

        previous_signature = None

        for page in range(1, self.MAX_SERIES_CATALOG_PAGES + 1):
            if time.time() >= deadline:
                break

            url = (
                self.base_link +
                '/data/browse/?lang=2&order_by=new&page=%d&limit=100&type=tvseries' %
                page
            )
            raw = self._fetch(url, timeout=2, caching=True)
            movies = self._movies_from_json(raw)

            _klog('[%s] Katalog-Fallback Seite %d: %d Kandidaten' %
                  (SITE_NAME, page, len(movies)),
                  log_utils.LOGWARNING)

            if not movies:
                break

            signature = tuple(
                str(item.get('_id', '') or '')
                for item in movies[:5] if isinstance(item, dict)
            )
            if signature and signature == previous_signature:
                break
            previous_signature = signature

            for movie in movies:
                if not isinstance(movie, dict):
                    continue

                title = str(movie.get('title', '') or '').strip()
                if not title:
                    continue

                match = re.search(
                    r'(?i)\s*[-–—:]?\s*(?:staffel|season)\s*0*(\d+)\s*$',
                    title
                )
                item_season = movie.get('s', '')
                if match and item_season in ('', None, 0, '0'):
                    item_season = match.group(1)

                if not self._same_number(item_season, wanted_season):
                    continue

                if match:
                    base_title = title[:match.start()].strip(' -–—:')
                else:
                    base_title = title

                base_clean = cleantitle.get(base_title)
                if expected_titles and base_clean not in expected_titles:
                    continue

                if movie.get('_id'):
                    _klog('[%s] Katalog-Staffeltreffer: "%s" Staffel=%s _id=%s' %
                          (SITE_NAME, title, item_season, movie.get('_id')),
                          log_utils.LOGWARNING)
                    return [movie]

        return []

    def _search_api(self, titles, media_type, imdb='', season=0, deadline=None, year=''):
        """Sucht zuerst über den von Kinokiste verwendeten keyword-Parameter.

        Die funktionierende Kinokiste-API filtert Titel über ``keyword`` am
        Browse-Endpunkt. Unscharfe Keyword-Kandidaten beenden die Suche nicht:
        Slug und /data/search/ werden weiter geprüft, bis ein exakter Titel-,
        Jahr- und gegebenenfalls Staffel-Treffer vorliegt. Bei Serien wird die
        IMDb-ID zusätzlich über mehrere gezielte API-Formen versucht; akzeptiert
        wird aber nur eine wirklich passende Staffel.
        """
        if deadline is None:
            deadline = time.time() + self.MAX_SEARCH_SECONDS

        title_values = []
        seen_titles = set()
        for value in titles:
            title = str(value or '').strip()
            key = title.lower()
            if not title or key in seen_titles:
                continue
            seen_titles.add(key)
            title_values.append(title)
            if len(title_values) >= 5:
                break

        seen_items = set()

        def _merge(movies, target):
            for movie in movies:
                if not isinstance(movie, dict):
                    continue
                movie_id = str(movie.get('_id', '') or movie.get('id', '') or '')
                key = movie_id or (
                    str(movie.get('title', '')),
                    str(movie.get('year', '')),
                    str(movie.get('s', '')),
                )
                if key in seen_items:
                    continue
                seen_items.add(key)
                target.append(movie)

        found = []

        if season > 0:
            _klog('[%s] DIAG series-search: keyword ohne type=tvseries, staffel=%s' %
                  (SITE_NAME, season), log_utils.LOGWARNING)

        expected_titles = {cleantitle.get(value) for value in title_values if value}
        try:
            expected_year = int(year)
            expected_years = {str(expected_year - 1), str(expected_year), str(expected_year + 1)}
        except (TypeError, ValueError):
            expected_years = {str(year or '').strip()}

        def _contains_expected(movies):
            """Prüft, ob ein Suchweg bereits einen wirklich passenden Treffer lieferte.

            Kinokiste kann bei ``keyword`` auch allgemeine oder unscharfe
            Kandidaten zurückgeben. Nur bei einem Titel-/Jahr-/Staffel-Treffer
            darf die gestufte Suche vorzeitig enden.
            """
            for movie in movies:
                if not isinstance(movie, dict):
                    continue
                movie_title = str(movie.get('title', '') or '')
                if season > 0:
                    movie_season = movie.get('s', '')
                    base_title = movie_title
                    match = re.search(
                        r'(?i)\s*[-–:]?\s*(?:staffel|season|s)\s*0*(\d+)\s*$',
                        movie_title
                    )
                    if match:
                        base_title = movie_title[:match.start()].strip(' -–:')
                        if movie_season in ('', None):
                            movie_season = match.group(1)
                    if (cleantitle.get(base_title) in expected_titles and
                            self._same_number(movie_season, season)):
                        return True
                else:
                    movie_year = str(movie.get('year', '') or '')
                    if (cleantitle.get(movie_title) in expected_titles and
                            (not expected_years or movie_year in expected_years)):
                        return True
            return False

        # Serien zuerst gezielt über IMDb/API suchen. Mehrere kleine
        # Abfragen laufen parallel, damit die Suche kurz bleibt.
        if season > 0 and imdb and (deadline - time.time()) > 0.8:
            imdb_value = str(imdb or '').strip()
            series_urls = [
                self.base_link + '/data/search/?q=%s&type=tvseries' %
                quote_plus(imdb_value),
                self.base_link + '/data/search/?query=%s&type=tvseries' %
                quote_plus(imdb_value),
                self.base_link + '/data/search/?search=%s&type=tvseries' %
                quote_plus(imdb_value),
                self.base_link +
                '/data/browse/?lang=all&order_by=new&page=1&limit=100&type=tvseries&search=%s' %
                quote_plus(imdb_value),
            ][:self.MAX_SERIES_API_QUERIES]

            pool = ThreadPoolExecutor(max_workers=len(series_urls))
            futures = {
                pool.submit(self._fetch, url, 2, False): url
                for url in series_urls
            }
            package_deadline = min(deadline, time.time() + 2.8)
            try:
                pending = set(futures)
                while pending and time.time() < package_deadline:
                    wait_for = max(0.05, package_deadline - time.time())
                    try:
                        future = next(as_completed(pending, timeout=wait_for))
                    except FutureTimeoutError:
                        break
                    pending.discard(future)
                    url = futures[future]
                    try:
                        raw_series = future.result()
                        series_movies = self._movies_from_json(raw_series)
                    except Exception:
                        raw_series = ''
                        series_movies = []

                    _klog('[%s] DIAG series-api "%s": response=%s kandidaten=%d' %
                          (SITE_NAME, url.split('/data/', 1)[-1],
                           'OK' if raw_series else 'LEER', len(series_movies)),
                          log_utils.LOGWARNING)

                    _merge(series_movies, found)
                    if _contains_expected(found):
                        for item in pending:
                            item.cancel()
                        return found

                for item in pending:
                    item.cancel()
            finally:
                pool.shutdown(wait=False)

        # Serien: Kinokiste führt Staffeln als eigenständige Datensätze
        # wie "Breaking Bad - Staffel 2". Deshalb vor der allgemeinen Suche
        # gezielt nach solchen Staffel-Titeln fragen.
        if season > 0 and title_values and (deadline - time.time()) > 0.8:
            main_title = str(title_values[0] or '').strip()
            series_terms = self._series_title_variants(main_title, season)[
                :self.MAX_SERIES_TITLE_QUERIES
            ]

            for term in series_terms:
                if (deadline - time.time()) <= 0.6:
                    break

                url = (self.base_link +
                       '/data/browse/?lang=all&keyword=%s&page=1&limit=40' %
                       quote_plus(term))
                raw_series_title = self._fetch(url, timeout=2, caching=False)
                series_title_movies = self._movies_from_json(raw_series_title)

                _klog('[%s] DIAG series-title "%s": response=%s kandidaten=%d' %
                      (SITE_NAME, term,
                       'OK' if raw_series_title else 'LEER',
                       len(series_title_movies)),
                      log_utils.LOGWARNING)

                _merge(series_title_movies, found)
                if _contains_expected(found):
                    return found

        # 1) Offizieller Kinokiste-Suchweg: Browse-API mit keyword.
        # Die Kinokiste-API uebernimmt die serverseitige Titelsuche. Statt viele
        # kuenstliche Schreibvarianten zu erzeugen, werden nur die ersten ein bis
        # zwei echten Titel aus xShip abgefragt. Pro Antwort werden maximal 16
        # Kandidaten ausgewertet, analog zur funktionierenden Kinokiste-Variante.
        keyword_terms = []
        keyword_seen = set()
        keyword_limit = 1 if season > 0 else self.MAX_KEYWORD_QUERIES
        for title in title_values:
            term = str(title or '').strip()
            key = term.lower()
            if not term or key in keyword_seen:
                continue
            keyword_seen.add(key)
            keyword_terms.append(term)
            if len(keyword_terms) >= keyword_limit:
                break

        for term in keyword_terms:
            if (deadline - time.time()) <= 0.6:
                break

            if season > 0:
                # Die funktionierende Kinokiste-Referenz sucht Serien ohne
                # type=tvseries und erkennt Staffel-Datensaetze erst in den
                # gelieferten Treffern.
                url = (self.base_link +
                       '/data/browse/?lang=all&keyword=%s&page=1&limit=40' %
                       quote_plus(term))
            else:
                url = (self.base_link +
                       '/data/browse/?lang=all&keyword=%s&page=1&limit=40&type=%s' %
                       (quote_plus(term), media_type))
            raw = self._fetch(url, timeout=2, caching=False)
            movies = self._movies_from_json(raw)

            movies = [
                movie for movie in movies
                if isinstance(movie, dict) and ('_id' in movie or 'id' in movie)
            ][:16]

            _klog('[%s] DIAG keyword="%s" response=%s kandidaten=%d' %
                  (SITE_NAME, term, 'OK' if raw else 'LEER', len(movies)),
                  log_utils.LOGWARNING)

            _merge(movies, found)
            if _contains_expected(found):
                return found

        # Serien bekommen keinen langsamen Slug-/Watch-Fallback. Nach IMDb/API
        # und keyword wird die Trefferliste an run() zurückgegeben; dort folgt
        # höchstens ein kleiner tvseries-Katalogcheck.
        if season > 0:
            _klog('[%s] Serien-API/Staffeltitel/keyword ohne Staffel-Treffer; kleiner Katalog-Fallback folgt' %
                  SITE_NAME, log_utils.LOGWARNING)
            return found

        # 2) Kleine parallele Slug-Probe als Rückfall.
        slug_jobs = []
        seen_slugs = set()
        for title in title_values[:2]:
            for slug in self._slug_variants(title, year=year, season=season):
                if slug in seen_slugs:
                    continue
                seen_slugs.add(slug)
                if season > 0:
                    slug_url = (self.base_link +
                                '/data/browse/?lang=all&slug=%s&page=1&limit=40' %
                                quote_plus(slug))
                else:
                    slug_url = (self.base_link +
                                '/data/browse/?lang=all&type=%s&slug=%s&page=1&limit=40' %
                                (media_type, quote_plus(slug)))
                slug_jobs.append((slug, slug_url))
                if len(slug_jobs) >= 3:
                    break
            if len(slug_jobs) >= 3:
                break

        if slug_jobs and time.time() < deadline:
            pool = ThreadPoolExecutor(max_workers=min(3, len(slug_jobs)))
            future_map = {
                pool.submit(self._fetch, url, 2, False): slug
                for slug, url in slug_jobs
            }
            package_deadline = min(deadline, time.time() + 2.6)
            try:
                pending = set(future_map)
                # Wichtig: ``found`` kann bereits unpassende Kandidaten aus der
                # Keyword-Suche enthalten. Deshalb die Slug-Antworten trotzdem
                # auswerten und nur bei einem wirklich passenden Titel/Jahr-
                # Treffer vorzeitig beenden.
                while pending and time.time() < package_deadline:
                    wait_for = max(0.05, package_deadline - time.time())
                    try:
                        future = next(as_completed(pending, timeout=wait_for))
                    except FutureTimeoutError:
                        break
                    pending.discard(future)
                    slug = future_map[future]
                    try:
                        raw_slug = future.result()
                        movies = self._movies_from_json(raw_slug)
                    except Exception:
                        raw_slug = ''
                        movies = []
                    _klog('[%s] DIAG slug="%s" response=%s kandidaten=%d' %
                          (SITE_NAME, slug, 'OK' if raw_slug else 'LEER', len(movies)),
                          log_utils.LOGWARNING)
                    _merge(movies, found)
                    if _contains_expected(found):
                        break
                for future in pending:
                    future.cancel()
            finally:
                pool.shutdown(wait=False)
            if _contains_expected(found):
                return found

        # 3) Alter /data/search/-Weg als letzter gezielter Titel-Rückfall.
        if title_values and time.time() < deadline:
            title = title_values[0]
            if season > 0:
                url = self.base_link + '/data/search/?q=%s' % quote_plus(title)
            else:
                url = self.base_link + '/data/search/?q=%s&type=%s' % (
                    quote_plus(title), media_type)
            raw = self._fetch(url, timeout=2, caching=False)
            movies = self._movies_from_json(raw)
            _klog('[%s] DIAG data/search title="%s" response=%s kandidaten=%d' %
                  (SITE_NAME, title, 'OK' if raw else 'LEER', len(movies)),
                  log_utils.LOGWARNING)
            _merge(movies, found)

        return found


    def _load_page(self, page, media_type):
        url = self.base_link + '/data/browse/?lang=all&order_by=new&page=%d&limit=%d&type=%s' % (
            page, self.PAGE_SIZE, media_type)
        movies = self._movies_from_json(self._fetch(url, timeout=2, caching=True))
        _klog('[%s] Fallback-Seite %d: %d Eintraege' % (SITE_NAME, page, len(movies)), log_utils.LOGINFO)
        return movies


    @staticmethod
    def _quality(release, resolution=''):
        """Normalisiert Aufloesung/Release auf xShip-Qualitaetswerte.

        Aufnahmearten wie TS/CAM haben Vorrang vor einer enthaltenen Zahl. Ein
        Release wie ``TELESYNC.1080p`` ist daher kein echter 1080p-Webstream.
        """
        r = ('%s %s' % (resolution or '', release or '')).upper()
        compact = re.sub(r'[^A-Z0-9]+', ' ', r)
        tokens = set(compact.split())

        if 'TELESYNC' in compact or 'TS' in tokens:
            return 'TS'
        if 'CAM' in tokens or 'HDCAM' in compact:
            return 'CAM'
        if '4K' in tokens or '2160' in compact:
            return '4K'
        if '1440' in compact:
            return '1440p'
        if '1080' in compact:
            return '1080p'
        if '720' in compact:
            return '720p'
        if 'HD' in tokens or 'WEB' in tokens or 'WEBDL' in compact or 'BLURAY' in compact or 'BRRIP' in compact:
            return 'HD'
        if 'SD' in tokens or '480' in compact:
            return 'SD'
        return 'SD'

    @classmethod
    def _stream_priority(cls, stream):
        """Sortierwert: echte hohe Aufloesungen vor HD/SD und TS/CAM."""
        if not isinstance(stream, dict):
            return -1
        quality = cls._quality(stream.get('release', ''), stream.get('res', ''))
        return {
            '4K': 70,
            '1440p': 65,
            '1080p': 60,
            '720p': 50,
            'HD': 40,
            'SD': 30,
            'TS': 10,
            'CAM': 0,
        }.get(quality, 20)

    @staticmethod
    def _release_info(release, quality):
        """Behält aussagekräftige Releaseinfos getrennt von der Qualität."""
        text = str(release or '').strip()
        if not text:
            return ''
        # Reine Qualitätsangaben nicht doppelt anzeigen.
        compact = text.upper().replace(' ', '')
        simple = {
            '4K', '2160P', '1440P', '1080P', '720P', 'HD', 'SD',
            'TS', 'CAM', 'TELESYNC', 'WEB', 'WEB-DL', 'BLURAY', 'BRRIP'
        }
        if compact in {x.replace(' ', '') for x in simple}:
            return ''
        return text

    @staticmethod
    def _same_number(value, expected):
        """Vergleicht Staffel/Episode robust (1, "1", "01", 1.0)."""
        try:
            return int(float(str(value).strip())) == int(float(str(expected).strip()))
        except (TypeError, ValueError):
            return False

    @staticmethod
    def _host_key(url):
        try:
            from urllib.parse import urlparse
            value = 'https:' + url if str(url).startswith('//') else str(url)
            return (urlparse(value).hostname or '').lower().removeprefix('www.')
        except Exception:
            return str(url or '').lower()

    def _get_streams(self, _id, season=0, episode=0, year=''):
        url  = self.base_link + '/data/watch/?_id=%s' % _id
        data = self._fetch(url)
        if not data:
            return
        try:
            obj = json.loads(data)
        except Exception as exc:
            _klog('[%s] Watch-API ungueltiges JSON fuer _id=%s: %s' % (
                SITE_NAME, _id, str(exc)[:180]), log_utils.LOGWARNING)
            return
        if isinstance(obj, dict) and isinstance(obj.get('movie'), dict):
            obj = obj['movie']
        elif isinstance(obj, dict) and isinstance(obj.get('movies'), list) and obj['movies']:
            obj = obj['movies'][0]
        if not isinstance(obj, dict):
            return

        streams = obj.get('streams', []) if isinstance(obj.get('streams', []), list) else []
        item_season = obj.get('s', 0)
        is_tv = str(obj.get('tv', 0)) == '1' or bool(item_season)
        _klog('[%s] Watch-API _id=%s: tv=%s staffel=%s %d Streams' % (
            SITE_NAME, _id, obj.get('tv', 0), item_season, len(streams)), log_utils.LOGINFO)

        # Kinokiste speichert Serien pro Staffel. Eine Antwort einer anderen
        # Staffel darf niemals als Treffer fuer die angeforderte Staffel gelten.
        if season > 0:
            if not is_tv:
                _klog('[%s] Watch-API _id=%s verworfen: kein Serien-Datensatz' % (
                    SITE_NAME, _id), log_utils.LOGWARNING)
                return
            if not self._same_number(item_season, season):
                _klog('[%s] Watch-API _id=%s verworfen: Staffel %s statt %s' % (
                    SITE_NAME, _id, item_season, season), log_utils.LOGWARNING)
                return

        # Hoster, die in bisherigen Logs dauerhaft nicht funktionierten.
        _skip = ('playmogo.com', 'dood.re', 'dood.to', 'dood.li', 'doods.pro',
                 'doodstream.com', 'doodstream.co', 'ds2video.com',
                 'streamtape.com', 'streamta.pe', 'strtape.site',
                 'upstream.to', 'mystream.to',
                 'vinovo.to', 'vinovo.com',
                 'veev.to', 'veevcdn',
                 'filemoon.sx',)

        limit_enabled, max_per_hoster = _hoster_limit_settings()
        accepted_before = len(self.sources)
        scan_started = time.time()
        scanned_streams = 0

        if season > 0:
            # Die API liefert Episodennummern gemischt als Zahl und Text.
            stream_pool = [
                item for item in streams
                if isinstance(item, dict) and self._same_number(item.get('e'), episode)
            ]
            episode_streams = stream_pool
        else:
            episode_streams = []
            stream_pool = [item for item in streams if isinstance(item, dict)]

        # Nicht einfach nur die ersten oder letzten 100 API-Eintraege nehmen:
        # Kinokiste gruppiert neue TS-Links oft am Listenende, waehrend echte
        # 1080p-WEB-Links weiter in der Mitte stehen. Zuerst nach der tatsaechlichen
        # Qualitaet sortieren und innerhalb derselben Stufe neuere Eintraege
        # bevorzugen. Das 100er-Prueflimit und das 8-Quellen-Limit bleiben bestehen.
        indexed_streams = list(enumerate(stream_pool))
        indexed_streams.sort(
            key=lambda pair: (self._stream_priority(pair[1]), pair[0]),
            reverse=True
        )
        candidate_streams = [
            item for _, item in indexed_streams[:self.MAX_INPUT_STREAMS_TO_SCAN]
        ]

        quality_counts = {}
        for item in candidate_streams:
            q = self._quality(item.get('release', ''), item.get('res', ''))
            quality_counts[q] = quality_counts.get(q, 0) + 1
        _klog('[%s] Qualitaetsauswahl: Pool=%d Kandidaten=%d Verteilung=%s' % (
            SITE_NAME, len(stream_pool), len(candidate_streams), quality_counts), log_utils.LOGINFO)

        seen_urls = set()
        hoster_count = {}
        prepared = []

        for stream in candidate_streams:
            scanned_streams += 1
            if time.time() - scan_started > self.MAX_PROCESS_SECONDS:
                _klog('[%s] Arbeitslimit erreicht: %ds, %d Kandidaten geprueft' % (
                    SITE_NAME, self.MAX_PROCESS_SECONDS, scanned_streams), log_utils.LOGWARNING)
                break

            sUrl = str(stream.get('stream') or '').strip()
            if not sUrl:
                continue
            if sUrl.startswith('//'):
                sUrl = 'https:' + sUrl
            url_key = sUrl.rstrip('/')
            if url_key in seen_urls:
                continue
            seen_urls.add(url_key)
            if any(blocked in sUrl.lower() for blocked in _skip):
                continue

            host_key = self._host_key(sUrl)
            if limit_enabled:
                hoster_count[host_key] = hoster_count.get(host_key, 0) + 1
                if hoster_count[host_key] > max_per_hoster:
                    continue

            isBlocked, hoster, clean_url, prioHoster = isBlockedHoster(sUrl, isResolve=False)
            if isBlocked or not clean_url:
                continue

            sRelease = stream.get('release', '') or ''
            sResolution = stream.get('res', '') or ''
            prepared.append({
                'source': hoster,
                'quality': self._quality(sRelease, sResolution),
                'language': 'de',
                'url': sUrl,
                'direct': False,
                'prioHoster': prioHoster,
                'info': str(year or '').strip(),
                '_host_key': host_key,
            })

            # Sobald acht unterschiedliche gültige Hoster vorhanden sind,
            # ist das spätere Auswahllimit bereits erfüllt. Weitere API-Einträge
            # würden nur Laufzeit erzeugen, aber keine zusätzlichen sichtbaren
            # Quellen liefern.
            if len({item['_host_key'] for item in prepared}) >= self.MAX_SOURCES_PER_SCRAPER:
                break

        # Runde 1: moeglichst viele verschiedene Hoster. Runde 2: mit weiteren
        # eindeutigen URLs auffuellen, falls weniger als acht Hoster vorhanden sind.
        selected = []
        selected_urls = set()
        selected_hosts = set()
        for item in prepared:
            if item['_host_key'] in selected_hosts:
                continue
            selected.append(item)
            selected_urls.add(item['url'].rstrip('/'))
            selected_hosts.add(item['_host_key'])
            if len(selected) >= self.MAX_SOURCES_PER_SCRAPER:
                break

        if len(selected) < self.MAX_SOURCES_PER_SCRAPER:
            for item in prepared:
                key = item['url'].rstrip('/')
                if key in selected_urls:
                    continue
                selected.append(item)
                selected_urls.add(key)
                if len(selected) >= self.MAX_SOURCES_PER_SCRAPER:
                    break

        for item in selected:
            item.pop('_host_key', None)
            self.sources.append(item)

        if season > 0:
            _klog('[%s] Episode S%02dE%02d: %d passende API-Eintraege, %d Kandidaten, %d Hoster, %d Quellen' % (
                SITE_NAME, int(season), int(episode), len(episode_streams), len(prepared),
                len(selected_hosts), len(self.sources) - accepted_before), log_utils.LOGINFO)
        _klog('[%s] Watch-API verarbeitet: %d Kandidaten geprueft, %d eindeutige URLs, max. %d Quellen' % (
            SITE_NAME, scanned_streams, len(seen_urls), self.MAX_SOURCES_PER_SCRAPER), log_utils.LOGINFO)

    def _check_movies(self, movies, titles_clean, years, season, episode):
        for movie in movies:
            if not isinstance(movie, dict) or '_id' not in movie:
                continue
            sTitle = movie.get('title', '')
            sYear = str(movie.get('year', ''))
            if season > 0:
                # Kinokiste fuehrt jede Staffel als eigenen Treffer, z. B.
                # "Supergirl - Staffel 1". Staffelnummer bevorzugt aus dem
                # JSON-Feld s lesen, ansonsten robust aus dem Titel extrahieren.
                movie_season = movie.get('s', '')
                base = sTitle
                match = re.search(r'(?i)\s*[-–:]?\s*(?:staffel|season|s)\s*0*(\d+)\s*$', sTitle)
                if match:
                    base = sTitle[:match.start()].strip(' -–:')
                    if movie_season in ('', None):
                        movie_season = match.group(1)
                is_tv = str(movie.get('tv', 0)) == '1' or movie_season not in ('', None, 0, '0')
                if (is_tv and cleantitle.get(base) in titles_clean and
                        self._same_number(movie_season, season)):
                    _klog('[%s] Serien-Treffer: "%s" Staffel=%s _id=%s' % (
                        SITE_NAME, sTitle, movie_season, movie['_id']), log_utils.LOGINFO)
                    self._get_streams(str(movie['_id']), season, episode, sYear)
            elif cleantitle.get(sTitle) in titles_clean and sYear in years:
                self._get_streams(str(movie['_id']), year=sYear)
            if self.sources:
                return True
        return False

    def run(self, titles, year, season=0, episode=0, imdb='', hostDict=None, originaltitle=''):
        self.sources = []
        _klog('[%s] run() start: titles=%s originaltitle=%r year=%s season=%s episode=%s imdb=%s' % (
            SITE_NAME, titles, originaltitle, year, season, episode, imdb), log_utils.LOGINFO)
        try:
            titles_clean = set(cleantitle.get(i) for i in set(titles) if i)
            year_int = int(year)
            years = [str(year_int - 1), str(year_int), str(year_int + 1)]
            media_type = 'tvseries' if season > 0 else 'movies'

            search_deadline = time.time() + self.MAX_SEARCH_SECONDS

            # Serien nach dem funktionierenden Kinokiste-Suchprinzip:
            # lang=2 + keyword=<Titel> -> "Titel - Staffel X" -> _id -> watch.
            if season > 0:
                series_movies = self._search_series(
                    titles,
                    season,
                    originaltitle=originaltitle,
                    deadline=search_deadline
                )
                if not series_movies:
                    series_movies = self._search_series_catalog_fallback(
                        titles,
                        season,
                        originaltitle=originaltitle,
                        deadline=search_deadline
                    )

                if not series_movies:
                    _klog('[%s] run() Ende: 0 Quellen (Seriensuche + Katalog ohne Staffeltreffer)' %
                          SITE_NAME, log_utils.LOGWARNING)
                    return self.sources

                series_item = series_movies[0]
                series_id = str(series_item.get('_id', '') or '')
                if not series_id:
                    return self.sources

                self._get_streams(
                    series_id,
                    season=season,
                    episode=episode,
                    year=str(series_item.get('year', '') or year)
                )
                _klog('[%s] run() Ende: %d Quellen (Seriensuche)' %
                      (SITE_NAME, len(self.sources)),
                      log_utils.LOGWARNING)
                return self.sources

            # Filme behalten unverändert die bestehende Suchlogik.
            movies = self._search_api(titles, media_type, imdb, season, search_deadline, year)
            if season > 0 and movies:
                available = []
                for movie in movies:
                    if not isinstance(movie, dict):
                        continue
                    stitle = str(movie.get('title', ''))
                    mseason = movie.get('s', '')
                    match = re.search(r'(?i)(?:staffel|season|s)\s*0*(\d+)\s*$', stitle)
                    if mseason in ('', None) and match:
                        mseason = match.group(1)
                    if mseason not in ('', None, 0, '0'):
                        try:
                            available.append(int(mseason))
                        except Exception:
                            pass
                if available:
                    _klog('[%s] Gefundene Staffeln fuer "%s": %s' % (
                        SITE_NAME, titles[0] if titles else '', sorted(set(available))), log_utils.LOGINFO)

            if movies and self._check_movies(movies, titles_clean, years, season, episode):
                _klog('[%s] run() Ende: %d Quellen (Keyword-Suche)' % (
                    SITE_NAME, len(self.sources)), log_utils.LOGINFO)
                return self.sources

            if season > 0:
                # Letzter Serien-Rückfall: nur wenige tvseries-Katalogseiten.
                previous_signature = None
                for page in range(1, self.MAX_SERIES_CATALOG_PAGES + 1):
                    if time.time() >= search_deadline:
                        break
                    url = (self.base_link +
                           '/data/browse/?lang=all&order_by=new&page=%d&limit=%d&type=tvseries' %
                           (page, self.PAGE_SIZE))
                    catalog_movies = self._movies_from_json(
                        self._fetch(url, timeout=2, caching=True)
                    )
                    _klog('[%s] DIAG Serien-Katalog Seite %d: %d Kandidaten' %
                          (SITE_NAME, page, len(catalog_movies)),
                          log_utils.LOGWARNING)
                    if not catalog_movies:
                        break

                    signature = tuple(
                        str(item.get('_id', ''))
                        for item in catalog_movies[:5]
                        if isinstance(item, dict)
                    )
                    if signature and signature == previous_signature:
                        break
                    previous_signature = signature

                    if self._check_movies(
                            catalog_movies, titles_clean, years, season, episode):
                        _klog('[%s] run() Ende: %d Quellen (Serien-Katalog)' %
                              (SITE_NAME, len(self.sources)), log_utils.LOGINFO)
                        return self.sources

                _klog('[%s] run() Ende: 0 Quellen (Serien-API/Katalog)' %
                      SITE_NAME, log_utils.LOGINFO)
                return self.sources

            # Staffelvarianten und Slugs wurden bereits in der gestuften Suche
            # innerhalb desselben Zeitbudgets geprueft.

            # Wenn die JSON-/Browse-Wege keinen passenden Datensatz liefern
            # (z. B. wegen Cloudflare), die öffentliche Watch-Seite gezielt über
            # die bekannten Slugs probieren. Die extrahierte ID wird anschließend
            # weiterhin über die normale Watch-API verarbeitet.
            if time.time() < search_deadline:
                watch_id = self._watch_page_fallback(
                    titles, year, search_deadline, season=season)
                if watch_id:
                    if season > 0:
                        self._get_streams(
                            watch_id, season=season, episode=episode, year=str(year))
                    else:
                        self._get_streams(watch_id, year=str(year))
                    if self.sources:
                        return self.sources

            # Begrenzter Fallback statt limit=0 / kompletter Katalog.
            previous_signature = None
            for page in range(1, self.MAX_FALLBACK_PAGES + 1):
                if time.time() >= search_deadline:
                    _klog('[%s] Browse-Fallback wegen Suchzeitlimit beendet' % SITE_NAME, log_utils.LOGWARNING)
                    break
                movies = self._load_page(page, media_type)
                if not movies:
                    break
                signature = tuple(str(m.get('_id', '')) for m in movies[:5] if isinstance(m, dict))
                if signature and signature == previous_signature:
                    break
                previous_signature = signature
                if self._check_movies(movies, titles_clean, years, season, episode):
                    break
        except Exception as e:
            _klog('[%s] run() Fehler: %s' % (SITE_NAME, str(e)[:300]), log_utils.LOGWARNING)
        _klog('[%s] run() Ende: %d Quellen' % (SITE_NAME, len(self.sources)), log_utils.LOGINFO)
        return self.sources

    def resolve(self, url):
        return url
