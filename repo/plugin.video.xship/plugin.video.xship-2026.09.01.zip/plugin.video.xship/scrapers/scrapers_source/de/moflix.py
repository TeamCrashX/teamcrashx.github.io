

#2023-07-28
# edit 2024-12-30

import json
from urllib.parse import quote_plus

import xbmc
from resources.lib.requestHandler import cRequestHandler
from scrapers.modules import cleantitle, dom_parser
from resources.lib.control import getSetting, quote
from resources.lib.utils import isBlockedHoster

SITE_IDENTIFIER = 'moflix'
SITE_DOMAIN = 'moflix-stream.xyz'
SITE_NAME = SITE_IDENTIFIER.upper()

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['de']
        self.domain = getSetting('provider.' + SITE_IDENTIFIER + '.domain', SITE_DOMAIN)
        self.base_link = 'https://' + self.domain

        # self.search_link = self.base_link + '/secure/search/%s?type=&limit=8&provider='
        self.search_link = self.base_link + '/api/v1/search/%s?query=%s&limit=8'
        self.sources = []

    def _log(self, message, level=xbmc.LOGINFO):
        try:
            xbmc.log('[MOFLIX] %s' % message, level)
        except Exception:
            pass

    @staticmethod
    def _year_from_result(item):
        value = item.get('year')
        if value not in (None, ''):
            return str(value)[:4]
        release_date = str(item.get('release_date') or '')
        if release_date:
            return release_date.split('-', 1)[0].strip()
        return ''

    @staticmethod
    def _quality(value):
        value = str(value or '').lower()
        if '2160' in value or '4k' in value:
            return '4K'
        if '1440' in value or '2k' in value:
            return '1440p'
        if '1080' in value:
            return '1080p'
        if '720' in value:
            return '720p'
        if '480' in value:
            return '480p'
        return 'SD'

    def _request_json(self, url, referer=None):
        request = cRequestHandler(url, caching=False)
        request.addHeaderEntry('Referer', referer or url)
        raw = request.request() or ''
        try:
            return json.loads(raw)
        except Exception as exc:
            preview = ' '.join(str(raw)[:300].split())
            self._log('Keine JSON-Antwort von %s: %s | %s' % (url, exc, preview), xbmc.LOGWARNING)
            return None

    def run(self, titles, year, season=0, episode=0, imdb='', hostDict=None):
        self.sources = []
        try:
            clean_titles = {cleantitle.get(i) for i in set(titles or []) if i}
            wanted_year = str(year or '')[:4]
            wanted_imdb = str(imdb or '').strip().lower()
            links = []

            for raw_title in titles or []:
                # Moflix erwartet im URL-Pfad %20, im query-Parameter dagegen +.
                path_title = quote(str(raw_title))
                query_title = quote_plus(str(raw_title))
                search_url = self.search_link % (path_title, query_title)

                search_data = self._request_json(search_url, self.base_link + '/')
                if not isinstance(search_data, dict):
                    continue

                results = search_data.get('results') or []
                for item in results:
                    if not isinstance(item, dict):
                        continue
                    if 'person' in str(item.get('model_type', '')).lower():
                        continue

                    is_series = bool(item.get('is_series'))
                    if season == 0 and is_series:
                        continue
                    if season != 0 and not is_series:
                        continue

                    item_imdb = str(item.get('imdb_id') or '').strip().lower()
                    item_title = str(item.get('name') or '')
                    item_year = self._year_from_result(item)
                    imdb_match = bool(wanted_imdb and item_imdb and wanted_imdb == item_imdb)
                    title_match = cleantitle.get(item_title) in clean_titles
                    year_match = not wanted_year or not item_year or wanted_year == item_year

                    if not imdb_match and not (title_match and year_match):
                        continue

                    item_id = item.get('id')
                    if not item_id:
                        continue
                    links.append({'id': str(item_id), 'name': item_title})
                    break

                if links:
                    break

            for link in links:
                item_id = link['id']
                if season == 0:
                    detail_url = self.base_link + '/api/v1/titles/%s?load=images,genres,productionCountries,keywords,videos,primaryVideo,seasons,compactCredits' % item_id
                else:
                    detail_url = self.base_link + '/api/v1/titles/%s/seasons/%s/episodes/%s?load=videos,compactCredits,primaryVideo' % (item_id, season, episode)

                detail_data = self._request_json(detail_url, detail_url)
                if not isinstance(detail_data, dict):
                    continue

                container = detail_data.get('title') if season == 0 else detail_data.get('episode')
                videos = container.get('videos', []) if isinstance(container, dict) else []

                for video in videos:
                    if not isinstance(video, dict):
                        continue
                    source_url = str(video.get('src') or '').strip()
                    source_url_lower = source_url.lower()
                    if not source_url or 'youtube' in source_url_lower:
                        continue

                    # Interne Moflix-Embedseiten nicht an ResolveURL weiterreichen.
                    if any(domain in source_url_lower for domain in (
                        'moflix-stream.link',
                        'moflix-stream.xyz',
                    )):
                        continue

                    # Direkte HLS-/DASH-Medien nicht über ResolveURL schicken.
                    # Signierte URLs enthalten oft Query-Parameter, daher nur den
                    # Pfad vor '?' auswerten.
                    media_path = source_url_lower.split('?', 1)[0]
                    is_direct_media = media_path.endswith(('.m3u8', '.mpd', '.mp4'))

                    if is_direct_media:
                        if media_path.endswith('.m3u8'):
                            hoster = 'DIRECT HLS'
                        elif media_path.endswith('.mpd'):
                            hoster = 'DIRECT DASH'
                        else:
                            hoster = 'DIRECT MP4'

                        self.sources.append({
                            'source': hoster,
                            'quality': self._quality(video.get('quality') or source_url),
                            'language': 'de',
                            'url': source_url,
                            'info': wanted_year,
                            'direct': True,
                            'prioHoster': 0
                        })
                        self._log('Direktstream übernommen: %s [%s]' % (
                            hoster, self._quality(video.get('quality') or source_url)))
                        continue

                    is_blocked, hoster, resolved_url, prio_hoster = isBlockedHoster(source_url)
                    hoster_lower = str(hoster or '').lower()
                    if 'poophq' in hoster_lower:
                        hoster = 'Veev'
                    elif 'moflix-stream.click' in hoster_lower:
                        hoster = 'FileLions'
                    elif 'moflix-stream.day' in hoster_lower:
                        hoster = 'VidGuard'
                    if is_blocked or not resolved_url:
                        continue

                    self.sources.append({
                        'source': hoster,
                        'quality': self._quality(video.get('quality')),
                        'language': 'de',
                        'url': resolved_url,
                        'info': wanted_year,
                        'direct': False,
                        'prioHoster': prio_hoster
                    })

            self._log('run Ende: %d Quellen' % len(self.sources))
            return self.sources
        except Exception as exc:
            self._log('run Fehler: %s' % exc, xbmc.LOGERROR)
            return self.sources

    def resolve(self, url):
        try:
            return url
        except:
            return