# primekiste.py (xShip Quellen-Scraper)
# Speicherarme Suche: direkter API-Suchversuch + Paging-Fallback

import json
import re
import time
from urllib.parse import quote_plus

from scrapers.modules import cleantitle
from resources.lib.utils import isBlockedHoster
from resources.lib.control import getSetting
from resources.lib.requestHandler import cRequestHandler
from resources.lib import log_utils

SITE_IDENTIFIER = 'primekiste'
SITE_DOMAIN = 'primekiste.com'
SITE_NAME = SITE_IDENTIFIER.upper()



def _hoster_limit_settings():
    """Liest das vorhandene xShip-Hosterlimit.

    Bei deaktiviertem Schalter wird kein Limit angewendet. Der Zahlenwert
    stammt aus ``hosts.limit.num`` und wird nur bei aktivem Schalter benutzt.
    """
    enabled = str(getSetting('hosts.limit', 'false')).strip().lower() in (
        'true', '1', 'yes', 'on'
    )
    try:
        limit = max(1, int(float(getSetting('hosts.limit.num', '15'))))
    except (TypeError, ValueError):
        limit = 15
    return enabled, limit


class source:
    PAGE_SIZE = 100
    MAX_PAGES = 10  # stable-fast patch: avoid full-catalog crawl after API miss
    MAX_INPUT_STREAMS_TO_SCAN = 100
    MAX_SOURCES_PER_SCRAPER = 10
    MAX_PROCESS_SECONDS = 10

    # PrimeKiste-only preference. Keep KinoGer/local-relay and all other
    # providers untouched. The PrimeKiste API often returns Vidaraa first,
    # although the same release is mirrored on faster/resolver-friendly hosts.
    HOST_PREFERENCE = {
        'firestream.to': 50,
        'firestream.site': 48,
        'voe.sx': 45,
        'vixeo.io': 40,
        'playmate.to': 35,
        'vidaraa.cc': 10,
        'vidara.so': 8,
        'vidara.to': 8,
        'vidara.fit': 8,
    }

    # xShip sorts prioHoster ascending. Give PrimeKiste mirrors explicit
    # PrimeKiste-only priorities so the preference survives the later global
    # source merge. Unknown hosts keep ResolveURL's original priority.
    HOSTER_PRIORITY = {
        'firestream.to': 10,
        'firestream.site': 10,
        'voe.sx': 20,
        'vixeo.io': 30,
        'playmate.to': 40,
        'vidaraa.cc': 90,
        'vidara.so': 90,
        'vidara.to': 90,
        'vidara.fit': 90,
    }

    def __init__(self):
        self.priority = 1
        self.language = ['de']
        self.domain = getSetting('provider.' + SITE_IDENTIFIER + '.domain', SITE_DOMAIN)
        self.base_link = 'https://' + self.domain
        self.sources = []

    def _fetch(self, url):
        try:
            oRequest = cRequestHandler(url, caching=True)
            oRequest.cacheTime = 60 * 60 * 6
            oRequest.addHeaderEntry('Origin', self.base_link)
            oRequest.addHeaderEntry('Referer', self.base_link + '/')
            oRequest.addHeaderEntry('Accept', 'application/json, text/plain, */*')
            oRequest.addHeaderEntry('Accept-Language', 'de-DE,de;q=0.9,en-US;q=0.8,en;q=0.7')
            oRequest.addHeaderEntry('X-Requested-With', 'XMLHttpRequest')
            return oRequest.request()
        except Exception as e:
            log_utils.log('[%s] _fetch Fehler: %s' % (SITE_NAME, str(e)[:200]), log_utils.LOGWARNING)
            return ''

    @staticmethod
    def _movies_from_json(data):
        if not data:
            return []
        try:
            obj = json.loads(data)
        except Exception:
            return []

        if isinstance(obj, list):
            return obj
        if not isinstance(obj, dict):
            return []

        for key in ('movies', 'results', 'items', 'data'):
            value = obj.get(key)
            if isinstance(value, list):
                return value
            if isinstance(value, dict):
                for subkey in ('movies', 'results', 'items'):
                    nested = value.get(subkey)
                    if isinstance(nested, list):
                        return nested
        return []

    def _search_api(self, titles, imdb=''):
        """Probiert bekannte/übliche Varianten der React-API.

        Nur Antworten mit einer Filmliste werden akzeptiert. Unbekannte oder
        nicht vorhandene Endpunkte sind dadurch harmlos; danach greift Paging.
        """
        terms = []
        if imdb:
            terms.append(imdb)
        terms.extend([title for title in titles if title])

        seen_urls = set()
        candidates = []
        for term in terms:
            q = quote_plus(str(term))
            candidates.extend([
                self.base_link + '/data/search/?q=' + q,
                self.base_link + '/data/search/?query=' + q,
                self.base_link + '/data/search/?search=' + q,
                self.base_link + '/data/browse/?lang=all&order_by=new&page=1&limit=100&search=' + q,
                self.base_link + '/data/browse/?lang=all&order_by=new&page=1&limit=100&q=' + q,
                self.base_link + '/data/browse/?lang=all&order_by=new&page=1&limit=100&query=' + q,
            ])

        for url in candidates:
            if url in seen_urls:
                continue
            seen_urls.add(url)
            data = self._fetch(url)
            movies = self._movies_from_json(data)
            if movies:
                log_utils.log('[%s] API-Suche: %d Kandidaten über %s' % (
                    SITE_NAME, len(movies), url.split('/data/', 1)[-1][:120]), log_utils.LOGINFO)
                return movies

        log_utils.log('[%s] API-Suche ohne verwertbare Treffer; Paging-Fallback' % SITE_NAME,
                      log_utils.LOGINFO)
        return []

    def _load_page(self, page):
        url = self.base_link + '/data/browse/?lang=all&order_by=new&page=%d&limit=%d' % (
            page, self.PAGE_SIZE)
        data = self._fetch(url)
        movies = self._movies_from_json(data)
        log_utils.log('[%s] _load_page: Seite %d, %d Eintraege geladen' % (
            SITE_NAME, page, len(movies)), log_utils.LOGINFO)
        return movies

    @staticmethod
    def _quality(release, resolution=''):
        """Normalisiert Aufloesung und Aufnahmeart.

        TS/CAM haben Vorrang vor Zahlenangaben: ``TELESYNC.1080p`` darf
        nicht als echter 1080p-Stream erscheinen.
        """
        value = ('%s %s' % (resolution or '', release or '')).upper()
        compact = re.sub(r'[^A-Z0-9]+', ' ', value)
        tokens = set(compact.split())

        if 'TELESYNC' in compact or 'TS' in tokens:
            return 'TS'
        if 'CAM' in tokens or 'HDCAM' in compact:
            return 'CAM'
        if '4K' in tokens or '2160' in compact:
            return '4K'
        if '1440' in compact:
            return '1440p'
        if '1080' in compact:
            return '1080p'
        if '720' in compact:
            return '720p'
        if ('HD' in tokens or 'WEB' in tokens or 'WEBDL' in compact or
                'BLURAY' in compact or 'BRRIP' in compact):
            return 'HD'
        if 'SD' in tokens or '480' in compact:
            return 'SD'
        return 'SD'

    @classmethod
    def _stream_priority(cls, stream):
        """Hohe echte Qualitaeten vor HD/SD und erst danach TS/CAM."""
        if not isinstance(stream, dict):
            return -1
        quality = cls._quality(stream.get('release', ''), stream.get('res', ''))
        return {
            '4K': 70,
            '1440p': 65,
            '1080p': 60,
            '720p': 50,
            'HD': 40,
            'SD': 30,
            'TS': 10,
            'CAM': 0,
        }.get(quality, 20)

    @staticmethod
    def _host_key(url):
        try:
            from urllib.parse import urlparse
            return (urlparse(url).hostname or url).lower().removeprefix('www.')
        except Exception:
            return str(url or '').lower()

    @classmethod
    def _host_preference(cls, url):
        host = cls._host_key(url)
        return cls.HOST_PREFERENCE.get(host, 20)

    def _get_streams(self, _id, season=0, episode=0, year=''):
        url = self.base_link + '/data/watch/?_id=%s' % _id
        data = self._fetch(url)
        if not data:
            log_utils.log('[%s] _get_streams: keine Daten fuer _id=%s' % (SITE_NAME, _id),
                          log_utils.LOGWARNING)
            return
        try:
            obj = json.loads(data)
        except Exception as e:
            log_utils.log('[%s] _get_streams JSON-Fehler: %s | Antwort: %s' % (
                SITE_NAME, str(e), data[:200]), log_utils.LOGWARNING)
            return

        item_year = str(obj.get('year', '') or year or '').strip()
        log_utils.log('[%s] PRIORITY-PATCH v2 max10 active' % SITE_NAME, log_utils.LOGINFO)
        log_utils.log('[%s] _get_streams: title="%s" year=%s imdb=%s' % (
            SITE_NAME, obj.get('title', ''), item_year, obj.get('imdb_id', '')), log_utils.LOGINFO)

        streams = obj.get('streams', [])
        if not isinstance(streams, list):
            streams = []
        log_utils.log('[%s] _get_streams: %d Streams in Antwort' % (
            SITE_NAME, len(streams)), log_utils.LOGINFO)

        # PrimeKiste liefert mehrere hundert historische Mirrors. Die API-
        # Reihenfolge mischt hochwertige WEB/HD-Releases mit TS/CAM. Deshalb
        # zuerst den gesamten passenden Pool nach echter Qualitaet sortieren,
        # innerhalb derselben Stufe neuere Eintraege bevorzugen und erst dann
        # das bestehende 100er-Prueflimit anwenden.
        limit_enabled, max_per_hoster = _hoster_limit_settings()
        accepted_before = len(self.sources)
        scan_started = time.time()
        scanned_streams = 0

        if season > 0:
            stream_pool = [
                item for item in streams
                if isinstance(item, dict) and str(item.get('e', '')) == str(episode)
            ]
        else:
            stream_pool = [item for item in streams if isinstance(item, dict)]

        indexed_streams = list(enumerate(stream_pool))
        indexed_streams.sort(
            key=lambda pair: (
                self._stream_priority(pair[1]),
                self._host_preference(pair[1].get('stream', '')),
                -pair[0],
            ),
            reverse=True
        )
        candidate_streams = [
            item for _, item in indexed_streams[:self.MAX_INPUT_STREAMS_TO_SCAN]
        ]

        quality_counts = {}
        for item in candidate_streams:
            quality = self._quality(item.get('release', ''), item.get('res', ''))
            quality_counts[quality] = quality_counts.get(quality, 0) + 1
        log_utils.log('[%s] Qualitaetsauswahl: Pool=%d Kandidaten=%d Verteilung=%s' % (
            SITE_NAME, len(stream_pool), len(candidate_streams), quality_counts), log_utils.LOGINFO)

        seen_urls = set()
        hoster_count = {}
        prepared = []
        rejected_blocked = 0
        rejected_duplicate = 0
        rejected_limit = 0

        for stream in candidate_streams:
            scanned_streams += 1
            if time.time() - scan_started > self.MAX_PROCESS_SECONDS:
                log_utils.log('[%s] Arbeitslimit erreicht: %ds, %d Kandidaten geprueft' % (
                    SITE_NAME, self.MAX_PROCESS_SECONDS, scanned_streams), log_utils.LOGWARNING)
                break

            sUrl = str(stream.get('stream', '') or '').strip()
            if not sUrl:
                continue
            if sUrl.startswith('//'):
                sUrl = 'https:' + sUrl

            url_key = sUrl.rstrip('/')
            if url_key in seen_urls:
                rejected_duplicate += 1
                continue
            seen_urls.add(url_key)

            low_url = sUrl.lower()
            if any(x in low_url for x in (
                    'filmpalast.to/stream/', 'primekiste.com/watch/',
                    self.domain.lower() + '/watch/')):
                continue

            host_key = self._host_key(sUrl)
            if limit_enabled:
                hoster_count[host_key] = hoster_count.get(host_key, 0) + 1
                if hoster_count[host_key] > max_per_hoster:
                    rejected_limit += 1
                    continue

            isBlocked, hoster, clean_url, prioHoster = isBlockedHoster(sUrl, isResolve=False)
            if isBlocked or not clean_url:
                rejected_blocked += 1
                continue

            # PrimeKiste-only host order. Lower prioHoster is sorted first by
            # xShip. Do not touch unknown hosts or any other provider.
            # Apply the final priority from the actual URL host here, where
            # the source dictionary is created. Use suffix matching as a
            # safeguard for subdomains/aliases returned by PrimeKiste.
            # Set the final PrimeKiste priority explicitly from the raw URL.
            # Do not rely on ResolveURL's host label here: that path returns 100
            # for these mirrors in the current Kodi/ResolveURL combination.
            url_l = str(sUrl or '').lower()
            if 'firestream.to/' in url_l or 'firestream.site/' in url_l:
                prioHoster = 10
            elif 'voe.sx/' in url_l:
                prioHoster = 20
            elif 'vixeo.io/' in url_l:
                prioHoster = 30
            elif 'playmate.to/' in url_l:
                prioHoster = 40
            elif ('vidaraa.cc/' in url_l or 'vidara.so/' in url_l or
                  'vidara.to/' in url_l or 'vidara.fit/' in url_l):
                prioHoster = 90

            sQuality = self._quality(stream.get('release', ''), stream.get('res', ''))
            prepared.append({
                'source': hoster,
                'quality': sQuality,
                'language': 'de',
                'url': sUrl,
                'direct': False,
                'prioHoster': prioHoster,
                'info': item_year,
                '_host_key': host_key,
            })

            # Unterschiedliche gueltige Hoster fuellen zuerst das sichtbare 10er-Limit.
            if len({item['_host_key'] for item in prepared}) >= self.MAX_SOURCES_PER_SCRAPER:
                break

        # Zuerst unterschiedliche Hoster, danach bei Bedarf weitere eindeutige
        # Links auffuellen. Maximal zehn sichtbare PrimeKiste-Quellen.
        selected = []
        selected_urls = set()
        selected_hosts = set()
        for item in prepared:
            if item['_host_key'] in selected_hosts:
                continue
            selected.append(item)
            selected_urls.add(item['url'].rstrip('/'))
            selected_hosts.add(item['_host_key'])
            if len(selected) >= self.MAX_SOURCES_PER_SCRAPER:
                break

        if len(selected) < self.MAX_SOURCES_PER_SCRAPER:
            for item in prepared:
                key = item['url'].rstrip('/')
                if key in selected_urls:
                    continue
                selected.append(item)
                selected_urls.add(key)
                if len(selected) >= self.MAX_SOURCES_PER_SCRAPER:
                    break

        # Keep the final PrimeKiste list deterministic: quality first, then
        # the host preference above. This prevents a slow Vidaraa mirror from
        # becoming the first 1080p choice when equivalent mirrors exist.
        selected.sort(
            key=lambda item: (
                self._stream_priority({'release': item.get('quality', '')}),
                self._host_preference(item.get('url', '')),
            ),
            reverse=True
        )

        for item in selected:
            item.pop('_host_key', None)
            self.sources.append(item)
            log_utils.log('[%s] Stream uebernommen: %s [%s] year=%s prioHoster=%s' % (
                SITE_NAME, self._host_key(item['url']), item['quality'], item_year,
                item.get('prioHoster', 100)), log_utils.LOGINFO)

        if season > 0:
            log_utils.log('[%s] Episode S%02dE%02d: %d Stream-Eintraege' % (
                SITE_NAME, int(season), int(episode), matched_episode_streams), log_utils.LOGINFO)
        log_utils.log('[%s] Watch-API verarbeitet: %d eindeutig, %d Quellen, '
                      'duplikate=%d blockiert=%d hosterlimit=%d' % (
                          SITE_NAME, len(seen_urls), len(self.sources), rejected_duplicate,
                          rejected_blocked, rejected_limit), log_utils.LOGINFO)
        log_utils.log('[%s] Arbeitsmenge: %d/%d Kandidaten geprueft, max. %d Quellen' % (SITE_NAME, scanned_streams, min(len(candidate_streams), self.MAX_INPUT_STREAMS_TO_SCAN), self.MAX_SOURCES_PER_SCRAPER), log_utils.LOGINFO)

    def _check_movies(self, movies, clean_titles, years, season, episode):
        for movie in movies:
            if not isinstance(movie, dict) or '_id' not in movie:
                continue

            sTitle = movie.get('title', '')
            sYear = str(movie.get('year', ''))

            if season > 0:
                base = sTitle.rsplit('-', 1)[0].strip() if '-' in sTitle else sTitle
                season_part = sTitle.rsplit('-', 1)[1].strip() if '-' in sTitle else ''
                if cleantitle.get(base) in clean_titles and str(season) in season_part:
                    log_utils.log('[%s] Serien-Treffer: "%s" _id=%s' % (
                        SITE_NAME, sTitle, movie['_id']), log_utils.LOGINFO)
                    self._get_streams(str(movie['_id']), season, episode, sYear)
            elif cleantitle.get(sTitle) in clean_titles and sYear in years:
                log_utils.log('[%s] Treffer: "%s" (%s) _id=%s' % (
                    SITE_NAME, sTitle, sYear, movie['_id']), log_utils.LOGINFO)
                self._get_streams(str(movie['_id']), year=sYear)

            if self.sources:
                return True
        return False

    def run(self, titles, year, season=0, episode=0, imdb='', hostDict=None):
        self.sources = []
        log_utils.log('[%s] run() start: titles=%s year=%s season=%s episode=%s imdb=%s' % (
            SITE_NAME, titles, year, season, episode, imdb), log_utils.LOGINFO)

        try:
            clean_titles = set(cleantitle.get(i) for i in set(titles) if i)
            years = [str(year - 1), str(year), str(year + 1)]

            # 1. Schnelle API-Suche. Die Treffer werden streng nach Titel/Jahr geprüft.
            candidates = self._search_api(titles, imdb)
            if candidates and self._check_movies(candidates, clean_titles, years, season, episode):
                return self.sources

            # 2. Speicherarmer Paging-Fallback. Es liegt immer nur eine Seite im RAM.
            previous_signature = None
            for page in range(1, self.MAX_PAGES + 1):
                movies = self._load_page(page)
                if not movies:
                    break

                signature = tuple(str(m.get('_id', '')) for m in movies[:5] if isinstance(m, dict))
                if signature and signature == previous_signature:
                    log_utils.log('[%s] Paging-Abbruch: Seite %d wiederholt Seite %d' % (
                        SITE_NAME, page, page - 1), log_utils.LOGWARNING)
                    break
                previous_signature = signature

                if self._check_movies(movies, clean_titles, years, season, episode):
                    break

                if len(movies) < self.PAGE_SIZE:
                    break

        except Exception as e:
            log_utils.log('[%s] run() Fehler: %s' % (SITE_NAME, str(e)[:200]),
                          log_utils.LOGWARNING)

        log_utils.log('[%s] run() end: %d Quellen gesamt' % (
            SITE_NAME, len(self.sources)), log_utils.LOGINFO)
        return self.sources

    def resolve(self, url):
        return url
