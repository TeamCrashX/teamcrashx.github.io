
#2022-11-05
# edit 2024-12-14
# fix 2026-07-09: erst Direkt-URL /stream/<slug>, dann Suchfallback
# v4: Hoster, die isBlockedHoster/ResolveURL nicht vorab pruefen kann, optional roh an Kodi/ResolveURL durchreichen

from resources.lib.utils import isBlockedHoster
import re
import traceback
import concurrent.futures
try:
	from urllib.parse import quote_plus
except Exception:
	quote_plus = None
from resources.lib.control import urljoin
from resources.lib.requestHandler import cRequestHandler
from scrapers.modules import cleantitle, dom_parser, source_utils
from resources.lib.control import getSetting

SITE_IDENTIFIER = 'filmpalast'
SITE_DOMAIN = 'filmpalast.to'
SITE_NAME = SITE_IDENTIFIER.upper()

# Entwicklungs-Logging entfernt; echte Fehler laufen weiterhin über xShip/Kodi.
def _log(msg):
	return None


def _html_unescape(txt):
	try:
		from html import unescape
		return unescape(txt)
	except Exception:
		return txt


def _strip_tags(txt):
	if not txt:
		return ''
	txt = re.sub(r'(?is)<script.*?</script>|<style.*?</style>', ' ', txt)
	txt = re.sub(r'(?is)<[^>]+>', ' ', txt)
	txt = _html_unescape(txt)
	return re.sub(r'\s+', ' ', txt).strip()


def _attr(tag, name):
	m = re.search(r'''(?is)\b%s\s*=\s*(["'])(.*?)\1''' % re.escape(name), tag)
	return _html_unescape(m.group(2).strip()) if m else ''


class source:
	def __init__(self):
		self.priority = 1
		self.language = ['de']
		self.domain = getSetting('provider.' + SITE_IDENTIFIER + '.domain', SITE_DOMAIN)
		self.base_link = 'https://' + self.domain

		self.search_link = '/search/title/%s'

	def _title_matches(self, page_title, wanted_titles):
		page_clean = cleantitle.get(page_title or '')
		if not page_clean:
			return False
		# Jahreszahlen und typische Stream-/HD-Zusaetze fuer den Vergleich ignorieren.
		page_clean_short = re.sub(r'(19|20)\d{2}$', '', page_clean)
		page_clean_short = re.sub(r'(stream|hd|german|deutsch|online)$', '', page_clean_short)
		for wanted in wanted_titles:
			wanted_short = re.sub(r'(19|20)\d{2}$', '', wanted)
			if page_clean == wanted or page_clean_short == wanted_short:
				return True
			# Etwas toleranter, aber nicht zu kurz, damit nicht jeder Teiltreffer angenommen wird.
			if len(wanted_short) >= 6 and (wanted_short in page_clean_short or page_clean_short in wanted_short):
				return True
		return False

	def _slug_matches(self, href, wanted_titles):
		slug = source_utils.strip_domain(href or '')
		slug = re.sub(r'\?.*$', '', slug)
		slug = cleantitle.get(slug)
		for wanted in wanted_titles:
			if wanted and len(wanted) >= 6 and wanted in slug:
				return True
		return False

	def _add_result(self, results, seen, href, title):
		if not href:
			return
		href = _html_unescape(href).strip()
		if href.startswith('#') or href.startswith('javascript:'):
			return
		# Such-/Asset-/Login-Links aussortieren.
		if re.search(r'(?i)/(search|genre|tag|login|register|impressum|privacy|kontakt)(/|\?|$)', href):
			return
		if re.search(r'(?i)\.(jpg|jpeg|png|gif|webp|svg|css|js|ico)(\?|$)', href):
			return
		title = _strip_tags(title)
		key = source_utils.strip_domain(href)
		if key in seen:
			return
		seen.add(key)
		results.append((href, title))

	def _parse_search_results(self, sHtmlContent, wanted_titles):
		results = []
		seen = set()

		# Alter Aufbau: <article> ... <a class="rb" href="...">Titel</a>
		try:
			articles = dom_parser.parse_dom(sHtmlContent, 'article')
			links = dom_parser.parse_dom(articles, 'a', attrs={'class': 'rb'}, req='href') if articles else []
			for i in links:
				self._add_result(results, seen, i.attrs.get('href', ''), i.content)
		except Exception:
			_log('Alter article/rb-Parser fehlgeschlagen: %s' % traceback.format_exc())

		# Neuer robuster Fallback: alle <a>-Tags pruefen und Titel aus Text/title/aria-label ableiten.
		for m in re.finditer(r'(?is)<a\b([^>]*?\bhref\s*=\s*(["\']).*?\2[^>]*)>(.*?)</a>', sHtmlContent or ''):
			tag = m.group(1)
			body = m.group(3)
			href = _attr(tag, 'href')
			title = _attr(tag, 'title') or _attr(tag, 'aria-label') or _strip_tags(body)
			if not title:
				# Posterbilder haben oft alt="Filmtitel" im Link.
				title = _attr(body, 'alt')
			# Kandidat annehmen, wenn entweder der sichtbare Titel oder der URL-Slug passt.
			if self._title_matches(title, wanted_titles) or self._slug_matches(href, wanted_titles):
				self._add_result(results, seen, href, title)

		# Noch ein Fallback fuer JSON/JS-Snippets mit href/url + title/name.
		for m in re.finditer(r'''(?is)(?:href|url)\s*[:=]\s*(["'])(.*?)\1.{0,250}?(?:title|name)\s*[:=]\s*(["'])(.*?)\3''', sHtmlContent or ''):
			href = m.group(2)
			title = m.group(4)
			if self._title_matches(title, wanted_titles) or self._slug_matches(href, wanted_titles):
				self._add_result(results, seen, href, title)

		_log('Treffer in Suchergebnis (robust): %d -> %s' % (len(results), [i[1] for i in results]))
		return results


	def _slugify_title(self, title):
		# Filmpalast-Detailseiten nutzen i.d.R. /stream/toy-story-5.
		# Deshalb zuerst eine direkte Detail-URL probieren, statt sich auf die kaputte Suche zu verlassen.
		s = (title or '').strip().lower()
		try:
			from unicodedata import normalize
			s = normalize('NFKD', s)
		except Exception:
			pass
		s = s.replace('&', ' und ')
		s = s.replace('ä', 'ae').replace('ö', 'oe').replace('ü', 'ue').replace('ß', 'ss')
		s = re.sub(r'[^a-z0-9]+', '-', s)
		s = re.sub(r'-+', '-', s).strip('-')
		return s

	def _detail_page_matches(self, html, wanted_titles, year=0):
		if not html:
			return False
		# Echte Filmpalast-Detailseite hat normalerweise article.detail und/oder Streamliste.
		if 'currentStreamLinks' not in html and 'article class="detail' not in html and "article class='detail" not in html:
			return False

		page_title = ''
		try:
			h = dom_parser.parse_dom(html, 'h2')
			if h:
				page_title = h[0].content
		except Exception:
			pass
		if not page_title:
			m = re.search(r'(?is)<title[^>]*>(.*?)</title>', html)
			if m:
				page_title = _strip_tags(m.group(1))

		if page_title and not self._title_matches(page_title, wanted_titles):
			_log('Direkt-URL: Titel passt nicht: "%s" vs %s' % (_strip_tags(page_title), wanted_titles))
			return False

		# Jahr nur weich pruefen: wenn auf der Detailseite ein Jahr im Umfeld von Veröffentlicht/Jahr steht,
		# muss es passen; wenn kein Jahr gefunden wird, wird der Treffer trotzdem akzeptiert.
		try:
			if year:
				years = ('%s' % str(year), '%s' % str(int(year) + 1), '%s' % str(int(year) - 1), '0')
				found = re.findall(r'(?i)(?:licht|jahr| DE|release|veröffentlicht|veroeffentlicht)[^0-9]{0,80}((?:19|20)\d{2})', html or '')
				if found and not any(y in years for y in found):
					_log('Direkt-URL: Jahr passt nicht - gefunden=%s erwartet=%s' % (found[:5], years))
					return False
		except Exception:
			pass
		return True

	def _search_urls(self, title):
		urls = []
		variants = []
		try:
			if quote_plus:
				variants.append(quote_plus(title))
		except Exception:
			pass
		variants += [title.replace(' ', '+'), title.replace(' ', '-'), title]
		seen = set()
		for v in variants:
			if not v or v in seen:
				continue
			seen.add(v)
			urls.append(urljoin(self.base_link, self.search_link % v))
		return urls

	def _candidate_links_debug(self, sHtmlContent):
		items = []
		try:
			for m in re.finditer(r'(?is)<a\b([^>]*)>(.*?)</a>', sHtmlContent or ''):
				tag = m.group(1)
				href = _attr(tag, 'href')
				text = _attr(tag, 'title') or _attr(tag, 'aria-label') or _strip_tags(m.group(2)) or _attr(m.group(2), 'alt')
				if href and not re.search(r'(?i)\.(jpg|jpeg|png|gif|webp|svg|css|js|ico)(\?|$)', href):
					items.append('%s => %s' % (text[:60], href[:120]))
		except Exception:
			items = []
		_log('Debug Kandidatenlinks: %d -> %s' % (len(items), items[:25]))
	def run(self, titles, year, season=0, episode=0, imdb='', hostDict=None):
		self.sources = []
		sources = []
		_log('run() start: titles=%s year=%s season=%s episode=%s imdb=%s' % (titles, year, season, episode, imdb))
		try:
			url = ''
			t = [cleantitle.get(i) for i in titles if i]
			_log('bereinigte Vergleichstitel t=%s' % t)
			for title in titles:
				try:
					# Filmpalast fuehrt bei gleichen Titeln oft mehrere Detailseiten.
					# Deshalb bei Filmen IMMER zuerst /stream/<titel>-<jahr> testen.
					slug = self._slugify_title(title)
					direct_candidates = []
					if slug and not season and year:
						year_suffix = str(year)
						if not slug.endswith('-' + year_suffix):
							direct_candidates.append('/stream/%s-%s' % (slug, year_suffix))
					if slug:
						direct_candidates.append('/stream/%s' % slug)

					for direct_url in direct_candidates:
						direct_query = urljoin(self.base_link, direct_url)
						_log('Direkt-Check: title="%s" year=%s -> %s' % (title, year, direct_query))
						oRequest = cRequestHandler(direct_query)
						oRequest.cacheTime = 0
						detailHtml = oRequest.request()
						if self._detail_page_matches(detailHtml, t, year):
							url = direct_url
							_log('Direkt-URL gefunden: %s' % url)
							break
					if url:
						break

					# 2) Fallback: alte/robuste Suche, falls Direkt-URL nicht passt.
					r = []
					sHtmlContent = ''
					for query in self._search_urls(title):
						_log('Suche: title="%s" -> %s' % (title, query))
						oRequest  = cRequestHandler(query)
						oRequest.cacheTime = 0  # beim Debug/Fixen nicht alte Null-Treffer aus dem Cache nehmen
						sHtmlContent = oRequest.request()
						r = self._parse_search_results(sHtmlContent, t)
						if len(r) > 0:
							break
					if len(r) == 0:
						_log('Keine verwertbaren Treffer im Suchergebnis fuer title="%s" (HTML-Laenge=%d)' % (title, len(sHtmlContent) if sHtmlContent else 0))
						self._candidate_links_debug(sHtmlContent)
						continue

					if len(r) >= 1 and season == 0:
						self.list = []
						with concurrent.futures.ThreadPoolExecutor() as executor:
							futures = [executor.submit(self.chk_year, i, year) for i in r]
							concurrent.futures.wait(futures)
						r = self.list
						_log('Treffer nach Jahresfilter (year=%s): %d -> %s' % (year, len(r), [i[1] for i in r]))

					if len(r) > 0:
						if season > 0:
							for i in r:
								link = re.findall(r'(.*?)S\d', i[1], flags=re.I)
								if link and cleantitle.get(link[0]) in t:
									url = source_utils.strip_domain(i[0])
						else:
							before = [i[1] for i in r]
							r2 = [i[0] for i in r if self._title_matches(i[1], t) or self._slug_matches(i[0], t)]
							if len(r2) > 0:
								url = r2[0]
							else:
								_log('Kein Titel-Match: bereinigte Seiten-Titel=%s vs gesuchte Titel t=%s' % ([cleantitle.get(x) for x in before], t))
					else:
						_log('Nach Jahresfilter blieb kein Treffer uebrig')
					if url:
						_log('URL gefunden: %s' % url)
						break
				except Exception:
					_log('Exception beim Verarbeiten von title="%s": %s' % (title, traceback.format_exc()))

			if url == '':
				_log('run() Ende: keine URL gefunden, gebe leere sources zurueck')
				return sources
			if season > 0:
				e = '0' + str(episode) if int(episode) < 10 else str(episode)
				s = '0' + str(season) if int(season) < 10 else str(season)
				url = re.findall(r'(.*?)s\d', url, flags=re.I)[0] + 's%se%s' % (s, e)

			query = urljoin(self.base_link, url)
			oRequest = cRequestHandler(query)
			oRequest.cacheTime = 60 * 60 * 24 * 1
			moviecontent = oRequest.request()

			quality = 'SD'
			try:
				q = dom_parser.parse_dom(moviecontent, 'span', attrs={'id': 'release_text'})
				if q:
					quality = q[0].content.split('&nbsp;')[0]
				quality, info = source_utils.get_release_quality(quality)
			except Exception:
				_log('Quality konnte nicht gelesen werden, verwende SD')
				quality = 'SD'

			# Jeder Anbieter steht in einem eigenen currentStreamLinks-Block.
			# Die bewährte Fremd-Addon-Logik sucht ab hostName bis zur ersten HTTP-URL.
			# Zusätzlich lesen wir data-player-url und href explizit aus.
			r = []
			seen_links = set()
			block_pattern = r'(?is)<ul[^>]*class=["\'][^"\']*currentStreamLinks[^"\']*["\'][^>]*>(.*?)</ul>'
			for block_m in re.finditer(block_pattern, moviecontent or ''):
				block = block_m.group(1)
				hm = re.search(r'(?is)hostName["\']?[^>]*>([^<]+)', block)
				hoster = re.sub(r'\s+HD\s*$', '', _strip_tags(hm.group(1))).strip() if hm else ''
				play_url = ''
				# Bevorzugt echte Playerattribute; danach wie im anderen Add-on
				# einfach die erste HTTP-URL nach dem Hosternamen.
				um = re.search(r'(?is)(?:data-player-url|href)\s*=\s*(["\'])(https?://.*?)\1', block)
				if um:
					play_url = _html_unescape(um.group(2)).strip()
				if not play_url:
					um = re.search(r'(?is)(https?://[^"\'<>\s]+)', block)
					if um:
						play_url = _html_unescape(um.group(1)).strip()
				if hoster and play_url and play_url not in seen_links:
					seen_links.add(play_url)
					r.append((hoster.lower(), play_url))

			# Globaler Fallback exakt nach dem Prinzip der hochgeladenen Datei:
			# hostName">NAME ... erste http-URL.
			if not r:
				for hm in re.finditer(r'(?is)hostName["\']?[^>]*>([^<]+).*?(https?://[^"\'<>\s]+)', moviecontent or ''):
					hoster = re.sub(r'\s+HD\s*$', '', _strip_tags(hm.group(1))).strip().lower()
					play_url = _html_unescape(hm.group(2)).strip()
					if hoster and play_url and play_url not in seen_links:
						seen_links.add(play_url)
						r.append((hoster, play_url))

			_log('Detailseite %s: quality=%s, %d Hoster-Links gefunden -> %s' % (query, quality, len(r), [x[0] for x in r]))

			# Keine Vorab-Aufloesung und kein angehaengtes $$-Refererformat mehr.
			# Das hatte insbesondere bei VOE aus gueltigen URLs einen 404 erzeugt.
			# Alle auf der Detailseite vorhandenen Links werden roh an den zentralen
			# Resolver weitergegeben; dort erfolgt die eigentliche Hosterbehandlung.
			for hoster, raw_link in r:
				if url:
					sources.append({'source': hoster, 'quality': quality, 'language': 'de', 'url': raw_link, 'direct': False, 'prioHoster': 0, 'info': str(year) if year else ''})
					_log('Hoster roh uebernommen: %s -> %s' % (hoster, raw_link))

			if len(sources) == 0:
				_log('Keine verwertbaren Hoster-Links uebrig (alle geblockt oder Liste leer)')
				raise Exception()
			_log('run() Ende: %d Sources gefunden' % len(sources))
			return sources
		except Exception:
			_log('Exception in run(): %s' % traceback.format_exc())
			return sources

	def resolve(self, url):
		try:
			return url
		except:
			return

	def chk_year(self, i, year):
		try:
			years = ('%s' % str(year), '%s' % str(int(year) + 1), '%s' % str(int(year) - 1), '0')
			query = urljoin(self.base_link, i[0])
			oRequest = cRequestHandler(query)
			sHtmlContent = oRequest.request()

			# Alter Aufbau: "...licht: 2026". Neuer Fallback: alle plausiblen Jahreszahlen im HTML pruefen.
			found = re.findall(r'(?i)(?:licht|jahr| DE|release|veröffentlicht|veroeffentlicht)[^0-9]{0,80}((?:19|20)\d{2})', sHtmlContent or '')
			if not found:
				found = re.findall(r'\b((?:19|20)\d{2})\b', sHtmlContent or '')

			# Wenn gar kein Jahr gefunden wird, Treffer nicht mehr hart verwerfen.
			# Genau das war nach HTML-Aenderungen oft der Grund fuer 0 Treffer.
			if not found:
				_log('chk_year: kein Jahr gefunden, akzeptiere Treffer vorsichtig: %s (Titel="%s")' % (query, i[1]))
				self.list.append((query, i[1]))
				return

			if any(y in years for y in found):
				self.list.append((query, i[1]))
			else:
				_log('chk_year: Jahr passt nicht - gefunden=%s, erwartet eines von %s, url=%s (Titel="%s")' % (found[:8], years, query, i[1]))
		except Exception:
			_log('chk_year: Exception fuer i=%s: %s' % (i, traceback.format_exc()))
