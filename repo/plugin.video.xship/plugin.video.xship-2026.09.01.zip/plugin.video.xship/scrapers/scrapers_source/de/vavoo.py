# -*- coding: utf-8 -*-

# vavoo
# edit 2026-08-04 — addonSig + direkte Source-URLs

import requests
from urllib.parse import urlparse

from resources.lib.utils import isBlockedHoster
from resources.lib.control import getSetting
from resources.lib.tmdb import cTMDB
from resources.lib import log_utils

SITE_IDENTIFIER = 'vavoo'
SITE_DOMAIN = 'vavoo.to'
SITE_NAME = SITE_IDENTIFIER.upper()

PING_URL = 'https://www.vavoo.tv/api/app/ping'
CLIENT_VERSION = '3.1.20'


def _quality(value):
    # xShip sortiert nur bekannte Qualitätswerte zuverlässig. Vavoo liefert
    # häufig allgemeine Tags wie HD/FHD/UHD, die deshalb normalisiert werden.
    text = str(value or '').upper().replace('-', ' ').replace('_', ' ')
    if '2160' in text or '4K' in text or 'UHD' in text:
        return '4K'
    if '1080' in text or 'FULL HD' in text or 'FULLHD' in text or 'FHD' in text:
        return '1080p'
    if '720' in text or 'HD' in text:
        return '720p'
    if '480' in text or 'SD' in text:
        return '480p'
    return '720p'


def _host(url):
    try:
        return urlparse(url).netloc.lower().split(':')[0].replace('www.', '')
    except Exception:
        return 'direct'


class source:
    def __init__(self):
        self.priority = int(getSetting('provider.' + SITE_IDENTIFIER + '.priority', 100))
        self.language = ['de']
        self.domain = getSetting('provider.' + SITE_IDENTIFIER + '.domain', SITE_DOMAIN)
        self.base_link = 'https://' + self.domain.strip('/')
        self.sources = []
        self._signature = None
        self.session = requests.Session()

    def _get_signature(self):
        if self._signature:
            return self._signature

        payload = {
            'token': 'tosFwQCJMS8qrW_AjLoHPQ41646J5dRNha6ZWHnijoYQQQoADQoXYSo7ki7O5-CsgN4CH0uRk6EEoJ0728ar9scCRQW3ZkbfrPfeCXW2VgopSW2FWDqPOoVYIuVPAOnXCZ5g',
            'reason': 'app-blur',
            'locale': 'de',
            'theme': 'dark',
            'metadata': {
                'device': {'type': 'Handset', 'brand': 'google', 'model': 'Nexus', 'name': '21081111RG', 'uniqueId': 'd10e5d99ab665233'},
                'os': {'name': 'android', 'version': '7.1.2', 'abis': ['arm64-v8a', 'armeabi-v7a', 'armeabi'], 'host': 'android'},
                'app': {'platform': 'android', 'version': CLIENT_VERSION, 'buildId': '289515000', 'engine': 'hbc85', 'signatures': ['6e8a975e3cbf07d5de823a760d4c2547f86c1403105020adee5de67ac510999e'], 'installer': 'app.revanced.manager.flutter'},
                'version': {'package': 'tv.vavoo.app', 'binary': CLIENT_VERSION, 'js': CLIENT_VERSION}
            },
            'appFocusTime': 0, 'playerActive': False, 'playDuration': 0,
            'devMode': False, 'hasAddon': True, 'castConnected': False,
            'package': 'tv.vavoo.app', 'version': CLIENT_VERSION, 'process': 'app',
            'firstAppStart': 1743962904623, 'lastAppStart': 1743962904623,
            'ipLocation': '', 'adblockEnabled': True,
            'proxy': {'supported': ['ss', 'openvpn'], 'engine': 'ss', 'ssVersion': 1, 'enabled': True, 'autoServer': True, 'id': 'pl-waw'},
            'iap': {'supported': False}
        }
        headers = {
            'User-Agent': 'okhttp/4.11.0',
            'Accept': 'application/json',
            'Content-Type': 'application/json; charset=utf-8'
        }
        try:
            response = self.session.post(PING_URL, json=payload, headers=headers, timeout=12)
            response.raise_for_status()
            self._signature = response.json().get('addonSig')
            if self._signature:
                log_utils.log('[VAVOO] addonSig erfolgreich geladen', log_utils.LOGINFO)
            else:
                log_utils.log('[VAVOO] Ping-Antwort ohne addonSig', log_utils.LOGWARNING)
        except Exception as exc:
            log_utils.log('[VAVOO] addonSig Fehler: %s' % exc, log_utils.LOGWARNING)
        return self._signature

    def _post_api(self, endpoint, payload, signature):
        headers = {
            'User-Agent': 'MediaHubMX/2',
            'Accept': 'application/json',
            'Content-Type': 'application/json; charset=utf-8',
            'mediahubmx-signature': signature,
            'Referer': self.base_link + '/'
        }
        url = self.base_link + '/' + endpoint.lstrip('/')
        response = self.session.post(url, json=payload, headers=headers, timeout=15)
        response.raise_for_status()
        return response.json()

    def run(self, titles, year, season=0, episode=0, imdb='', hostDict=None):
        self.sources = []
        try:
            tmdb = cTMDB()
            result = tmdb._call('find/' + str(imdb), 'external_source=imdb_id')
            result_key = 'tv_results' if season else 'movie_results'
            result_list = result.get(result_key, []) if isinstance(result, dict) else []
            tmdb_id = result_list[0].get('id') if result_list else None
            if not tmdb_id:
                log_utils.log('[VAVOO] Keine TMDb-ID fuer %s (%s)' % (imdb, result_key), log_utils.LOGWARNING)
                return self.sources
            log_utils.log('[VAVOO] TMDb-ID: %s' % tmdb_id, log_utils.LOGINFO)

            signature = self._get_signature()
            if not signature:
                return self.sources

            mediatype = 'series' if season else 'movie'
            name = next((str(x) for x in titles if x), '')
            payload = {
                'language': 'de',
                'region': 'DE',
                'type': mediatype,
                'ids': {'tmdb_id': tmdb_id},
                'name': name,
                'episode': {},
                'clientVersion': '3.0.2'
            }
            if season:
                payload['episode'] = {'ids': {}, 'season': int(season), 'episode': int(episode)}

            mirrors = self._post_api('mediahubmx-source.json', payload, signature)
            if not isinstance(mirrors, list):
                log_utils.log('[VAVOO] Source-API unerwartete Antwort: %s' % type(mirrors).__name__, log_utils.LOGWARNING)
                return self.sources

            log_utils.log('[VAVOO] Source-API: %d Mirrors' % len(mirrors), log_utils.LOGINFO)
            seen = set()
            for item in mirrors:
                try:
                    languages = item.get('languages') or []
                    if languages and 'de' not in [str(x).lower() for x in languages]:
                        continue

                    source_url = str(item.get('url') or '').strip()
                    if not source_url or not source_url.startswith(('http://', 'https://')):
                        continue
                    if source_url in seen:
                        continue
                    seen.add(source_url)

                    # Die aktuelle Source-API liefert bereits verwendbare URLs.
                    # mediahubmx-resolve.json antwortet derzeit mit HTTP 500 und
                    # wird deshalb bewusst nicht mehr aufgerufen.
                    is_blocked, hoster, filtered_url, prio_hoster = isBlockedHoster(source_url)
                    final_url = filtered_url or source_url

                    # Vavoo-URLs nicht schon während der Suche verwerfen. Auch
                    # unbekannte Links werden direkt an Kodi weitergereicht.
                    if not final_url:
                        continue
                    hoster = hoster or _host(final_url)
                    quality = _quality(item.get('tag') or item.get('name'))
                    info_parts = []
                    if item.get('name'):
                        info_parts.append(str(item.get('name')).strip())
                    if year:
                        info_parts.append(str(year))
                    info = ' | '.join(x for x in info_parts if x)

                    self.sources.append({
                        'source': hoster,
                        'quality': quality,
                        'language': 'de',
                        'url': final_url,
                        'info': info,
                        'direct': True,
                        'priority': self.priority,
                        'prioHoster': prio_hoster
                    })
                    if is_blocked:
                        log_utils.log('[VAVOO] Hoster roh uebernommen: %s [%s]' % (hoster, quality), log_utils.LOGINFO)
                    else:
                        log_utils.log('[VAVOO] Quelle: %s [%s]' % (hoster, quality), log_utils.LOGINFO)
                except Exception as exc:
                    log_utils.log('[VAVOO] Source-Eintrag Fehler: %s' % exc, log_utils.LOGWARNING)

            log_utils.log('[VAVOO] run Ende: %d Quellen' % len(self.sources), log_utils.LOGINFO)
        except Exception as exc:
            log_utils.log('[VAVOO] run Fehler: %s' % exc, log_utils.LOGWARNING)
        return self.sources

    def resolve(self, url):
        return url
