# -*- coding: UTF-8 -*-
import re, ast
from resources.lib.control import quote_plus, urlparse, getSetting
from resources.lib.requestHandler import cRequestHandler
from scrapers.modules import cleantitle, dom_parser, source_utils
from scrapers.modules.tools import cParser
from resolveurl.plugins import voesx
import resolveurl

SITE_IDENTIFIER = 'kinoger'
SITE_DOMAIN = 'kinoger.com'
SITE_NAME = SITE_IDENTIFIER.upper()

DOOD_DOMAINS = ('dood.sbs', 'dood.re', 'dood.cx', 'dood.la', 'dood.so', 'dood.pm', 'dood.to', 'dood.watch')

# These KinoGer embed hosts are not direct media URLs. In Kodi 21 they can be
# handed through unchanged when ResolveURL has no matching resolver, causing
# the player to sit in Creating Demuxer / retry-like loops. Do not advertise
# them as playable sources unless a resolver is added separately.
SPECIAL_EMBED_HOSTS = ('kinoger.pw', 'fsst.online')


def _rewrite_dood(url):
    url_l = (url or '').lower()
    for domain in DOOD_DOMAINS:
        if domain in url_l:
            return url.replace(domain, 'veev.to')
    return url


def get_voe_stream_from_kinoger(kinoger_url):
    try:
        request = cRequestHandler(kinoger_url, caching=False, ignoreErrors=True)
        request.addHeaderEntry('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36')
        request.addHeaderEntry('Referer', 'https://kinoger.ru/')
        html = request.request()
        patterns = (
            r'https?://[^/]+/e/([a-zA-Z0-9]{8,12})',
            r'voe\.sx/e/([a-zA-Z0-9]{8,12})',
            r'/([a-zA-Z0-9]{8,12})["\']'
        )
        for pattern in patterns:
            for media_id in re.findall(pattern, html or '', re.I):
                if len(media_id) >= 8 and media_id.isalnum():
                    return voesx.VoeResolver().get_media_url('voe.sx', media_id)
    except Exception:
        pass
    return None


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['de']
        self.domain = getSetting('provider.' + SITE_IDENTIFIER + '.domain', SITE_DOMAIN)
        self.base_link = 'https://' + self.domain
        self.search = self.base_link + '/index.php?do=search&subaction=search&search_start=1&full_search=0&result_from=1&titleonly=3&story=%s'
        self.sources = []

    def run(self, titles, year, season=0, episode=0, imdb='', hostDict=None):
        sources, items = [], []
        url = ''
        try:
            t = [cleantitle.get(i) for i in titles if i]
            years = [str(year - 1), str(year), str(year + 1)] if season == 0 else ['']

            for title in titles:
                try:
                    url = self._direct_url(title, year, season, imdb)
                    if url:
                        break

                    for search_title in (quote_plus(title), title):
                        request = cRequestHandler(self.search % search_title)
                        request.removeBreakLines(False)
                        request.removeNewLines(False)
                        request.cacheTime = 60 * 60 * 12
                        results = self._search_results(request.request())

                        for href, name, item_year in results:
                            clean_name = cleantitle.get(name)
                            if season > 0:
                                if 'staffel' in clean_name and any(k in clean_name for k in t):
                                    url = href
                                    break
                            elif any(k in clean_name for k in t):
                                if item_year and item_year in years:
                                    self._log('SEARCH ACCEPT title=%r year=%s target=%s url=%s' % (name, item_year, year, href))
                                    url = href
                                    break
                                if item_year:
                                    self._log('SEARCH REJECT title=%r year=%s target=%s reason=year-mismatch url=%s' % (name, item_year, year, href))
                                    continue
                                # Search result without a year: validate the detail page before accepting it.
                                if self._is_valid_detail(href, title, year, imdb, require_year=True):
                                    url = href
                                    break
                        if url:
                            break
                    if url:
                        break
                except Exception:
                    pass

            if not url:
                return sources

            request = cRequestHandler(self._full_url(url))
            request.cacheTime = 60 * 60 * 12
            qualities, links = self._stream_entries(request.request())
            if not links:
                return sources

            if season > 0 and episode > 0:
                season -= 1
                episode -= 1

            for i, link in enumerate(links):
                try:
                    stream_url = ast.literal_eval(link)[season][episode].strip()
                    direct = True
                    valid, host = source_utils.is_host_valid(stream_url, hostDict or [])
                    if valid:
                        direct = False
                    if not host:
                        host = self._host_from_url(stream_url)
                    quality = self._normalize_quality(qualities[i] if i < len(qualities) else 'SD')
                    items.append({'source': host, 'quality': quality, 'url': stream_url, 'direct': direct})
                except Exception:
                    continue

            headers = '&Accept-Language=de%2Cen-US%3Bq%3D0.7%2Cen%3Bq%3D0.3&Accept=%2A%2F%2A&User-Agent=Mozilla%2F5.0+%28Windows+NT+10.0%3B+Win64%3B+x64%3B+rv%3A99.0%29+Gecko%2F20100101+Firefox%2F99.0'
            for item in items:
                try:
                    host = item['source'] or ''
                    host_l = host.lower()
                    url_l = str(item.get('url') or '').lower()
                    if 'kinoger.re' in host_l or 'p2p' in host_l:
                        continue
                    if any(special in host_l or special in url_l for special in SPECIAL_EMBED_HOSTS):
                        # Keep the wrapper URL until playback. These hosts return short-lived
                        # media URLs / cookies; resolving them during the source search can make
                        # the token stale by the time the user presses Play. sourcesResolve()
                        # always calls this provider's resolve(), even for direct=True entries.
                        self._log('SOURCE DEFER host=%r reason=resolve-at-playback url=%s' % (host, item.get('url')))
                        sources.append({'source': host, 'quality': item['quality'], 'language': 'de', 'url': item.get('url'), 'direct': True})
                        continue
                    if 'kinoger.ru' in host:
                        stream_url = get_voe_stream_from_kinoger(item['url'])
                        if stream_url:
                            sources.append({'source': host, 'quality': item['quality'], 'language': 'de', 'url': stream_url, 'direct': False})
                    elif 'kinoger.be' in host:
                        sources += self._kinoger_be_sources(item, headers)
                    else:
                        sources.append({'source': host, 'quality': item['quality'], 'language': 'de', 'url': _rewrite_dood(item['url']), 'direct': False})
                except Exception:
                    continue

            for item in sources:
                if item not in self.sources:
                    self.sources.append(item)
            return self.sources if sources else sources
        except Exception:
            return sources

    def _log(self, message, level=1):
        """Best-effort Kodi logging for KinoGer matching diagnostics."""
        text = '[KINOGER] %s' % message
        try:
            import xbmc
            xbmc.log(text, level)
        except Exception:
            try:
                from resources.lib import control
                control.log(text)
            except Exception:
                pass

    def _direct_url(self, title, year, season=0, imdb=''):
        if season > 0:
            return ''
        slug = self._slug(title)
        if not slug:
            return ''

        for candidate in self._find_direct_candidates(title, slug):
            if self._is_valid_detail(candidate, title, year, imdb, require_year=True):
                return candidate

        # Guessed slug URLs are especially ambiguous for remakes / identical titles.
        # Therefore they are only accepted when the detail page itself confirms the year
        # (or the exact IMDb id when KinoGer exposes one).
        for candidate in (self.base_link + '/stream/%s-stream.html' % slug, self.base_link + '/stream/%s.html' % slug):
            if self._is_valid_detail(candidate, title, year, imdb, require_year=True):
                return candidate
        return ''

    def _find_direct_candidates(self, title, slug):
        found, seen = [], set()
        pages = [self.base_link + '/']
        for search_title in (quote_plus(title), title):
            pages.append(self.search % search_title)
            pages.append(self.base_link + '/?do=search&subaction=search&titleonly=3&story=%s' % search_title)

        for page in pages:
            try:
                request = cRequestHandler(page, ignoreErrors=True)
                request.removeBreakLines(False)
                request.removeNewLines(False)
                request.cacheTime = 60 * 60 * 12
                html = request.request()
                for href in re.findall(r'href=["\']([^"\']*/stream/[^"\']+)["\']', html or '', re.I):
                    full = self._full_url(href)
                    if slug in full.lower() and full not in seen:
                        found.append(full)
                        seen.add(full)
            except Exception:
                pass
        return found

    def _detail_years(self, html):
        """Extract only years that look like movie metadata, not arbitrary footer/current years."""
        text = self._clean_html(html or '')
        years = set()
        patterns = (
            r'(?:jahr|year|release|released|erscheinungsjahr|veroeffentlichung|veröffentlichung)\s*[:\-]?\s*((?:19|20)\d{2})',
            r'\((?:19|20)\d{2}\)',
        )
        for pattern in patterns:
            for match in re.findall(pattern, text[:20000], re.I):
                if isinstance(match, tuple):
                    match = next((x for x in match if x), '')
                m = re.search(r'(?:19|20)\d{2}', str(match))
                if m:
                    years.add(m.group(0))
        # The HTML title often carries the release year even when the visible body does not.
        page_title = self._page_title(html)
        years.update(re.findall(r'(?<!\d)((?:19|20)\d{2})(?!\d)', page_title or ''))
        return years

    def _detail_imdb_ids(self, html):
        return set(x.lower() for x in re.findall(r'\btt\d{5,10}\b', html or '', re.I))

    def _is_valid_detail(self, url, title, year=0, imdb='', require_year=False):
        try:
            request = cRequestHandler(url, ignoreErrors=True)
            request.cacheTime = 60 * 60 * 12
            html = request.request()
            if not html:
                self._log('REJECT title=%r target_year=%s reason=empty-page url=%s' % (title, year, url))
                return False

            clean_title = cleantitle.get(title)
            page_title = self._page_title(html)
            page_head = cleantitle.get(page_title + ' ' + html[:5000])
            if clean_title and clean_title not in page_head:
                self._log('REJECT title=%r page_title=%r target_year=%s reason=title-mismatch url=%s' % (title, page_title, year, url))
                return False

            links = self._stream_entries(html)[1]
            if not links:
                self._log('REJECT title=%r page_title=%r target_year=%s reason=no-streams url=%s' % (title, page_title, year, url))
                return False

            wanted_imdb = ''
            m = re.search(r'(tt\d+)', str(imdb or ''), re.I)
            if m:
                wanted_imdb = m.group(1).lower()
            page_imdb = self._detail_imdb_ids(html)
            if wanted_imdb and page_imdb:
                if wanted_imdb not in page_imdb:
                    self._log('REJECT title=%r page_title=%r target_year=%s imdb=%s page_imdb=%s reason=imdb-mismatch url=%s' %
                              (title, page_title, year, wanted_imdb, sorted(page_imdb), url))
                    return False
                self._log('ACCEPT title=%r page_title=%r target_year=%s imdb=%s reason=imdb-match url=%s' %
                          (title, page_title, year, wanted_imdb, url))
                return True

            target_year = str(year or '').strip()
            page_years = self._detail_years(html)
            if target_year:
                # Movie matching must be exact here. A +/-1 tolerance is unsafe for
                # remakes / identical titles and caused a 2025 page marker to validate
                # a requested 2026 movie.
                allowed_years = {target_year}

                if page_years:
                    if not (page_years & allowed_years):
                        self._log('REJECT title=%r page_title=%r target_year=%s page_years=%s reason=year-mismatch url=%s' %
                                  (title, page_title, target_year, sorted(page_years), url))
                        return False
                    self._log('ACCEPT title=%r page_title=%r target_year=%s page_years=%s reason=year-match url=%s' %
                              (title, page_title, target_year, sorted(page_years), url))
                    return True

                if require_year:
                    self._log('REJECT title=%r page_title=%r target_year=%s reason=year-not-verifiable url=%s' %
                              (title, page_title, target_year, url))
                    return False

            self._log('ACCEPT title=%r page_title=%r target_year=%s reason=title-and-streams url=%s' %
                      (title, page_title, target_year, url))
            return True
        except Exception as exc:
            self._log('REJECT title=%r target_year=%s reason=exception:%s url=%s' % (title, year, exc, url))
            return False

    def _resolve_special_embed(self, url):
        """Resolve KinoGer wrapper embeds without handing HTML pages to Kodi."""
        if not url:
            return None
        original = str(url).strip()
        try:
            request = cRequestHandler(original, caching=False, ignoreErrors=True)
            request.addHeaderEntry('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36')
            request.addHeaderEntry('Referer', 'https://kinoger.com/')
            html = request.request() or ''
            try:
                real_url = request.getRealUrl()
            except Exception:
                real_url = ''

            # KinoGer.pw is used as a redirect wrapper (not a media URL).  If it
            # redirects to a supported host such as Veev/VOE, let ResolveURL do
            # the host-specific resolution.
            candidates = []
            if real_url and real_url != original:
                candidates.append(real_url)

            # Some wrappers expose the destination in iframe/source/script data.
            patterns = (
                r'<iframe[^>]+src=["\']([^"\']+)',
                r'<source[^>]+src=["\']([^"\']+)',
                r'(https?://[^"\'<>\\\s]+(?:\.m3u8|\.mp4)(?:\?[^"\'<>\\\s]*)?)',
                r'(https?://(?:[^/]+/)?(?:e|embed)/[A-Za-z0-9_-]+)'
            )
            for pattern in patterns:
                for found in re.findall(pattern, html, re.I):
                    found = found.replace('\\/', '/').replace('&amp;', '&').strip()
                    if found.startswith('//'):
                        found = 'https:' + found
                    if found.startswith('http') and found not in candidates:
                        candidates.append(found)

            for candidate in candidates:
                low = candidate.lower()
                if '.m3u8' in low or '.mp4' in low:
                    return candidate + '|Referer=' + quote_plus(original) + '&User-Agent=Mozilla%2F5.0'
                try:
                    hmf = resolveurl.HostedMediaFile(url=candidate, include_disabled=True, include_universal=False)
                    if hmf and hmf.valid_url():
                        media = hmf.resolve()
                        if media:
                            return media
                except Exception:
                    pass

            # Older KinoGer wrappers frequently contain a VOE-style /e/<id>.
            for media_id in re.findall(r'(?:voe\.[^/]+/e/|/e/)([A-Za-z0-9]{8,20})', html, re.I):
                try:
                    media = voesx.VoeResolver().get_media_url('voe.sx', media_id)
                    if media:
                        return media
                except Exception:
                    pass
        except Exception as exc:
            self._log('SPECIAL RESOLVE ERROR url=%s error=%s' % (original, exc))
        return None

    def _kinoger_be_sources(self, item, headers):
        sources = []
        request = cRequestHandler(item['url'], caching=False, ignoreErrors=True)
        request.addHeaderEntry('Referer', 'https://kinoger.com/')
        html = request.request()
        is_match, packed = cParser.parseSingleResult(html, r'(eval\s*\(function.*?)</script>')
        if is_match:
            from resources.lib import jsunpacker
            html = jsunpacker.unpack(packed)
        is_match, h_url = cParser.parseSingleResult(html, 'sources.*?file.*?(http[^"\']+)')
        if not is_match:
            return sources

        h_url = h_url.replace('\\', '')
        request = cRequestHandler(h_url, caching=False, ignoreErrors=True)
        request.addHeaderEntry('Referer', 'https://kinoger.be/')
        request.addHeaderEntry('Origin', 'https://kinoger.be')
        request.removeNewLines(False)
        m3u8 = request.request()
        if 'CF-DDOS-GUARD aktiv' in m3u8:
            return sources

        is_match, results = cParser.parse(m3u8, r'RESOLUTION=.*?x(\d+).*?\n(index[^\n]+)')
        if is_match:
            for quality, index in results:
                stream_url = h_url.split('video')[0].strip() + index.strip()
                stream_url += '|Origin=https%3A%2F%2Fkinoger.be&Referer=https%3A%2F%2Fkinoger.be%2F' + headers
                sources.append({'source': item['source'], 'quality': quality, 'language': 'de', 'url': stream_url, 'direct': True})
        return sources

    def _stream_entries(self, html):
        qualities = [self._clean_html(q) for q in re.findall(r'<label[^>]+title=["\']Stream\s*([^"\']*)["\'][^>]*>', html or '', re.I | re.S)]
        if not qualities:
            qualities = re.findall('title="Stream.(.+?)"', html or '')
        links = re.findall(r'(?:pw|fsst|go|ollhd|playerx|wolfstream)?\.show\s*\([^,]+,\s*(\[\[.+?\]\])', html or '', re.I | re.S)
        if not links:
            links = re.findall(r'.show.+?,(\[\[.+?\]\])', html or '', re.I | re.S)
        return qualities, links

    def _search_results(self, html):
        results, seen = [], set()
        try:
            for item in dom_parser.parse_dom(dom_parser.parse_dom(html, 'div', attrs={'class': 'title'}), 'a'):
                href = self._full_url(item.attrs.get('href', ''))
                name = self._clean_html(item.content)
                year = re.search(r'\((\d{4})', name)
                if href and href not in seen:
                    results.append((href, re.sub(r'\s*\(\d{4}.*?$', '', name).strip(), year.group(1) if year else ''))
                    seen.add(href)
        except Exception:
            pass

        for href, name in re.findall(r'<a[^>]+href=["\']([^"\']*?/stream/[^"\']+)["\'][^>]*>(.*?)</a>', html or '', re.I | re.S):
            href = self._full_url(href)
            name = self._clean_html(name)
            year = re.search(r'\((\d{4})\)', name)
            if href and name and href not in seen:
                results.append((href, re.sub(r'\s*\(\d{4}\).*?$', '', name).strip(), year.group(1) if year else ''))
                seen.add(href)
        return results

    def _full_url(self, url):
        url = (url or '').strip()
        if url.startswith('//'):
            return 'https:' + url
        if url.startswith('http'):
            return url
        if url.startswith('/'):
            return self.base_link + url
        return self.base_link + '/' + url if url else ''

    def _host_from_url(self, url):
        try:
            return urlparse(url).netloc.lower().replace('www.', '')
        except Exception:
            return ''

    def _slug(self, value):
        value = (value or '').lower().replace('&', ' and ')
        value = re.sub(r'[^a-z0-9äöüß]+', '-', value)
        value = value.replace('ä', 'ae').replace('ö', 'oe').replace('ü', 'ue').replace('ß', 'ss')
        return re.sub(r'-+', '-', value).strip('-')

    def _page_title(self, html):
        match = re.search(r'<title>(.*?)</title>', html or '', re.I | re.S)
        return self._clean_html(match.group(1)) if match else ''

    def _clean_html(self, value):
        value = re.sub(r'<[^>]+>', ' ', value or '')
        value = value.replace('&raquo;', ' ').replace('&amp;', '&').replace('&quot;', '"').replace('&#039;', "'")
        return re.sub(r'\s+', ' ', value).strip()

    def _normalize_quality(self, quality):
        quality = (quality or '').strip()
        if not quality:
            return 'SD'
        if quality == 'HD':
            return '720p'
        if quality == 'HD+':
            return '1080p'
        for q in ('2160', '1440', '1080', '720', '480', '360'):
            if q in quality:
                return '4K' if q == '2160' else q + 'p'
        return quality

    def _playback_headers(self, media_url):
        """Make direct HTTP playback less sticky when Kodi closes a stalled stream."""
        if not media_url:
            return media_url
        media_url = str(media_url)
        # ResolveURL may already return Kodi's URL|Header=Value syntax. Preserve its
        # session cookie/referer and only add transport hints that are safe for MP4/HLS.
        extra = 'Connection=close&Accept-Encoding=identity'
        if '|' in media_url:
            base, headers = media_url.split('|', 1)
            existing = headers.lower()
            additions = []
            if 'connection=' not in existing:
                additions.append('Connection=close')
            if 'accept-encoding=' not in existing:
                additions.append('Accept-Encoding=identity')
            return base + '|' + headers + (('&' + '&'.join(additions)) if additions else '')
        return media_url + '|' + extra

    def resolve(self, url):
        if not url:
            return None
        url_l = str(url).lower()
        if any(special in url_l for special in SPECIAL_EMBED_HOSTS):
            self._log('PLAYBACK RESOLVE start url=%s' % url)
            resolved = self._resolve_special_embed(url)
            if not resolved:
                self._log('PLAYBACK RESOLVE reject reason=unresolved url=%s' % url)
                return None
            resolved = self._playback_headers(resolved)
            self._log('PLAYBACK RESOLVE success host=%r url=%s' % (self._host_from_url(resolved.split('|', 1)[0]), resolved))
            return resolved
        return url
