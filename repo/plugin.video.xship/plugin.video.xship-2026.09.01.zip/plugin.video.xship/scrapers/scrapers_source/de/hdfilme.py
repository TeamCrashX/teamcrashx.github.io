# hdfilme (DLE CMS)
# edit 2026.04.10


import re
from resources.lib.utils import isBlockedHoster
from scrapers.modules.tools import cParser
from resources.lib.requestHandler import cRequestHandler
from resources.lib.control import getSetting, quote_plus
from scrapers.modules import cleantitle

SITE_IDENTIFIER = 'hdfilme'
SITE_DOMAIN = 'hdfilme-de.my'
SITE_NAME = SITE_IDENTIFIER.upper()

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['de']
        self.domain = getSetting('provider.' + SITE_IDENTIFIER + '.domain', SITE_DOMAIN)
        self.base_link = 'https://' + self.domain
        self.search_link = self.base_link + '/index.php?do=search&subaction=search&story=%s'
        self.sources = []

    @staticmethod
    def _map_quality(sRaw):
        q = sRaw.upper()
        if '4K' in q or '2160' in q:             return '4K'
        if '1080' in q or 'WEBRIP' in q \
                       or 'BDRIP' in q:           return '1080p'
        if '720' in q or 'HD' in q:               return '720p'
        if 'CAM' in q or 'TS' in q:               return 'CAM'
        if 'SD' in q or '480' in q or 'DVD' in q: return 'SD'
        return 'HD'

    def _add_source(self, sUrl, quality, seen):
        if not sUrl:
            return
        if sUrl.startswith('//'):
            sUrl = 'https:' + sUrl
        elif sUrl.startswith('/'):
            # interne Links (z.B. /vod/...) überspringen
            return
        if not sUrl.startswith('http'):
            return
        if 'youtube' in sUrl:
            return
        # Leere Hoster-URLs ohne ID
        last = sUrl.rstrip('/').split('/')[-1]
        if not last or len(last) < 3:
            return
        # embed-.html Platzhalter
        if re.search(r'/embed[^/]*\.html$', sUrl):
            return
        if sUrl in seen:
            return
        seen.add(sUrl)
        isBlocked, hoster, url, prioHoster = isBlockedHoster(sUrl)
        if isBlocked or not url:
            return
        self.sources.append({
            'source':     hoster,
            'quality':    quality,
            'language':   'de',
            'url':        url,
            'direct':     True,
            'prioHoster': prioHoster
        })

    def run(self, titles, year, season=0, episode=0, imdb='', hostDict=None):
        self.sources = []
        try:
            t     = set([cleantitle.get(i) for i in set(titles) if i])
            years = (year, year + 1, year - 1, 0)
            links = []

            # ── Suche ────────────────────────────────────────────────────────
            for sSearchText in titles:
                try:
                    oRequest = cRequestHandler(self.search_link % quote_plus(sSearchText))
                    oRequest.cacheTime = 60 * 60 * 6
                    sHtml = oRequest.request()
                    if not sHtml:
                        continue

                    pattern = r'<div class="box-product(.*?)<h3.*?href="([^"]+).*?">([^<]+).*?(.*?)</li>'
                    isMatch, aResult = cParser.parse(sHtml, pattern)
                    if not isMatch:
                        continue

                    def _parse_hit(sInfo, sUrl, sName, sDummy):
                        # Qualität direkt aus Suchergebnis-Span
                        q_m = re.search(r'quality-product">([^<]+)', sDummy)
                        sQuality = self._map_quality(q_m.group(1).strip()) if q_m else 'HD'
                        # Jahr
                        yr_m = re.search(r'([\d]{4})\s*</p>', sDummy)
                        sYear = int(yr_m.group(1)) if yr_m else 0
                        return sQuality, sYear

                    if season == 0:
                        # Filme: exakter Titel-Match
                        for sInfo, sUrl, sName, sDummy in aResult:
                            if 'taffel' in sName or 'eason' in sName:
                                continue
                            sQuality, sYear = _parse_hit(sInfo, sUrl, sName, sDummy)
                            if sYear not in years:
                                continue
                            if cleantitle.get(sName.strip()) in t:
                                links.append({'url': sUrl, 'quality': sQuality})

                        # Fallback: Substring-Match
                        if not links:
                            for sInfo, sUrl, sName, sDummy in aResult:
                                if 'taffel' in sName or 'eason' in sName:
                                    continue
                                sQuality, sYear = _parse_hit(sInfo, sUrl, sName, sDummy)
                                if sYear not in years:
                                    continue
                                name_clean = cleantitle.get(sName.strip())
                                if any(a in name_clean for a in t):
                                    links.append({'url': sUrl, 'quality': sQuality})
                    else:
                        # Serien: "Staffel N" im Titel suchen
                        # Jede Staffel ist ein eigener Eintrag auf hdfilme-de.my
                        for sInfo, sUrl, sName, sDummy in aResult:
                            sName = sName.strip()
                            if 'taffel' not in sName:
                                continue
                            # Staffelnummer per Regex (split('- S') bricht bei Titeln
                            # die selbst ein '- S' enthalten, z.B. "Vongozero - Flucht zum See")
                            s_m = re.search(r'Staffel\s+(\d+)', sName)
                            if not s_m:
                                continue
                            # Exakter int-Vergleich verhindert S1 matcht S12
                            if int(s_m.group(1)) != int(season):
                                continue
                            title_part = re.sub(r'\s*[-–]\s*Staffel\s+\d+.*$', '', sName).strip()
                            if cleantitle.get(title_part) in t:
                                links.append({'url': sUrl, 'quality': 'HD'})

                    if links:
                        break
                except Exception:
                    continue

            if not links:
                return self.sources

            # ── Detailseiten ─────────────────────────────────────────────────
            seen = set()
            for link in links:
                try:
                    oRequest = cRequestHandler(link['url'], bypass_dns=True, ssl_verify=False)
                    oRequest.cacheTime = 60 * 60 * 6
                    sHtml = oRequest.request()
                    if not sHtml:
                        continue

                    if season > 0:
                        # Primär: Episodenname als Anker (wie xstream)
                        ep_names = re.findall(r'"><a href="#">([^<]+)', sHtml)
                        ep_name  = next((e for e in ep_names if str(episode) in e), None)
                        if ep_name:
                            ep_m = re.search(re.escape(ep_name) + r'.*?</ul>', sHtml, re.DOTALL)
                        else:
                            # Fallback: data-num="SxE"
                            ep_m = re.search(
                                r'data-num="%sx%s".*?</li>' % (season, episode),
                                sHtml, re.DOTALL)
                        if not ep_m:
                            continue
                        block = ep_m.group(0)
                        # hdfilme-de.my nutzt link="..." (nicht data-link=)
                        for sUrl in re.findall(r'\blink="([^"]+)"', block):
                            self._add_source(sUrl, 'HD', seen)
                    else:
                        # Filme: alle data-link in <ul class="mirrors">
                        # Label aus dem <li> Inhalt (HTML-Tags entfernen)
                        for sUrl, sRaw in re.findall(
                                r'data-link="([^"]+)"[^>]*>(.*?)</li>',
                                sHtml, re.DOTALL):
                            sLabel   = re.sub(r'<[^>]+>', '', sRaw).strip()
                            sQuality = self._map_quality(sLabel) if sLabel else link['quality']
                            self._add_source(sUrl, sQuality, seen)

                except Exception:
                    continue

        except Exception:
            pass

        return self.sources

    def resolve(self, url):
        return url
