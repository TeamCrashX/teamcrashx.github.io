# primekiste.py (xShip Quellen-Scraper)
# Speicherarme Suche: direkter API-Suchversuch + Paging-Fallback

import json
import re
import time
from urllib.parse import quote_plus

from scrapers.modules import cleantitle
from resources.lib.utils import isBlockedHoster
from resources.lib.control import getSetting
from resources.lib.requestHandler import cRequestHandler
from resources.lib import log_utils

SITE_IDENTIFIER = 'movie4k'
SITE_DOMAIN = 'movie4k.sx'
SITE_NAME = SITE_IDENTIFIER.upper()



def _hoster_limit_settings():
    """Liest das vorhandene xShip-Hosterlimit.

    Bei deaktiviertem Schalter wird kein Limit angewendet. Der Zahlenwert
    stammt aus ``hosts.limit.num`` und wird nur bei aktivem Schalter benutzt.
    """
    enabled = str(getSetting('hosts.limit', 'false')).strip().lower() in (
        'true', '1', 'yes', 'on'
    )
    try:
        limit = max(1, int(float(getSetting('hosts.limit.num', '15'))))
    except (TypeError, ValueError):
        limit = 15
    return enabled, limit


class source:
    PAGE_SIZE = 100
    MAX_PAGES = 10  # stable-fast patch: avoid full-catalog crawl after API miss
    MAX_SERIES_FALLBACK_PAGES = 3
    MAX_INPUT_STREAMS_TO_SCAN = 100
    MAX_SOURCES_PER_SCRAPER = 8
    MAX_PROCESS_SECONDS = 10

    def __init__(self):
        self.priority = 1
        self.language = ['de']
        # Kodi-Enum liefert den gewählten Index. Bereits gespeicherte
        # Domaintexte älterer Installationen werden weiterhin unterstützt.
        domain_setting = getSetting('provider.' + SITE_IDENTIFIER + '.domain', '0')
        domain_options = {
            '0': 'movie4k.sx',
            '1': 'movie4k.ag',
            '2': 'movie4k.stream',
            '3': 'movie4k.at',
        }
        selected = domain_options.get(
            str(domain_setting).strip(),
            str(domain_setting).strip()
        )
        selected = selected.replace('https://', '').replace('http://', '').strip().strip('/')
        self.domain = selected or SITE_DOMAIN
        self.base_link = 'https://' + self.domain
        self.sources = []

    def _fetch(self, url):
        try:
            oRequest = cRequestHandler(url, caching=True)
            oRequest.cacheTime = 60 * 60 * 6
            oRequest.addHeaderEntry('Origin', self.base_link)
            oRequest.addHeaderEntry('Referer', self.base_link + '/')
            oRequest.addHeaderEntry('Accept', 'application/json, text/plain, */*')
            oRequest.addHeaderEntry('Accept-Language', 'de-DE,de;q=0.9,en-US;q=0.8,en;q=0.7')
            oRequest.addHeaderEntry('X-Requested-With', 'XMLHttpRequest')
            return oRequest.request()
        except Exception as e:
            log_utils.log('[%s] _fetch Fehler: %s' % (SITE_NAME, str(e)[:200]), log_utils.LOGWARNING)
            return ''

    @staticmethod
    def _movies_from_json(data):
        if not data:
            return []
        try:
            obj = json.loads(data)
        except Exception:
            return []

        if isinstance(obj, list):
            return obj
        if not isinstance(obj, dict):
            return []

        for key in ('movies', 'results', 'items', 'data'):
            value = obj.get(key)
            if isinstance(value, list):
                return value
            if isinstance(value, dict):
                for subkey in ('movies', 'results', 'items'):
                    nested = value.get(subkey)
                    if isinstance(nested, list):
                        return nested
        return []

    def _search_api(self, titles, media_type, imdb=''):
        """Probiert bekannte/übliche Varianten der React-API.

        Nur Antworten mit einer Filmliste werden akzeptiert. Unbekannte oder
        nicht vorhandene Endpunkte sind dadurch harmlos; danach greift Paging.
        """
        terms = []
        if imdb:
            terms.append(imdb)
        terms.extend([title for title in titles if title])

        seen_urls = set()
        candidates = []
        for term in terms:
            q = quote_plus(str(term))
            candidates.extend([
                self.base_link + '/data/search/?q=' + q + '&type=' + media_type,
                self.base_link + '/data/search/?query=' + q + '&type=' + media_type,
                self.base_link + '/data/search/?search=' + q + '&type=' + media_type,
                self.base_link + '/data/browse/?lang=all&order_by=new&page=1&limit=100&type=' + media_type + '&search=' + q,
                self.base_link + '/data/browse/?lang=all&order_by=new&page=1&limit=100&type=' + media_type + '&q=' + q,
                self.base_link + '/data/browse/?lang=all&order_by=new&page=1&limit=100&type=' + media_type + '&query=' + q,
            ])

        for url in candidates:
            if url in seen_urls:
                continue
            seen_urls.add(url)
            data = self._fetch(url)
            movies = self._movies_from_json(data)
            if movies:
                log_utils.log('[%s] API-Suche: %d Kandidaten über %s' % (
                    SITE_NAME, len(movies), url.split('/data/', 1)[-1][:120]), log_utils.LOGINFO)
                return movies

        log_utils.log('[%s] API-Suche ohne verwertbare Treffer; Paging-Fallback' % SITE_NAME,
                      log_utils.LOGINFO)
        return []

    def _load_page(self, page, media_type):
        url = self.base_link + '/data/browse/?lang=all&order_by=new&page=%d&limit=%d' % (
            page, self.PAGE_SIZE) + '&type=' + media_type
        data = self._fetch(url)
        movies = self._movies_from_json(data)
        log_utils.log('[%s] _load_page: Seite %d, %d Eintraege geladen' % (
            SITE_NAME, page, len(movies)), log_utils.LOGINFO)
        return movies

    @staticmethod
    def _quality(release, resolution=''):
        """Normalisiert Aufloesung und Aufnahmeart.

        TS/CAM haben Vorrang vor Zahlenangaben, damit etwa
        ``TELESYNC.1080p`` nicht als echter 1080p-Stream erscheint.
        """
        value = ('%s %s' % (resolution or '', release or '')).upper()
        compact = re.sub(r'[^A-Z0-9]+', ' ', value)
        tokens = set(compact.split())

        if 'TELESYNC' in compact or 'TS' in tokens:
            return 'TS'
        if 'CAM' in tokens or 'HDCAM' in compact:
            return 'CAM'
        if '4K' in tokens or '2160' in compact:
            return '4K'
        if '1440' in compact:
            return '1440p'
        if '1080' in compact:
            return '1080p'
        if '720' in compact:
            return '720p'
        if ('HD' in tokens or 'WEB' in tokens or 'WEBDL' in compact or
                'BLURAY' in compact or 'BRRIP' in compact):
            return 'HD'
        if 'SD' in tokens or '480' in compact:
            return 'SD'
        return 'SD'

    @classmethod
    def _stream_priority(cls, stream):
        if not isinstance(stream, dict):
            return -1
        quality = cls._quality(stream.get('release', ''), stream.get('res', ''))
        return {
            '4K': 70,
            '1440p': 65,
            '1080p': 60,
            '720p': 50,
            'HD': 40,
            'SD': 30,
            'TS': 10,
            'CAM': 0,
        }.get(quality, 20)

    def _get_streams(self, _id, season=0, episode=0):
        url = self.base_link + '/data/watch/?_id=%s' % _id
        data = self._fetch(url)
        if not data:
            log_utils.log('[%s] _get_streams: keine Daten fuer _id=%s' % (SITE_NAME, _id),
                          log_utils.LOGWARNING)
            return
        try:
            obj = json.loads(data)
        except Exception as e:
            log_utils.log('[%s] _get_streams JSON-Fehler: %s | Antwort: %s' % (
                SITE_NAME, str(e), data[:200]), log_utils.LOGWARNING)
            return

        log_utils.log('[%s] _get_streams: title="%s" imdb=%s' % (
            SITE_NAME, obj.get('title', ''), obj.get('imdb_id', '')), log_utils.LOGINFO)

        _skip = (
            'veev.to', 'veevcdn', 'vide0.net', 'vidsonic.net',
            'vidara.to', 'vidara.so', 'vidara.si',
            'bonuscaf.com', 'playmogo.com',
            'vinovo.to', 'vinovo.si', 'bonuscaf.com', 'playmogo.com',
            'dood.re', 'dood.to', 'dood.li', 'doods.pro',
            'doodstream.com', 'doodstream.co', 'ds2video.com', 'dsvplay.com',
            'streamtape',
        )

        streams = obj.get('streams', [])
        log_utils.log('[%s] _get_streams: %d Streams in Antwort' % (
            SITE_NAME, len(streams)), log_utils.LOGINFO)

        seen_urls = set()
        hoster_count = {}
        limit_enabled, max_per_hoster = _hoster_limit_settings()
        accepted_before = len(self.sources)
        scan_started = time.time()
        scanned_streams = 0
        if season > 0:
            stream_pool = [
                s for s in streams
                if isinstance(s, dict) and str(s.get('e', '')) == str(episode)
            ]
        else:
            stream_pool = [s for s in streams if isinstance(s, dict)]

        # Die Watch-API mischt aktuelle hochwertige Releases mit vielen
        # historischen TS/CAM-Mirrors. Zuerst nach echter Qualitaet sortieren,
        # innerhalb derselben Stufe neuere Eintraege bevorzugen und erst danach
        # das bestehende 100er-Kandidatenlimit anwenden.
        indexed_streams = list(enumerate(stream_pool))
        indexed_streams.sort(
            key=lambda pair: (self._stream_priority(pair[1]), pair[0]),
            reverse=True
        )
        candidate_streams = [
            item for _, item in indexed_streams[:self.MAX_INPUT_STREAMS_TO_SCAN]
        ]

        quality_counts = {}
        for item in candidate_streams:
            quality = self._quality(item.get('release', ''), item.get('res', ''))
            quality_counts[quality] = quality_counts.get(quality, 0) + 1
        log_utils.log('[%s] Qualitaetsauswahl: Pool=%d Kandidaten=%d Verteilung=%s' % (
            SITE_NAME, len(stream_pool), len(candidate_streams), quality_counts), log_utils.LOGINFO)

        for stream in candidate_streams:
            scanned_streams += 1
            if time.time() - scan_started > self.MAX_PROCESS_SECONDS:
                log_utils.log('[%s] Arbeitslimit erreicht: %ds, %d Kandidaten geprueft, %d Quellen' % (SITE_NAME, self.MAX_PROCESS_SECONDS, scanned_streams, len(self.sources) - accepted_before), log_utils.LOGWARNING)
                break
            if season > 0 and str(stream.get('e', '')) != str(episode):
                continue

            sUrl = stream.get('stream', '')
            sQuality = self._quality(stream.get('release', ''), stream.get('res', ''))
            if not sUrl:
                continue

            url_key = sUrl.rstrip('/')
            if url_key in seen_urls:
                continue
            seen_urls.add(url_key)

            if any(x in sUrl for x in (self.domain, 'movie4k')):
                continue
            if any(x in sUrl for x in _skip):
                continue

            try:
                from urllib.parse import urlparse
                host = urlparse('https:' + sUrl if sUrl.startswith('//') else sUrl).hostname or sUrl
            except Exception:
                host = sUrl

            if limit_enabled:
                hoster_count[host] = hoster_count.get(host, 0) + 1
                if hoster_count[host] > max_per_hoster:
                    continue

            # Bewusst wie in der funktionierenden Originaldatei:
            # nur erfolgreich aufgelöste Streams werden zurückgegeben.
            isBlocked, hoster, url, prioHoster = isBlockedHoster(sUrl, isResolve=False)
            if isBlocked or not url:
                continue

            log_utils.log('[%s] Stream akzeptiert: %s [%s]' % (
                SITE_NAME, sUrl, sQuality), log_utils.LOGINFO)
            self.sources.append({
                'source': hoster,
                'quality': sQuality,
                'language': 'de',
                'url': sUrl,
                'direct': False,
                'prioHoster': prioHoster,
            })
            if len(self.sources) - accepted_before >= self.MAX_SOURCES_PER_SCRAPER:
                log_utils.log('[%s] Quellen-Arbeitslimit erreicht: %d' % (SITE_NAME, self.MAX_SOURCES_PER_SCRAPER), log_utils.LOGINFO)
                break
        log_utils.log('[%s] Arbeitsmenge: %d/%d Kandidaten geprueft, %d Quellen' % (SITE_NAME, scanned_streams, len(candidate_streams), len(self.sources) - accepted_before), log_utils.LOGINFO)

    def _check_movies(self, movies, clean_titles, years, season, episode):
        for movie in movies:
            if not isinstance(movie, dict) or '_id' not in movie:
                continue

            sTitle = movie.get('title', '')
            sYear = str(movie.get('year', ''))

            if season > 0:
                base = sTitle.rsplit('-', 1)[0].strip() if '-' in sTitle else sTitle
                season_part = sTitle.rsplit('-', 1)[1].strip() if '-' in sTitle else ''
                if cleantitle.get(base) in clean_titles and str(season) in season_part:
                    log_utils.log('[%s] Serien-Treffer: "%s" _id=%s' % (
                        SITE_NAME, sTitle, movie['_id']), log_utils.LOGINFO)
                    self._get_streams(str(movie['_id']), season, episode)
            elif cleantitle.get(sTitle) in clean_titles and sYear in years:
                log_utils.log('[%s] Treffer: "%s" (%s) _id=%s' % (
                    SITE_NAME, sTitle, sYear, movie['_id']), log_utils.LOGINFO)
                self._get_streams(str(movie['_id']))

            if self.sources:
                return True
        return False

    def run(self, titles, year, season=0, episode=0, imdb='', hostDict=None):
        self.sources = []
        log_utils.log('[%s] run() start: titles=%s year=%s season=%s episode=%s imdb=%s' % (
            SITE_NAME, titles, year, season, episode, imdb), log_utils.LOGINFO)

        try:
            clean_titles = set(cleantitle.get(i) for i in set(titles) if i)
            year_int = int(year)
            years = [str(year_int - 1), str(year_int), str(year_int + 1)]

            # 1. Schnelle API-Suche. Die Treffer werden streng nach Titel/Jahr geprüft.
            media_type = 'tvseries' if season > 0 else 'movies'
            candidates = self._search_api(titles, media_type, imdb)
            if candidates and self._check_movies(candidates, clean_titles, years, season, episode):
                return self.sources

            # 2. Speicherarmer Paging-Fallback. Es liegt immer nur eine Seite im RAM.
            previous_signature = None
            page_limit = self.MAX_SERIES_FALLBACK_PAGES if season > 0 else self.MAX_PAGES
            if season > 0:
                log_utils.log('[%s] Serien-Katalog-Fallback auf %d Seiten begrenzt' % (
                    SITE_NAME, page_limit), log_utils.LOGINFO)
            for page in range(1, page_limit + 1):
                movies = self._load_page(page, media_type)
                if not movies:
                    break

                signature = tuple(str(m.get('_id', '')) for m in movies[:5] if isinstance(m, dict))
                if signature and signature == previous_signature:
                    log_utils.log('[%s] Paging-Abbruch: Seite %d wiederholt Seite %d' % (
                        SITE_NAME, page, page - 1), log_utils.LOGWARNING)
                    break
                previous_signature = signature

                if self._check_movies(movies, clean_titles, years, season, episode):
                    break

                if len(movies) < self.PAGE_SIZE:
                    break

        except Exception as e:
            log_utils.log('[%s] run() Fehler: %s' % (SITE_NAME, str(e)[:200]),
                          log_utils.LOGWARNING)

        log_utils.log('[%s] run() end: %d Quellen gesamt' % (
            SITE_NAME, len(self.sources)), log_utils.LOGINFO)
        return self.sources

    def resolve(self, url):
        return url
