# megakino
# 2022-07-19
# edit 2026-03-29

from resources.lib.utils import isBlockedHoster
import re
from scrapers.modules.tools import cParser
from resources.lib.requestHandler import cRequestHandler
from scrapers.modules import cleantitle, dom_parser
from resources.lib.control import getSetting, quote_plus

SITE_IDENTIFIER = 'megakino'
SITE_DOMAIN = 'megakino3.tv'
SITE_NAME = SITE_IDENTIFIER.upper()


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['de']
        self.domain = getSetting('provider.' + SITE_IDENTIFIER + '.domain', SITE_DOMAIN)
        self.base_link = 'https://' + self.domain
        self.search_link = self.base_link + '/?do=search&subaction=search&story=%s'
        self.sources = []

    def _getHtml(self, url):
        # FIX: bypass_dns=True + cacheTime=0 wie im Original
        oRequest = cRequestHandler(url, bypass_dns=True)
        oRequest.cacheTime = 0
        oRequest.addHeaderEntry('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36')
        oRequest.addHeaderEntry('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8')
        oRequest.addHeaderEntry('Accept-Language', 'de-DE,de;q=0.9,en;q=0.8')
        oRequest.addHeaderEntry('Referer', self.base_link + '/')
        sHtmlContent = oRequest.request()

        # FIX: Token-Handling - DER echte Grund warum die Seite leer zurückkommt!
        if sHtmlContent and 'yg=token' in sHtmlContent:
            token_url = self.base_link + '/index.php?yg=token'
            oToken = cRequestHandler(token_url, bypass_dns=True)
            oToken.cacheTime = 0
            oToken.addHeaderEntry('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36')
            oToken.addHeaderEntry('Accept', '*/*')
            oToken.addHeaderEntry('Referer', url)
            oToken.addHeaderEntry('X-Requested-With', 'XMLHttpRequest')
            oToken.request()  # Token abholen - setzt Cookie

            # Jetzt nochmal mit gesetztem Cookie
            oRequest2 = cRequestHandler(url, bypass_dns=True)
            oRequest2.cacheTime = 0
            oRequest2.addHeaderEntry('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36')
            oRequest2.addHeaderEntry('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8')
            oRequest2.addHeaderEntry('Accept-Language', 'de-DE,de;q=0.9,en;q=0.8')
            oRequest2.addHeaderEntry('Referer', self.base_link + '/')
            sHtmlContent = oRequest2.request()

        if sHtmlContent and len(sHtmlContent) > 1000:
            return sHtmlContent
        return None

    def run(self, titles, year, season=0, episode=0, imdb='', hostDict=None):
        self.sources = []
        try:
            t = set([cleantitle.get(i) for i in set(titles) if i])
            years = (year, year + 1, year - 1, 0)
            links = []

            for sSearchText in titles:
                try:
                    sHtmlContent = self._getHtml(self.search_link % quote_plus(sSearchText))
                    if not sHtmlContent:
                        continue

                    # Serien
                    if season > 0:
                        pattern = r'<a class="poster grid-item[^>]*href="([^"]+)"[^>]*>.*?alt="([^"]+)"'
                        isMatch, aResult = cParser.parse(sHtmlContent, pattern)
                        if not isMatch:
                            continue
                        for sUrl, sName in aResult:
                            # "Breaking Bad - Staffel 5" -> "Staffel N" kommt nach dem Bindestrich
                            sNameClean = re.split(r'\s*[-–]\s*Staffel\s+\d+', sName)[0].strip()
                            if cleantitle.get(sNameClean) in t:
                                m = re.search(r'Staffel\s+(\d+)', sName)
                                if m and int(m.group(1)) == season:
                                    if not sUrl.startswith('http'):
                                        sUrl = self.base_link + sUrl
                                    links.append({'url': sUrl, 'name': sNameClean})

                    # Filme
                    else:
                        pattern = r'<a class="poster grid-item[^>]*href="([^"]+)"[^>]*>.*?alt="([^"]+)".*?<li>[^<]*?(\d{4})[^<]*</li>'
                        isMatch, aResult = cParser.parse(sHtmlContent, pattern)
                        if isMatch:
                            for sUrl, sName, sYear in aResult:
                                if int(sYear) not in years:
                                    continue
                                if not sUrl.startswith('http'):
                                    sUrl = self.base_link + sUrl
                                if cleantitle.get(sName) in t:
                                    links.append({'url': sUrl, 'name': sName, 'year': sYear})
                                elif any(a and a in cleantitle.get(sName) for a in t):
                                    links.append({'url': sUrl, 'name': sName, 'year': sYear})

                except Exception:
                    continue

                if links:
                    break

            if not links:
                return self.sources

            for link in links:
                try:
                    sHtmlContent = self._getHtml(link['url'])
                    if not sHtmlContent:
                        continue

                    if season > 0:
                        # Episoden-Select
                        # episodeId auf megakino3.tv: <select id="ep1x1"> (season x episode)
                        pattern = r'<select[^>]+id="ep%sx%s"[^>]*>(.*?)</select>' % (str(season), str(episode))
                        isMatch, aResult = cParser.parse(sHtmlContent, pattern)
                        if not isMatch or not aResult:
                            continue
                        isMatch, aUrls = cParser.parse(aResult[0], r'value="([^"]+)"')
                        if not isMatch:
                            continue
                        urls = aUrls
                        quality = 'HD'
                    else:
                        # Qualität
                        pattern = r'class="poster__label">([^<]+)'
                        isMatch, aResult = cParser.parse(sHtmlContent, pattern)
                        if isMatch and aResult:
                            q = aResult[0].strip().upper()
                            quality = '1080p' if '1080' in q else 'CAM' if 'CAM' in q else 'SD' if 'LD' in q else 'HD'
                        else:
                            quality = 'HD'

                        # FIX: iframe-Pattern aus der funktionierenden Version
                        # '<iframe.*?src=([^\s]+)' - ohne Anführungszeichen!
                        pattern = r'<iframe[^>]*src=["\']?(https?://[^"\'>\s]+)'
                        isMatch, aResult = cParser.parse(sHtmlContent, pattern)
                        if not isMatch:
                            # Fallback: data-src
                            pattern = r'<iframe[^>]*data-src=["\']?(https?://[^"\'>\s]+)'
                            isMatch, aResult = cParser.parse(sHtmlContent, pattern)
                        if not isMatch:
                            continue
                        urls = aResult

                    for sUrl in urls:
                        sUrl = sUrl.replace('"', '').replace("'", "").strip()
                        if not sUrl.startswith('http'):
                            continue
                        if 'youtube' in sUrl:
                            continue
                        try:
                            isBlocked, hoster, resolved_url, prioHoster = isBlockedHoster(sUrl)
                            if isBlocked:
                                continue
                            if resolved_url:
                                self.sources.append({
                                    'source': hoster,
                                    'quality': quality,
                                    'language': 'de',
                                    'url': resolved_url,
                                    'direct': True,
                                    'prioHoster': prioHoster
                                })
                        except Exception:
                            continue

                except Exception:
                    continue

        except Exception:
            pass

        return self.sources

    def resolve(self, url):
        try:
            return url
        except Exception:
            return None
