# filmpro.py
# 2024-06-02
# edit 2026-04-04 


import re
import html as _html
from urllib.parse import urlparse                        

from resources.lib.utils import isBlockedHoster
from resources.lib.requestHandler import cRequestHandler
from scrapers.modules import cleantitle
from scrapers.modules.tools import cParser
from resources.lib.control import getSetting, quote_plus

SITE_IDENTIFIER = 'filmpro'
SITE_DOMAIN     = 'filmpalast.one'
SITE_NAME       = SITE_IDENTIFIER.upper()

_MEINECLOUD = 'https://meinecloud.click'
_SEARCH_TPL = 'https://{domain}/?story={q}&do=search&subaction=search'


class source:
    def __init__(self):
        self.priority  = 1
        self.language  = ['de']
        self.domain    = getSetting('provider.' + SITE_IDENTIFIER + '.domain', SITE_DOMAIN)
        self.base_link = 'https://' + self.domain

    def _fetch(self, url, cache_hours=24, referer=None):
        
        oReq = cRequestHandler(url, bypass_dns=True, ssl_verify=False)
        oReq.cacheTime = 60 * 60 * cache_hours
        oReq.addHeaderEntry('Referer', referer or self.base_link + '/')
        # KEIN addHeaderEntry('User-Agent', ...) – RandomUA() übernimmt das
        return oReq.request() or ''

    def _fetch_fresh(self, url, referer=None):
        """Kurzlebige Serien-Playerseiten immer frisch laden."""
        oReq = cRequestHandler(url, caching=False, bypass_dns=True, ssl_verify=False)
        oReq.cacheTime = 0
        oReq.addHeaderEntry('Referer', referer or self.base_link + '/')
        return oReq.request() or ''

    @staticmethod
    def _normalise_link(link):
        link = _html.unescape((link or '').strip()).replace('\\/', '/')
        if link.startswith('//'):
            link = 'https:' + link
        return link if link.startswith('http') else ''

    def _series_link_from_player(self, player_url, episode):
        """Passenden data-link aus der MeineCloud-Playerseite lesen."""
        sHtml = self._fetch_fresh(player_url, referer=self.base_link + '/')
        if not sHtml:
            return ''

        # Bevorzugt: data-episode und data-link im selben Element/Block.
        ep = str(int(episode))
        patterns = [
            r'data-episode=["\']?' + re.escape(ep) + r'["\']?[^>]*data-link=["\']([^"\']+)',
            r'data-link=["\']([^"\']+)["\'][^>]*data-episode=["\']?' + re.escape(ep) + r'["\']?',
        ]
        for pattern in patterns:
            match = re.search(pattern, sHtml, flags=re.IGNORECASE | re.DOTALL)
            if match:
                link = self._normalise_link(match.group(1))
                if link:
                    return link

        # Kompatibilitäts-Fallback der funktionierenden Referenz:
        # data-link-Liste entspricht der Episodenreihenfolge.
        links = re.findall(r'data-link=["\']([^"\']+)["\']', sHtml,
                           flags=re.IGNORECASE)
        links = [self._normalise_link(x) for x in links]
        links = [x for x in links if x and 'youtube' not in x]
        if not links:
            return ''
        try:
            idx = max(0, int(episode) - 1)
        except Exception:
            idx = 0
        return links[idx] if idx < len(links) else links[0]


    def _resolve_series_embed(self, url):
        """Dr0pstream/Dropload-Embed leichtgewichtig zur direkten Datei auflösen."""
        lower = (url or '').lower()
        if not any(host in lower for host in ('dr0pstream.', 'dropload.')):
            return ''
        try:
            oReq = cRequestHandler(url, caching=False, bypass_dns=True, ssl_verify=False)
            oReq.cacheTime = 0
            oReq.requestTimeout = 4
            oReq.addHeaderEntry('Referer', _MEINECLOUD + '/')
            oReq.addHeaderEntry('Origin', _MEINECLOUD)
            sHtml = oReq.request() or ''
            patterns = (
                r'["\'](https?://[^"\'<>\s]*dropcdn[^"\'<>\s]*\.m3u8[^"\'<>\s]*)["\']',
                r'["\'](https?://[^"\'<>\s]*\.m3u8[^"\'<>\s]*)["\']',
                r'["\'](https?://[^"\'<>\s]*\.mp4[^"\'<>\s]*)["\']',
                r'file\s*[=:]\s*["\'](https?://[^"\'<>\s]+)["\']',
                r'source\s*[=:]\s*["\'](https?://[^"\'<>\s]+)["\']',
            )
            for pattern in patterns:
                match = re.search(pattern, sHtml, flags=re.IGNORECASE)
                if not match:
                    continue
                stream_url = _html.unescape(match.group(1)).replace('\\/', '/').strip()
                if not stream_url.startswith('http'):
                    continue
                if '|' not in stream_url:
                    origin = 'https://dr0pstream.com' if 'dr0pstream.' in lower else 'https://dropload.co'
                    stream_url += '|Referer=%s/&Origin=%s' % (origin, origin)
                return stream_url
        except Exception:
            pass
        return ''

    @staticmethod
    def _append_direct_source(sources, link, quality):
        hoster = urlparse(link.split('|', 1)[0]).hostname or 'direct'
        sources.append({
            'source': hoster,
            'quality': quality,
            'language': 'de',
            'url': link,
            'direct': True,
            'prioHoster': 100,
        })

    @staticmethod
    def _quality(raw):
        q = raw.strip().upper()
        if '4K' in q or '2160' in q: return '4K'
        if '1080' in q:               return '1080p'
        if '720'  in q:               return '720p'
        if 'CAM'  in q or 'TS' in q: return 'CAM'
        if 'SD'   in q or 'LD' in q: return 'SD'
        return 'HD'

    @staticmethod
    def _clean(s):
        s = _html.unescape(s)
        s = re.sub(r'\s*[–\-]\s*Der\s+Film\s*$',  '', s, flags=re.IGNORECASE)
        s = re.sub(r'\s*[–\-]\s*Die\s+Serie\s*$', '', s, flags=re.IGNORECASE)
        return cleantitle.get(s)

    def _search(self, titles, year):
        t     = [self._clean(i) for i in titles if i]
        years = (str(year), str(int(year) + 1), str(int(year) - 1))
        pattern = (
            r'href="(https?://[^"]+/stream/[^"]+)"[^>]*>'
            r'.*?class="Title">([^<]+)</h3>'
            r'\s*<span class="Year">(\d+)</span>'
            r'.*?class="Qlty">([^<]+)</span>'
        )
        for title in titles:
            try:
                sHtml = self._fetch(
                    _SEARCH_TPL.format(domain=self.domain, q=quote_plus(title)),
                    cache_hours=48, referer=self.base_link + '/'
                )
                if not sHtml:
                    continue
                isMatch, aResults = cParser.parse(sHtml, pattern)
                if not isMatch:
                    continue
                for sUrl, sTitle, sYear, sQlty in aResults:
                    if sYear not in years:
                        continue
                    if self._clean(sTitle) not in t:
                        continue
                    return sUrl, self._quality(sQlty)
            except Exception:
                pass
        return '', 'HD'

    def _append_source(self, sources, link, quality):
        """Gemeinsame Hilfsmethode: isBlockedHoster prüfen und Source anhängen."""
        try:
            isBlocked, hoster, sUrl, prioHoster = isBlockedHoster(
                link, isResolve=False
            )
            if isBlocked:
                # resolveurl kennt diesen Hoster nicht → prioHoster=999
                # sourcesResolve versucht es dann mit include_popups=True
                hoster = urlparse(link).hostname or link
                sources.append({
                    'source':     hoster,
                    'quality':    quality,
                    'language':   'de',
                    'url':        link,
                    'direct':     False,
                    'prioHoster': 999,
                })
            else:
                sources.append({
                    'source':     hoster,
                    'quality':    quality,
                    'language':   'de',
                    'url':        link,
                    'direct':     False,
                    'prioHoster': prioHoster,
                })
        except Exception:
            pass

    def run(self, titles, year, season=0, episode=0, imdb='', hostDict=None):
        self.sources = []
        sources = []
        try:

            # ---- Filme ------------------------------------------------
            if season == 0:
                if not imdb:
                    return sources

                sHtml = self._fetch(
                    '%s/movie/%s' % (_MEINECLOUD, imdb),
                    cache_hours=48,
                    referer=self.base_link + '/'
                )
                if not sHtml:
                    return sources

                quality = 'HD'
                isM, qList = cParser.parse(
                    sHtml, r'class="_player-quality_link[^"]*"[^>]*>\s*([^\s<]+)'
                )
                if isM and qList:
                    quality = self._quality(qList[0])

                isMatch, dlinks = cParser.parse(sHtml, r'data-link="([^"]+)"')
                if not isMatch:
                    return sources

                for link in dlinks:
                    if not link or 'meinecloud' in link:
                        continue
                    if link.startswith('//'):
                        link = 'https:' + link
                    if not link.startswith('http'):
                        continue
                    self._append_source(sources, link, quality)

            # ---- Serien -----------------------------------------------
            # Eigener Serienpfad nach der funktionierenden FilmPro-Referenz:
            # meinecloud.click/serial/{IMDbNum}?s={Staffel}&e={Episode}
            # Filme oberhalb bleiben vollständig unverändert.
            else:
                if not imdb:
                    return sources

                imdb_id = str(imdb).strip()
                imdb_num = imdb_id[2:] if imdb_id.lower().startswith('tt') else imdb_id
                try:
                    season_num = max(1, int(season))
                    episode_num = max(1, int(episode))
                except Exception:
                    return sources

                player_url = ('https://meinecloud.click/serial/%s?s=%s&e=%s' %
                              (imdb_num, season_num, episode_num))

                # 1. Direkter Playeraufruf: frische Seite, niemals cachen.
                link = self._series_link_from_player(player_url, episode_num)
                if link:
                    direct_link = self._resolve_series_embed(link)
                    if direct_link:
                        self._append_direct_source(sources, direct_link, '720p')
                    else:
                        self._append_source(sources, link, '720p')
                    return sources

                # 2. Fallback: FilmPalast-Check-API erwartet die vollständige
                # IMDb-ID inklusive "tt" und liefert player_url als JSON.
                try:
                    import json as _json
                    check_imdb = imdb_id if imdb_id.lower().startswith('tt') else 'tt' + imdb_num
                    check_url = ('https://meinecloud.click/serials.php'
                                 '?task=check&id_imdb=%s' % check_imdb)
                    raw = self._fetch_fresh(check_url, referer=self.base_link + '/')
                    data = _json.loads(raw) if raw else {}
                    fallback_player = self._normalise_link(data.get('player_url', ''))
                    if fallback_player:
                        sep = '&' if '?' in fallback_player else '?'
                        fallback_player += '%ss=%s&e=%s' % (sep, season_num, episode_num)
                        link = self._series_link_from_player(fallback_player, episode_num)
                        if link:
                            direct_link = self._resolve_series_embed(link)
                            if direct_link:
                                self._append_direct_source(sources, direct_link, '720p')
                            else:
                                self._append_source(sources, link, '720p')
                            return sources

                        # Manche Antworten liefern bereits einen auflösbaren
                        # Embed-Link. Nur dann als letzte Alternative übernehmen.
                        if '/e/' in fallback_player or '/embed/' in fallback_player:
                            self._append_source(sources, fallback_player, '720p')
                except Exception:
                    pass

        except Exception:
            pass

        return sources

    def resolve(self, url):
        return url
