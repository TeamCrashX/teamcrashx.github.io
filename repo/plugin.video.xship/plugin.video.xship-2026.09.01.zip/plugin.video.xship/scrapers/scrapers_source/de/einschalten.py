# einschalten
# 2024-09-05
# edit 2026.08.04 — Watch-API, Release-Qualitaet, Raw-Hoster-Fallback

import json
from urllib.parse import urlparse
from resources.lib.utils import isBlockedHoster
from resources.lib.requestHandler import cRequestHandler
from resources.lib.control import getSetting, quote_plus
from scrapers.modules import cleantitle
from resources.lib import log_utils

SITE_IDENTIFIER = 'einschalten'
SITE_DOMAIN     = 'einschalten.in'
SITE_NAME       = SITE_IDENTIFIER.upper()

class source:
    def __init__(self):
        self.priority  = 1
        self.language  = ['de']
        self.domain    = getSetting('provider.' + SITE_IDENTIFIER + '.domain', SITE_DOMAIN)
        self.base_link = 'https://' + self.domain
        self.api_link  = self.base_link + '/api/movies'
        self.sources   = []

    def _fetch(self, url):
        try:
            oRequest = cRequestHandler(url, caching=True)
            oRequest.cacheTime = 60 * 60 * 6
            oRequest.addHeaderEntry('Accept',       'application/json, text/plain, */*')
            oRequest.addHeaderEntry('Referer',      self.base_link + '/')
            oRequest.addHeaderEntry('Origin',       self.base_link)
            return oRequest.request()
        except Exception as e:
            log_utils.log('[%s] _fetch Fehler: %s' % (SITE_NAME, str(e)), log_utils.LOGWARNING)
            return ''

    @staticmethod
    def _quality(release):
        """Nur die vom zentralen xShip-Filter unterstützte Qualitätsstufe."""
        r = str(release or '').upper()
        if '2160' in r or '4K' in r or 'UHD' in r:
            return '4K'
        if '1080' in r:
            return '1080p'
        if '720' in r:
            return '720p'
        if '480' in r or '.SD.' in r:
            return '480p'
        return 'HD'

    @staticmethod
    def _release_type(release):
        """Releaseart getrennt von quality halten, damit 720p korrekt sortiert wird."""
        r = str(release or '').upper()
        if 'TELESYNC' in r or '.TS.' in r or r.endswith('.TS'):
            return 'TS'
        if 'TELECINE' in r or '.TC.' in r:
            return 'TC'
        if 'CAMRIP' in r or '.CAM.' in r or r.endswith('.CAM'):
            return 'CAM'
        return ''

    def run(self, titles, year, season=0, episode=0, imdb='', hostDict=None):
        self.sources = []
        # einschalten.in hat nur Filme, keine Serien
        if season > 0:
            return self.sources
        try:
            t     = set([cleantitle.get(i) for i in set(titles) if i])
            years = (str(year), str(year - 1), str(year + 1))

            movie_id = None
            for sSearchText in titles:
                try:
                    url  = self.api_link + '?search=%s' % quote_plus(sSearchText)
                    data = self._fetch(url)
                    if not data:
                        continue
                    obj  = json.loads(data)
                    items = obj.get('data', []) if isinstance(obj, dict) else obj
                    for item in items:
                        sTitle = item.get('title', '')
                        sYear  = str(item.get('releaseDate', ''))[:4]
                        if cleantitle.get(sTitle) in t and sYear in years:
                            movie_id = item.get('id')
                            log_utils.log('[%s] Treffer: "%s" (%s) id=%s' % (
                                SITE_NAME, sTitle, sYear, movie_id), log_utils.LOGINFO)
                            break
                    if movie_id:
                        break
                except Exception as e:
                    log_utils.log('[%s] Suche Fehler: %s' % (SITE_NAME, str(e)), log_utils.LOGWARNING)
                    continue

            if not movie_id:
                return self.sources

            # Stream-URL holen
            watch_url = self.api_link + '/%s/watch' % movie_id
            data = self._fetch(watch_url)
            if not data:
                return self.sources

            try:
                jResult = json.loads(data)
            except Exception:
                return self.sources

            # API kann ein einzelnes Objekt, eine Liste oder einen Wrapper
            # mit data/streams liefern.
            if isinstance(jResult, list):
                streams = jResult
            elif isinstance(jResult, dict):
                wrapped = jResult.get('streams') or jResult.get('data')
                streams = wrapped if isinstance(wrapped, list) else [jResult]
            else:
                streams = []

            seen_urls = set()
            accepted = 0
            duplicates = 0
            blocked = 0
            for stream in streams:
                if not isinstance(stream, dict):
                    continue
                streamUrl = str(stream.get('streamUrl') or '').strip()
                releaseName = str(stream.get('releaseName') or '')
                if not streamUrl:
                    continue
                if streamUrl.startswith('//'):
                    streamUrl = 'https:' + streamUrl

                url_key = streamUrl.rstrip('/')
                if url_key in seen_urls:
                    duplicates += 1
                    continue
                seen_urls.add(url_key)

                quality = self._quality(releaseName)
                release_type = self._release_type(releaseName)
                # Nur klassifizieren. Embed-Links wie vide0.net sind keine
                # direkten Mediendateien und werden erst beim Anklicken durch
                # ResolveURL aufgeloest.
                isBlocked, hoster, clean_url, prioHoster = isBlockedHoster(
                    streamUrl, isResolve=False)

                # Einschalten liefert teilweise neue/noch unbekannte Embed-
                # Domains (z. B. vide0.net). Diese nicht bereits waehrend
                # der Suche verwerfen: als rohe URL anzeigen und erst beim
                # Anklicken von ResolveURL pruefen lassen.
                if isBlocked or not clean_url:
                    blocked += 1
                    parsed_host = (urlparse(streamUrl).hostname or '').lower()
                    if not parsed_host or not streamUrl.lower().startswith(('http://', 'https://')):
                        continue
                    hoster = parsed_host
                    prioHoster = 0
                    log_utils.log('[%s] Unbekannter/blockierter Hoster roh uebernommen: %s' % (
                        SITE_NAME, parsed_host), log_utils.LOGINFO)

                self.sources.append({
                    'source': hoster,
                    'quality': quality,
                    'language': 'de',
                    'url': streamUrl,
                    'direct': False,
                    'prioHoster': prioHoster,
                    'info': ' | '.join(x for x in (release_type, str(year or '')[:4]) if x)
                })
                accepted += 1
                log_utils.log('[%s] Quelle: %s [%s] %s' % (
                    SITE_NAME, hoster, '%s%s' % (quality, (' ' + release_type) if release_type else ''), streamUrl), log_utils.LOGINFO)

            log_utils.log('[%s] Watch-API: %d Eintraege, %d Quellen, '
                          'duplikate=%d blockiert=%d' % (
                              SITE_NAME, len(streams), accepted,
                              duplicates, blocked), log_utils.LOGINFO)

        except Exception as e:
            log_utils.log('[%s] run() Fehler: %s' % (SITE_NAME, str(e)), log_utils.LOGWARNING)

        return self.sources

    def resolve(self, url):
        return url
