

import os.path
import importlib
import importlib.util
import pkgutil

from resources.lib import log_utils

try:
    import xbmcaddon
    __addon__ = xbmcaddon.Addon()
except:
    __addon__ = None
    pass

debug = True #if __addon__.getSetting('debug.enabled') == 'true' else False

# Ergebnis des letzten Modul-Ladevorgangs. Wird von der Scraper-Diagnose ausgewertet.
LAST_LOAD_DIAGNOSTICS = []


def sources(specified_folders=None):
    global LAST_LOAD_DIAGNOSTICS
    diagnostics = []
    try:
        sourceDict = []
        provider = os.path.dirname(__file__).split(os.sep)[-1]
        sourceFolder = getScraperFolder(provider)
        sourceFolderLocation = os.path.join(os.path.dirname(__file__), sourceFolder)
        sourceSubFolders = [x[1] for x in os.walk(sourceFolderLocation)][0]
        if specified_folders is not None:
            sourceSubFolders = specified_folders

        for i in sourceSubFolders:
            folder = os.path.join(sourceFolderLocation, i)
            for loader, module_name, is_pkg in pkgutil.walk_packages([folder]):
                if is_pkg:
                    continue
                entry = {'provider': module_name, 'folder': i, 'status': 'DISCOVERED', 'error': ''}
                diagnostics.append(entry)
                if not enabledCheck(module_name):
                    entry['status'] = 'DISABLED'
                    continue
                try:
                    if hasattr(loader, 'find_module'):
                        module = loader.find_module(module_name).load_module(module_name)
                    else:
                        spec = loader.find_spec(module_name, None)
                        module = importlib.util.module_from_spec(spec)
                        spec.loader.exec_module(module)
                    sourceDict.append((module_name, module.source()))
                    entry['status'] = 'LOADED'
                except Exception as e:
                    entry['status'] = 'LOAD_ERROR'
                    entry['error'] = '%s: %s' % (e.__class__.__name__, e)
                    # Bestehendes Verhalten beibehalten: defekten Provider deaktivieren.
                    if __addon__ is not None:
                        __addon__.setSetting('provider.' + module_name, 'false')
                    if debug:
                        log_utils.log('Error: Loading module: "%s": %s' % (module_name, e), log_utils.LOGERROR)
        LAST_LOAD_DIAGNOSTICS = diagnostics
        return sourceDict
    except Exception as e:
        LAST_LOAD_DIAGNOSTICS = diagnostics
        if debug:
            log_utils.log('Error while discovering scraper modules: %s' % e, log_utils.LOGERROR)
        return []


def getLoadDiagnostics():
    return list(LAST_LOAD_DIAGNOSTICS)


def enabledCheck(module_name):
    if __addon__ is not None:
        if __addon__.getSetting('provider.' + module_name) == 'false' or __addon__.getSetting('provider.' + module_name + '.check') == 'false':
            return False
        return True


def providerSources():
    sourceSubFolders = [x[1] for x in os.walk(os.path.dirname(__file__))][0]
    return getModuleName(sourceSubFolders)


def providerNames():
    providerList = []
    provider = __addon__.getSetting('module.provider')
    sourceFolder = getScraperFolder(provider)
    sourceFolderLocation = os.path.join(os.path.dirname(__file__), sourceFolder)
    sourceSubFolders = [x[1] for x in os.walk(sourceFolderLocation)][0]
    for i in sourceSubFolders:
        for loader, module_name, is_pkg in pkgutil.walk_packages([os.path.join(sourceFolderLocation, i)]):
            if is_pkg:
                continue
            correctName = module_name.split('_')[0]
            providerList.append(correctName)
    return providerList


def getAllHosters():
    def _sources(sourceFolder, appendList):
        sourceFolderLocation = os.path.join(os.path.dirname(__file__), sourceFolder)
        sourceSubFolders = [x[1] for x in os.walk(sourceFolderLocation)][0]
        for i in sourceSubFolders:
            for loader, module_name, is_pkg in pkgutil.walk_packages([os.path.join(sourceFolderLocation, i)]):
                if is_pkg:
                    continue
                try:
                    mn = str(module_name).split('_')[0]
                except:
                    mn = str(module_name)
                appendList.append(mn)

    sourceSubFolders = [x[1] for x in os.walk(os.path.dirname(__file__))][0]
    appendList = []
    for item in sourceSubFolders:
        if item != 'modules':
            _sources(item, appendList)
    return list(set(appendList))


def getScraperFolder(scraper_source):
    sourceSubFolders = [x[1] for x in os.walk(os.path.dirname(__file__))][0]
    return [i for i in sourceSubFolders if scraper_source.lower() in i.lower()][0]


def getModuleName(scraper_folders):
    nameList = []
    for s in scraper_folders:
        try:
            nameList.append(s.split('_')[1].lower().title())
        except:
            pass
    return nameList
