
# 2022-10-09
# edit 2026.05.07

import sys, os, requests, threading
from random import choice
from xbmcaddon import Addon
# from resources.lib.requestHandler import cRequestHandler
try:
    from resources.lib.tools import logger
    isLogger=True
except:
    isLogger=False
    pass


is_python2 = sys.version_info.major == 2
if is_python2:
    from xbmc import translatePath
    from urlparse import urlparse
else:
    from xbmcvfs import translatePath
    from urllib.parse import urlparse

addonInfo = Addon().getAddonInfo
addonPath = translatePath(addonInfo('path'))
addonVersion = addonInfo('version')
_addon = Addon()
_rawSetSetting = _addon.setSetting
_getSetting = _addon.getSetting
_settings_write_lock = threading.RLock()

def setSetting(id, value):
    # Kodi schreibt addon_data/settings.xml bei setSetting(). Die Domainchecks
    # laufen parallel; Schreibzugriffe deshalb serialisieren, damit die XML-Datei
    # nicht durch gleichzeitige Writes beschädigt wird.
    with _settings_write_lock:
        return _rawSetSetting(id, value)

def getSetting(Name, default=''):
    result = _getSetting(Name)
    if result: return result
    else: return default


def repair_profile_settings_if_malformed():
    """Sichert und entfernt nur eine tatsächlich unlesbare Kodi-Settings-XML."""
    try:
        import xml.etree.ElementTree as ET
        import shutil, time
        profile = translatePath(addonInfo('profile'))
        settings_path = os.path.join(profile, 'settings.xml')
        if not os.path.isfile(settings_path):
            return False
        try:
            ET.parse(settings_path)
            return False
        except (ET.ParseError, ValueError):
            backup = settings_path + '.broken-%s.bak' % int(time.time())
            shutil.copy2(settings_path, backup)
            os.remove(settings_path)
            if isLogger:
                logger.warning(' -> [service]: beschädigte Profil-settings.xml gesichert und zurückgesetzt: %s' % backup)
            return True
    except Exception as e:
        if isLogger:
            logger.warning(' -> [service]: Settings-XML-Prüfung fehlgeschlagen: %s' % e)
        return False

repair_profile_settings_if_malformed()

# Html Cache beim KodiStart loeschen
def delHtmlCache():
    try:
        from resources.lib.requestHandler import cRequestHandler
        from time import time
        deltaDay = int(getSetting('cacheDeltaDay', 3))
        deltaTime = 60*60*24*deltaDay # Tage
        currentTime = int(time())
        # einmalig
        if getSetting('delHtmlCache') == 'true':
            cRequestHandler('dummy').clearCache()
            setSetting('lastdelhtml', str(currentTime))
            setSetting('delHtmlCache', 'false')
        # alle x Tage
        elif currentTime >= int(getSetting('lastdelhtml', 0)) + deltaTime:
            cRequestHandler('dummy').clearCache()
            setSetting('lastdelhtml', str(currentTime))
    except: pass

# Scraper(Seiten) ein- / ausschalten
#  [(providername, domainname), ...]     providername identisch mit dateiname
def _getPluginData():
    from os import path, listdir
    sPluginFolder = path.join(addonPath, 'scrapers', 'scrapers_source', 'de')
    sys.path.append(sPluginFolder)
    items = listdir(sPluginFolder)
    aFileNames=[]
    aPluginsData = []
    for sItemName in items:
        if sItemName.endswith('.py'): aFileNames.append(sItemName[:-3])
    for fileName in aFileNames:
        if fileName ==  '__init__': continue
        try:
            plugin = __import__(fileName, globals(), locals())
            # print(plugin.SITE_DOMAIN +'  '+ plugin.SITE_IDENTIFIER)
            aPluginsData.append({'domain': plugin.SITE_DOMAIN, 'provider': plugin.SITE_IDENTIFIER})
        except:
            pass
    return aPluginsData


def check_domains():
    domains = _getPluginData()
    import threading
    threads = []
    try:
        for item in domains:
            _domain = item['domain']
            _provider = item['provider']
            t = threading.Thread(target=_checkdomain, args=(_domain, _provider))
            threads += [t]
            t.start()
    except:
        pass
    for count, t in enumerate(threads):
        t.join()

def RandomUA():
    #Random User Agents aktualisiert 08.06.2025
    FF_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:139.0) Gecko/20100101 Firefox/139.0'
    OPERA_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36 OPR/119.0.0.0'
    ANDROID_USER_AGENT = 'Mozilla/5.0 (Linux; Android 15; SM-S931U Build/AP3A.240905.015.A2; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/132.0.6834.163 Mobile Safari/537.36'
    EDGE_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36 Edg/134.0.0.0'
    CHROME_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36'
    SAFARI_USER_AGENT = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 14_7_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.4 Safari/605.1.15'

    _User_Agents = [FF_USER_AGENT, OPERA_USER_AGENT, EDGE_USER_AGENT, CHROME_USER_AGENT, SAFARI_USER_AGENT]
    return choice(_User_Agents)

def _checkdomain(_domain, _provider):
    try:
        requests.packages.urllib3.disable_warnings()  # weil verify = False - ansonst Fehlermeldungen im kodi log
        check=None
        status_code=None
        if _provider == 'vavoo':
            setSetting('provider.' + _provider + '.check', 'true')
            return
        domain = getSetting('provider.'+ _provider +'.domain', _domain)
        if not domain:
            domain = _domain  # Fallback auf Default wenn leer

        # Kodi speichert Enum-Einstellungen als Index. Vor dem Provider-Check
        # müssen diese Werte in die tatsächlich gewählte Domain übersetzt werden.
        enum_domains = {
            'kinokiste': {
                '0': 'kinokiste.club',
                '1': 'kinokiste.eu',
            },
            'movie2k': {
                '0': 'movie2k.ch',
                '1': 'movie2k.ag',
                '2': 'movie2k.life',
                '3': 'movie2k.cx',
            },
            'movie4k': {
                '0': 'movie4k.sx',
                '1': 'movie4k.ag',
                '2': 'movie4k.stream',
                '3': 'movie4k.at',
            },
        }
        provider_domains = enum_domains.get(_provider)
        if provider_domains:
            selected = provider_domains.get(str(domain).strip(), str(domain).strip())
            selected = selected.replace('https://', '').replace('http://', '').strip().strip('/')
            domain = selected or _domain

        # SerienStream nutzt eine Enum-Einstellung. Der allgemeine Service darf
        # den gespeicherten Index (z. B. "2") nicht als Domain behandeln.
        # Außerdem wird SerienStream nicht dauerhaft deaktiviert, nur weil ein
        # HEAD-Request von der aktuell gewählten Mirror-Domain blockiert wird.
        if _provider == 'serienstream':
            domain_options = {
                '0': 'serienstream.to',
                '1': '186.2.175.5',
                '2': 's.to',
                '3': 'serienstream.cloud',
            }
            selected = domain_options.get(str(domain).strip(), str(domain).strip())
            selected = selected.replace('https://', '').replace('http://', '').strip().strip('/')
            domain = selected or _domain
            scheme = 'http' if domain == '186.2.175.5' else 'https'
            base_link = scheme + '://' + domain
            status_code = None
            check = 'true'
            try:
                UA = RandomUA()
                headers = {'referer': base_link, 'user-agent': UA}
                # GET ist bei den Mirrors zuverlässiger als HEAD; nur einen
                # sehr kleinen Abruf durchführen und nicht dem Redirect folgen.
                r = requests.get(base_link, verify=False, headers=headers,
                                 timeout=4, allow_redirects=False, stream=True)
                status_code = r.status_code
                try: r.close()
                except: pass
                if status_code and status_code >= 500:
                    logger.warning(' -> [service]: SerienStream-Mirror antwortet mit %s; Provider bleibt für Laufzeit-Fallback aktiv' % status_code)
            except Exception as e:
                logger.warning(' -> [service]: SerienStream-Mirrorcheck fehlgeschlagen (%s); Provider bleibt aktiv' % e)
        else:
            base_link = 'https://' + domain
            try:
                UA=RandomUA()
                headers = {
                    "referer": base_link,
                    "user-agent": UA,
                }
                r = requests.head(base_link, verify=False, headers=headers)
                status_code = r.status_code
                if 300 <= status_code <= 400:
                    check = 'true'  # Domain NICHT aus Redirect übernehmen
                elif status_code == 200:
                    check = 'true'
                else:
                    check = 'false'
            except:
                check = 'false'
        wrongDomain = 'site-maps.cc', 'www.drei.at', 'notice.cuii.info'
        if domain in wrongDomain:
            setSetting('provider.' + _provider + '.check', '')
            setSetting('provider.' + _provider + '.domain', '')
        else:
            setSetting('provider.' + _provider + '.check', check)
            # Domain nur speichern wenn leer - nie User-Einstellung überschreiben
            if not getSetting('provider.'+ _provider +'.domain'):
                setSetting('provider.' + _provider + '.domain', domain)
        if isLogger: logger.info(' -> [service]: Provider: %s / Statuscode: %s / Domain: %s, Check: %s' % (_provider, status_code, domain, check))
    except: pass

def ensure_youtube_api_keys():
    """Legacy no-op: xShip now resolves trailers internally."""
    return


def disable_xship_auto_update():
    """Disable automatic updates for xShip only; manual updates stay possible."""
    try:
        import glob
        import re
        import sqlite3

        addon_id = 'plugin.video.xship'
        db_dir = translatePath('special://profile/Database/')
        candidates = glob.glob(os.path.join(db_dir, 'Addons*.db'))
        if not candidates:
            if isLogger:
                logger.warning('[service]: Addons database not found; xShip auto-update rule not set')
            return False

        def _db_key(path):
            match = re.search(r'Addons(\d+)\.db$', os.path.basename(path), re.I)
            return (int(match.group(1)) if match else -1, os.path.getmtime(path))

        db_path = max(candidates, key=_db_key)
        conn = sqlite3.connect(db_path, timeout=5)
        try:
            cur = conn.cursor()
            cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='update_rules'")
            if cur.fetchone():
                cur.execute(
                    "INSERT OR IGNORE INTO update_rules(addonID, updateRule) VALUES(?, ?)",
                    (addon_id, 1)
                )
                conn.commit()
                if isLogger:
                    logger.info('[service]: automatic updates disabled for xShip only')
                return True

            cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='blacklist'")
            if cur.fetchone():
                columns = [row[1] for row in cur.execute('PRAGMA table_info(blacklist)')]
                if 'addonID' in columns:
                    cur.execute("INSERT OR IGNORE INTO blacklist(addonID) VALUES(?)", (addon_id,))
                    conn.commit()
                    if isLogger:
                        logger.info('[service]: automatic updates disabled for xShip only (legacy Kodi)')
                    return True

            if isLogger:
                logger.warning('[service]: no supported per-addon update rule table found')
            return False
        finally:
            conn.close()
    except Exception as e:
        if isLogger:
            logger.warning('[service]: failed to set xShip-only auto-update rule: %s' % str(e))
        return False


class xShipMonitor(xbmc.Monitor):
	"""Listens for sxManager domain updates and re-runs check_domains immediately."""
	def onNotification(self, sender, method, data):
		if sender == 'sxManager' and method == 'Other.domainsUpdated':
			import json
			try:
				addon = json.loads(data) if data else None
			except Exception:
				addon = None
			if addon is None or addon == 'xship':
				try:
					logger.info('[service]: sxManager domain update received - re-running check_domains()')
				except Exception:
					pass
				check_domains()


if __name__ == "__main__":
	import xbmc, time
	# Do not auto-install dependencies here. InstallAddon() forces Kodi to query
	# repositories and can overlap with provider searches on low-memory devices.
	if not xbmc.getCondVisibility("System.HasAddon(inputstream.adaptive)"):
		if isLogger:
			logger.warning('[service]: inputstream.adaptive is missing; automatic installation disabled')

	disable_xship_auto_update()

	# Wait for sxManager to finish its startup sync before running domain check
	monitor = xShipMonitor()
	monitor.waitForAbort(15)
	if monitor.abortRequested():
		sys.exit(0)

	check_domains()
	delHtmlCache()
	# Internal trailer resolver does not require plugin.video.youtube data.

	# Keep service alive to receive sxManager notifications
	while not monitor.waitForAbort(3600):
		pass