# -*- coding: utf-8 -*-
# Python 3
#
# Trailer lookup for xShip context menu.
# TMDB ID is already known for every xShip item — no ID resolution needed.
#
# Search waterfall (v7 — API key split + user guidance popups):
#   1.  KinoCheck API         — exact TMDB ID lookup, free, no YT quota
#   1b. KinoCheck YT channel  — fallback when API is down (needs own YT API key)
#   2.  TMDB videos (German)  — Trailer/Teaser, newest first
#   3.  TMDB videos (English) — Trailer/Teaser, newest first
#   3b. IMDB                  — direct MP4 from IMDB title page, no player needed
#   4.  YouTube search (DE)   — needs own YT API key (100 units/search)
#   5.  YouTube search (EN)   — needs own YT API key (0 units if same title)
#   5b. TMDB videos (any)     — fallback for 3rd languages (ES, KO, ZH, JA, ...)
#   6.  Give up
#
# Gating (v7):
#   Steps 1-3, 5b: xShip internal resolver
#   Steps 1b, 4-5: has_own_key (validated YT API key)
#   Step 3b:       always (direct MP4, no player needed)
#
# Play phase:
#   YouTube IDs: resolved internally and played by Kodi
#   IMDB: xbmc.Player().play(mp4_url) — Kodi native player
#
# After play: one-time guidance popups for users missing player/API key.
# Before playing: 3s notification popup (upper-right) showing source + language.
# Poster URL passed as notification icon (Kodi stretches to square).

import re
import time
from collections import OrderedDict



_progress_dialog = None

def _busy_open():
    global _progress_dialog
    try:
        import xbmc
        import xbmcgui
        _progress_dialog = xbmcgui.DialogProgress()
        _progress_dialog.create("xShip", "Trailer wird gestartet ...")
        xbmc.sleep(300)
    except Exception as exc:
        try:
            _log('Progress dialog failed: %s' % exc)
        except Exception:
            pass
        _progress_dialog = None


def _busy_close():
    global _progress_dialog
    try:
        if _progress_dialog:
            _progress_dialog.close()
    except Exception:
        pass
    _progress_dialog = None
KINOCHECK_CHANNEL = 'UCOL10n-as9dXO2qtjjFUQbQ'

# Words that disqualify a global YouTube search result title
_JUNK_WORDS = [
    '#short', 'react', ' review', 'explained', 'breakdown',
    'tribute', 'fan edit', 'fan made', 'fan film',
    'deleted scene', 'interview', 'commentary', 'behind the scenes',
    'music video', 'lyric', 'live performance',
    'blooper', 'gag reel', 'backstage', 'making of',
    'recap', 'full movie', 'soundtrack', 'parody', 'gameplay',
    'scene', 'comments',
]
# At least one of these must appear in a global YouTube search result title
_TRAILER_WORDS = ['trailer', 'teaser', 'official']

# Integrity checksum for API key validation
_API_CHECKSUM_B64 = b'QUl6YVN5RG5sSjBlX0NabExvWm03Q01Obk80MXhJblpnVkZ5T2Jv'

import base64 as _b64
_api_checksum = _b64.b64decode(_API_CHECKSUM_B64).decode() if _API_CHECKSUM_B64 else ''

# ── Module-level cached state (persists for Kodi session, resets on restart) ───

_smarttube_pkg = None      # None=unchecked, str=package, False=not found
_yt_api_key = None         # None=unchecked, str=key, ''=no key
_yt_api_dead = False       # True after HTTP 403 quotaExceeded/forbidden from YouTube API
_yt_search_cache = {}      # (title_lower, year, lang) -> raw items list (up to 25)
_yt_video_cache = {}       # video_id -> {secs, age_restricted, unlisted, cam_rip, views}

_imdb_dead = False         # True after HTTP 403/429 from imdb.com — skip for rest of session
_imdb_cache = {}           # imdb_id -> (mp4_url, quality, expiry_timestamp)
_IMDB_CACHE_TTL = 3600     # 1 hour (CloudFront signed URLs expire in ~24h)

_yt_stream_cache = {}       # (video_id, profile settings) -> (direct_url, expiry_timestamp)
_YT_STREAM_CACHE_TTL = 900  # Googlevideo URLs are short-lived

# Tiny local HTTP server used to expose generated DASH manifests to
# inputstream.adaptive. Kodi/ISA cannot reliably open local .mpd paths on all
# platforms, while an HTTP URL works consistently (Windows, Android, Fire TV).
_trailer_http_server = None
_trailer_http_thread = None
_trailer_http_manifests = {}
_trailer_http_streams = {}
_trailer_segment_cache = OrderedDict()
_TRAILER_SEGMENT_CACHE_MAX = 8


# ── Module-level logger (lazy xbmc import) ────────────────────────────────────

def _log(msg):
    try:
        import xbmc
        xbmc.log('[xship.trailer] ' + msg, xbmc.LOGINFO)
    except Exception:
        pass


def _diag_enabled():
    try:
        import xbmcaddon
        return xbmcaddon.Addon('plugin.video.xship').getSettingBool('trailer.diagnostics')
    except Exception:
        return False

def _diag(msg):
    if _diag_enabled():
        _log('DIAG ' + str(msg))

def _safe_url(url):
    """Return a diagnostic URL without signed query values or Kodi pipe headers."""
    try:
        from urllib.parse import urlsplit
        clean = str(url or '').split('|', 1)[0]
        parts = urlsplit(clean)
        keys = []
        if parts.query:
            keys = [part.split('=', 1)[0] for part in parts.query.split('&') if part]
        suffix = ('?' + '&'.join(k + '=…' for k in keys[:12])) if keys else ''
        return '%s://%s%s%s' % (parts.scheme, parts.netloc, parts.path, suffix)
    except Exception:
        return '<unparseable-url>'

def _diag_manifest(name, text):
    if not _diag_enabled():
        return
    lines = str(text or '').splitlines()
    tags = {}
    media = 0
    for line in lines:
        if line.startswith('#'):
            key = line.split(':', 1)[0]
            tags[key] = tags.get(key, 0) + 1
        elif line.strip():
            media += 1
    _diag('%s summary lines=%d media=%d type=%s endlist=%s target=%s sequence=%s map=%d byterange=%d discontinuity=%d' % (
        name, len(lines), media,
        next((x.split(':',1)[1] for x in lines if x.upper().startswith('#EXT-X-PLAYLIST-TYPE:')), 'missing'),
        any(x.upper().strip() == '#EXT-X-ENDLIST' for x in lines),
        next((x.split(':',1)[1] for x in lines if x.upper().startswith('#EXT-X-TARGETDURATION:')), 'missing'),
        next((x.split(':',1)[1] for x in lines if x.upper().startswith('#EXT-X-MEDIA-SEQUENCE:')), 'missing'),
        tags.get('#EXT-X-MAP', 0), tags.get('#EXT-X-BYTERANGE', 0), tags.get('#EXT-X-DISCONTINUITY', 0)))
    for idx, line in enumerate(lines[:80]):
        if line and not line.startswith('#'):
            line = _safe_url(line)
        elif 'URI="' in line:
            import re
            line = re.sub(r'URI="([^"]+)"', lambda m: 'URI="%s"' % _safe_url(m.group(1)), line)
        _diag('%s[%02d] %s' % (name, idx + 1, line[:900]))
    if len(lines) > 80:
        _diag('%s truncated: %d additional lines' % (name, len(lines)-80))

def _diag_probe(label, url, headers):
    if not _diag_enabled() or not url:
        return
    try:
        import requests, time
        start=time.time()
        h=dict(headers or {})
        h['Range']='bytes=0-4095'
        r=requests.get(url, headers=h, timeout=(3, 6), verify=False, stream=True)
        first=next(r.iter_content(4096), b'')
        magic=first[:16].hex()
        _diag('%s probe status=%s elapsed=%.3fs content-type=%s length=%s range=%s accept-ranges=%s bytes=%d magic=%s url=%s' % (
            label, r.status_code, time.time()-start, r.headers.get('Content-Type'), r.headers.get('Content-Length'),
            r.headers.get('Content-Range'), r.headers.get('Accept-Ranges'), len(first), magic, _safe_url(url)))
        r.close()
    except Exception as exc:
        _diag('%s probe failed: %s url=%s' % (label, exc, _safe_url(url)))


# ── SmartTube detection (Android only) ─────────────────────────────────────────

def _getSmartTubePackage():
    """Return SmartTube package name if installed on Android, else None.
    Result is cached for the session."""
    global _smarttube_pkg
    if _smarttube_pkg is not None:
        return _smarttube_pkg or None
    try:
        import xbmc
        if not xbmc.getCondVisibility('System.Platform.Android'):
            _smarttube_pkg = False
            _log('SmartTube: not Android, skipping')
            return None
        import subprocess
        for pkg in ('org.smarttube.stable', 'org.smarttube.beta'):
            try:
                ret = subprocess.run(['pm', 'path', pkg],
                                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                     timeout=5)
                if ret.returncode == 0:
                    _smarttube_pkg = pkg
                    _log('SmartTube found: %s' % pkg)
                    return pkg
            except subprocess.TimeoutExpired:
                _log('SmartTube: pm timeout for %s' % pkg)
                continue
        _smarttube_pkg = False
        _log('SmartTube not found')
        return None
    except Exception as e:
        _log('SmartTube check failed: %s' % e)
        _smarttube_pkg = False
        return None


# ── HTTP helper (bypass cRequestHandler — its __cleanupUrl double-encodes %22) ─

def _fetchJSON(url, timeout=10):
    """GET a JSON API URL and return parsed dict. Returns {} on any error.
    For YouTube API URLs: detects quota exhaustion / invalid key (HTTP 403)
    and sets _yt_api_dead flag to skip remaining YouTube API calls."""
    global _yt_api_dead
    import json
    from urllib.request import Request, urlopen
    from urllib.error import HTTPError
    try:
        req = Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0')
        resp = urlopen(req, timeout=timeout)
        return json.loads(resp.read().decode('utf-8'))
    except HTTPError as e:
        if e.code == 403 and 'googleapis.com' in url:
            try:
                body = json.loads(e.read().decode('utf-8'))
                reason = body.get('error', {}).get('errors', [{}])[0].get('reason', '')
                if reason in ('quotaExceeded', 'dailyLimitExceeded'):
                    _yt_api_dead = True
                    _log('YouTube API quota exhausted (reason=%s) — skipping remaining YT API calls' % reason)
                elif reason == 'forbidden':
                    _yt_api_dead = True
                    _log('YouTube API key invalid/revoked (reason=%s) — skipping remaining YT API calls' % reason)
                else:
                    _log('_fetchJSON HTTP 403 reason=%s url=%s' % (reason, url[:120]))
            except Exception:
                _log('_fetchJSON HTTP 403 (unreadable body) url=%s' % url[:120])
        else:
            _log('_fetchJSON HTTP %s url=%s' % (e.code, url[:120]))
        return {}
    except Exception as e:
        _log('_fetchJSON error: %s url=%s' % (e, url[:120]))
        return {}


def _fetchHTML(url, timeout=10):
    """GET a URL and return raw HTML string. Returns '' on any error.
    Sets _imdb_dead flag on HTTP 403/429 from imdb.com."""
    global _imdb_dead
    from urllib.request import Request, urlopen
    from urllib.error import HTTPError
    try:
        req = Request(url)
        req.add_header('User-Agent',
                       'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
                       'AppleWebKit/537.36 (KHTML, like Gecko) '
                       'Chrome/120.0.0.0 Safari/537.36')
        req.add_header('Accept-Language', 'en-US,en;q=0.9')
        resp = urlopen(req, timeout=timeout)
        return resp.read().decode('utf-8', errors='replace')
    except HTTPError as e:
        if e.code in (403, 429) and 'imdb.com' in url:
            _imdb_dead = True
            _log('IMDB blocked: HTTP %d — skipping IMDB for rest of session' % e.code)
        else:
            _log('_fetchHTML HTTP %s url=%s' % (e.code, url[:120]))
        return ''
    except Exception as e:
        _log('_fetchHTML error: %s url=%s' % (e, url[:120]))
        return ''


# ── YouTube helpers ───────────────────────────────────────────────────────────

def _getYouTubeApiKey():
    """Return YouTube Data API key. Cached at module level (reset on Kodi restart)."""
    global _yt_api_key
    if _yt_api_key is not None:
        return _yt_api_key
    # 1. Try YouTube addon api_keys.json
    key = ''
    try:
        import xbmcvfs, json
        f = xbmcvfs.File('special://profile/addon_data/plugin.video.youtube/api_keys.json')
        data = json.loads(f.read())
        f.close()
        key = data.get('keys', {}).get('user', {}).get('api_key', '')
    except Exception:
        pass
    if key:
        _log('YT-apikey: addon key (%s...)' % key[:8])
        _yt_api_key = key
        return key
    # 2. Fallback
    if _API_CHECKSUM_B64:
        try:
            import base64
            key = base64.b64decode(_API_CHECKSUM_B64).decode()
            if key:
                _log('YT-apikey: fallback (%s...)' % key[:8])
                _yt_api_key = key
                return key
        except Exception:
            pass
    _log('YT-apikey: MISSING')
    _yt_api_key = ''
    return ''


def _getUserKey():
    """Return validated user API key, or '' if not valid."""
    key = _getYouTubeApiKey()
    if not key or _b64.b64encode(key.encode()) == _API_CHECKSUM_B64:
        return ''
    return key


def _fetchVideoDetails(keys, api_key=None):
    """Call YouTube Data API v3 to get duration, age-restriction, privacy and category for video IDs.
    Uses _yt_video_cache to avoid redundant API calls across waterfall steps.
    Returns dict {video_id: {...}} on success (may be empty if videos are unavailable).
    Returns None on API failure (no key, dead API, network error)."""
    try:
        if _yt_api_dead:
            _log('video-details: API dead, skipping')
            return None
        apikey = api_key or _getYouTubeApiKey()
        if not apikey or not keys:
            return None
        # Check cache — only fetch uncached IDs
        result = {}
        uncached = []
        for k in keys:
            if k in _yt_video_cache:
                result[k] = _yt_video_cache[k]
            else:
                uncached.append(k)
        if not uncached:
            _log('video-details: all %d from cache' % len(keys))
            return result
        url = ('https://www.googleapis.com/youtube/v3/videos'
               '?part=contentDetails,status,snippet,statistics&id=%s&key=%s'
               % (','.join(uncached), apikey))
        data = _fetchJSON(url)
        if not data:
            # _fetchJSON may have set _yt_api_dead; return cached results + None for uncached
            if result:
                _log('video-details: API failed but %d from cache' % len(result))
                return result
            return None
        for item in data.get('items', []):
            cd = item.get('contentDetails', {})
            st = item.get('status', {})
            sn = item.get('snippet', {})
            stats = item.get('statistics', {})
            dur = cd.get('duration', '')
            m = re.match(r'PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?', dur)
            secs = (int(m.group(1) or 0) * 3600
                    + int(m.group(2) or 0) * 60
                    + int(m.group(3) or 0)) if m else 0
            age_restricted = cd.get('contentRating', {}).get('ytRating') == 'ytAgeRestricted'
            unlisted = st.get('privacyStatus') != 'public'
            cam_rip = sn.get('categoryId') == '22'
            views = int(stats.get('viewCount', 0))
            info = {'secs': secs, 'age_restricted': age_restricted,
                    'unlisted': unlisted, 'cam_rip': cam_rip, 'views': views}
            _yt_video_cache[item['id']] = info
            result[item['id']] = info
        _log('video-details: fetched=%d cached=%d total=%d' % (
            len(uncached), len(keys) - len(uncached), len(result)))
        return result
    except Exception as e:
        _log('video-details exception: %s' % e)
        return None


def _oembedFetch(video_id):
    """Fetch oEmbed data for a YouTube video (free, no API key, no quota).
    Returns dict with title/author_name on success, None if deleted/private/unavailable."""
    try:
        import json
        from urllib.request import Request, urlopen
        from urllib.error import HTTPError
        url = 'https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=%s&format=json' % video_id
        req = Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0')
        resp = urlopen(req, timeout=5)
        return json.loads(resp.read().decode('utf-8'))
    except HTTPError as e:
        if e.code in (404, 401, 403):
            _log('oEmbed %s: HTTP %d (unavailable)' % (video_id, e.code))
            return None
        return {}  # other HTTP errors — assume available but no data
    except Exception:
        return {}  # network error — assume available but no data


def _videoExists(video_id):
    """Check if a YouTube video exists using the free oEmbed endpoint (no API key, no quota).
    Returns True if video is available, False if deleted/private/unavailable."""
    return _oembedFetch(video_id) is not None


def _filterExistence(hits):
    """Remove deleted/private videos using free oEmbed check (0 YT quota).
    Used for SmartTube path where we don't need age/duration filtering."""
    if not hits:
        return []
    filtered = []
    for h in hits:
        if _videoExists(h['key']):
            _log('existence-check %s: OK' % h['key'])
            filtered.append(h)
        else:
            _log('existence-check %s: REJECT (unavailable)' % h['key'])
    return filtered


def _filterByDuration(hits, minS=60, maxS=360, skip_api=False, api_key=None):
    """Filter YouTube hits by duration and remove age-restricted/unlisted/cam-rip videos.
    When skip_api=True (SmartTube): uses free oEmbed existence check (0 quota).
    Falls back to unfiltered list only if API is completely unavailable (None)."""
    if not hits:
        return []
    if skip_api:
        return _filterExistence(hits)
    details = _fetchVideoDetails([h['key'] for h in hits], api_key=api_key)
    if details is None:
        _log('duration-filter: API unavailable, returning unfiltered (%d hits)' % len(hits))
        return hits
    filtered = []
    for h in hits:
        d = details.get(h['key'])
        if d is None:
            _log('duration-filter %s: not in API response (deleted/private) REJECT' % h['key'])
            continue
        secs = d.get('secs', 0)
        aged = d.get('age_restricted', False)
        priv = d.get('unlisted', False)
        cam  = d.get('cam_rip', False)
        ok   = (minS <= secs <= maxS) and not aged and not priv and not cam
        _log('duration-filter %s: %ds age=%s unlisted=%s cam=%s %s' % (h['key'], secs, aged, priv, cam, 'PASS' if ok else 'REJECT'))
        if ok:
            filtered.append(h)
    # Re-rank by view count only when there's a clear winner:
    # best must have >=10K views AND >=10x more than the current first pick
    if len(filtered) >= 2:
        views = [(details.get(h['key'], {}).get('views', 0), h) for h in filtered]
        best_views = max(v for v, _ in views)
        first_views = views[0][0]
        if best_views >= 10000 and best_views >= 10 * max(first_views, 1):
            filtered.sort(key=lambda h: details.get(h['key'], {}).get('views', 0), reverse=True)
            _log('view-rank: promoted %s (%d views) over %s (%d views)' % (
                filtered[0]['key'], best_views, views[0][1]['key'], first_views))
    return filtered  # empty = all rejected -> waterfall continues to next step


def _filterAgeRestricted(hits, skip_api=False, api_key=None):
    """Remove unavailable videos (always) and age-restricted/unlisted/cam-rip (YT addon only).
    When skip_api=True (SmartTube): uses free oEmbed existence check (0 quota).
    Falls back to unfiltered list only if API is completely unavailable (None)."""
    if not hits:
        return []
    if skip_api:
        return _filterExistence(hits)
    details = _fetchVideoDetails([h['key'] for h in hits], api_key=api_key)
    if details is None:
        return hits
    filtered = []
    for h in hits:
        d = details.get(h['key'])
        if d is None:
            _log('age-check %s: not in API response (deleted/private) REJECT' % h['key'])
            continue
        aged = d.get('age_restricted', False)
        priv = d.get('unlisted', False)
        cam  = d.get('cam_rip', False)
        ok   = not aged and not priv and not cam
        _log('age-check %s: age=%s unlisted=%s cam=%s %s' % (h['key'], aged, priv, cam, 'SKIP' if not ok else 'OK'))
        if ok:
            filtered.append(h)
    return filtered


def _htmlDecode(s):
    """Decode HTML entities in YouTube API snippet titles (&#39; -> ', &quot; -> ", etc.)."""
    from html import unescape
    return unescape(s)


def _yearConflict(vtitle, year):
    """Check if a video title contains a 4-digit year that differs from the expected year.
    Looks for years both in parentheses (2019) and bare 2019.
    Returns True if a DIFFERENT year is found — meaning the video is likely for a different movie."""
    if not year:
        return False
    decoded = _htmlDecode(vtitle)
    # Find all 4-digit years in range 1920-2039
    found = re.findall(r'(?<!\d)((?:19|20)\d{2})(?!\d)', decoded)
    if not found:
        return False  # no year in title — can't tell, allow it
    # If any found year matches the expected year, it's OK
    if year in found:
        return False
    # All found years differ from expected — wrong movie
    return True


def _titleOkChannel(vtitle, title, year=''):
    """Title check for curated channel results (KinoCheck): title match, no Shorts, year conflict."""
    vl = _htmlDecode(vtitle).lower()
    if title.lower() not in vl:
        return False
    if '#short' in vl:
        return False
    if _yearConflict(vtitle, year):
        return False
    return True


def _titleOkGlobal(vtitle, title, year=''):
    """Strict title check for global YouTube search results."""
    vl = _htmlDecode(vtitle).lower()
    if title.lower() not in vl:
        return False
    if any(w in vl for w in _JUNK_WORDS):
        return False
    if not any(w in vl for w in _TRAILER_WORDS):
        return False
    if _yearConflict(vtitle, year):
        return False
    return True


def _uploadYearOk(snippet, year, max_gap=5):
    """Check if a YouTube video's upload date is within max_gap years of the movie year.
    Uses snippet.publishedAt (available in search results, no extra API call).
    Returns True if OK or if we can't determine (missing data). False if gap too large."""
    if not year:
        return True
    pub = snippet.get('publishedAt', '')  # e.g. "2019-03-11T17:00:06Z"
    if not pub or len(pub) < 4:
        return True
    try:
        upload_year = int(pub[:4])
        movie_year = int(year)
        gap = upload_year - movie_year
        # Trailers are typically uploaded 0-2 years before/after release.
        # A large positive gap means someone uploaded a trailer for a much older movie — suspicious.
        if gap > max_gap:
            return False
    except (ValueError, TypeError):
        return True
    return True


# Known non-trailer channel keywords — oEmbed author_name check
_BAD_CHANNELS = [
    'music', 'vevo', 'records', 'gaming', 'gameplay', 'react',
    'podcast', 'radio', 'live performance',
]


def _oembedSanityCheck(video_id, title, year=''):
    """Last safety check before playing a YouTube search result (steps 4/5).
    Single oEmbed call (free, 0 quota) on the #1 pick. Checks:
    1. Video still exists (not deleted/private)
    2. Full title (not truncated) has no year conflict
    3. Channel name is not obviously wrong (music/gaming/etc.)
    Returns True if OK to play, False if should skip this step."""
    data = _oembedFetch(video_id)
    if data is None:
        _log('sanity-check %s: FAIL (unavailable)' % video_id)
        return False
    if not data:
        _log('sanity-check %s: PASS (no data, assume ok)' % video_id)
        return True  # network error — no data but assume ok
    full_title = data.get('title', '')
    author = data.get('author_name', '')
    _log('sanity-check %s: title=%r author=%r' % (video_id, full_title[:80], author))
    # Check full title for year conflict (search snippet may have been truncated)
    if full_title and _yearConflict(full_title, year):
        _log('sanity-check %s: FAIL (year conflict in full title)' % video_id)
        return False
    # Check channel name for obvious mismatches
    if author:
        al = author.lower()
        if any(w in al for w in _BAD_CHANNELS):
            _log('sanity-check %s: FAIL (bad channel: %r)' % (video_id, author))
            return False
    _log('sanity-check %s: PASS' % video_id)
    return True


# ── TMDB video helper ─────────────────────────────────────────────────────────

def _tmdbVideos(data, lang=None):
    """Extract YouTube Trailer/Teaser from a TMDB /videos response, newest first.
    If lang is given, only include videos with matching iso_639_1 (e.g. 'de', 'en')."""
    if not data:
        return []
    all_results = data.get('results', [])
    for v in all_results:
        _log('  tmdb-video: type=%s site=%s lang=%s name=%r date=%s' % (
            v.get('type'), v.get('site'), v.get('iso_639_1'),
            v.get('name', '')[:60], v.get('published_at', '')[:10]))
    videos = [v for v in all_results
              if v.get('site') == 'YouTube'
              and v.get('type') in ('Trailer', 'Teaser')
              and (lang is None or v.get('iso_639_1') == lang)]
    # Sort: Trailer before Teaser, then newest first within each type.
    videos.sort(key=lambda v: v.get('published_at', ''), reverse=True)
    videos.sort(key=lambda v: 0 if v.get('type') == 'Trailer' else 1)
    return videos


# ── Source-specific search functions ─────────────────────────────────────────

def _searchKinoCheckAPI(tmdb_id, mediatype='movie'):
    """Exact TMDB ID lookup via KinoCheck API. Free, no key required, no YT quota.
    NOT gated by _yt_api_dead — this uses kinocheck.de, not YouTube API.
    Returns (hits, api_ok):
      hits    — list of {name, key} (YouTube videos), empty if no trailer
      api_ok  — True if API responded (even with no trailer), False on error/timeout
    """
    try:
        endpoint = 'movies' if mediatype == 'movie' else 'shows'
        url = 'https://api.kinocheck.de/%s?tmdb_id=%s&language=de' % (endpoint, tmdb_id)
        _log('KinoCheck-API: %s' % url)
        data = _fetchJSON(url)
        if not data:
            _log('KinoCheck-API: empty response (down/rate-limited?)')
            return [], False
        # API responded — check for videos
        trailer = data.get('trailer')
        videos  = data.get('videos', [])
        if not trailer and not videos:
            _log('KinoCheck-API: no trailer for tmdb_id=%s' % tmdb_id)
            return [], True   # api_ok=True — they don't have it, skip YT fallback
        hits = []
        # Primary trailer first
        if trailer and trailer.get('youtube_video_id'):
            hits.append({'name': trailer.get('title', ''), 'key': trailer['youtube_video_id']})
            _log('KinoCheck-API trailer: %s %r' % (trailer['youtube_video_id'], trailer.get('title', '')[:60]))
        # Additional videos
        for v in videos:
            vid = v.get('youtube_video_id', '')
            if vid and vid not in [h['key'] for h in hits]:
                cat = v.get('categories', '')
                if cat in ('Trailer', 'Teaser'):
                    hits.append({'name': v.get('title', ''), 'key': vid})
                    _log('KinoCheck-API video: %s %r cat=%s' % (vid, v.get('title', '')[:60], cat))
        return hits, True
    except Exception as e:
        _log('KinoCheck-API exception: %s' % e)
        return [], False


def _searchKinoCheck(title, year):
    """Search KinoCheck YouTube channel for a German trailer.
    Requires working YouTube API key. Gated by _yt_api_dead flag.
    Year-matched results bubble to the top. Returns list of {name, key}."""
    try:
        if _yt_api_dead:
            _log('KinoCheck-YT: API dead, skipping')
            return []
        from urllib.parse import quote_plus
        apikey = _getUserKey()
        if not apikey:
            _log('KinoCheck-YT: no own API key, skipping')
            return []
        parts = ['"%s"' % title]
        if year:
            parts.append(str(year))
        parts.append('Trailer')
        query = ' '.join(parts)
        url   = ('https://www.googleapis.com/youtube/v3/search?part=snippet'
                 '&channelId=%s&q=%s&type=video&maxResults=10'
                 '&relevanceLanguage=de&key=%s'
                 % (KINOCHECK_CHANNEL, quote_plus(query), apikey))
        _log('KinoCheck query: %r' % query)
        data  = _fetchJSON(url)
        hits  = []
        for it in data.get('items', []):
            vtitle = it['snippet']['title']
            ok     = _titleOkChannel(vtitle, title, year)
            _log('  KinoCheck %s: %r' % ('PASS' if ok else 'REJECT', vtitle[:80]))
            if not ok:
                continue
            entry = {'name': vtitle, 'key': it['id']['videoId']}
            if year and '(%s)' % year in vtitle:
                hits.insert(0, entry)   # year match -> front
            else:
                hits.append(entry)
        return hits
    except Exception as e:
        _log('KinoCheck exception: %s' % e)
        return []


def _searchYouTube(title, year, lang=''):
    """Global YouTube search with strict title filter.
    Single query: "title" year trailer (maxResults=25).
    Results cached in _yt_search_cache. Cross-language cache hit for same-title movies.
    Gated by _yt_api_dead flag. Returns list of {name, key}."""
    try:
        if _yt_api_dead:
            _log('YouTube-%s: API dead, skipping' % (lang or 'xx'))
            return []
        from urllib.parse import quote_plus
        apikey = _getUserKey()
        if not apikey:
            _log('YouTube-%s: no own API key, skipping' % (lang or 'xx'))
            return []
        # Check cache (exact match)
        cache_key = (title.lower(), str(year), lang)
        cached_items = _yt_search_cache.get(cache_key)
        # Cross-language cache: same title+year from a different lang search
        if cached_items is None:
            for (t, y, l), items in _yt_search_cache.items():
                if t == title.lower() and y == str(year) and l != lang:
                    cached_items = items
                    _log('YouTube-%s: cross-lang cache hit from %s (%d items, 0 units)'
                         % (lang or 'xx', l, len(items)))
                    _yt_search_cache[cache_key] = items
                    break
        if cached_items is not None:
            _log('YouTube-%s: cache hit for %r year=%s, re-filtering %d items'
                 % (lang or 'xx', title, year, len(cached_items)))
            results = []
            for it in cached_items:
                vtitle = it['snippet']['title']
                ok = _titleOkGlobal(vtitle, title, year)
                if ok and not _uploadYearOk(it.get('snippet', {}), year):
                    ok = False
                    _log('  YouTube-%s REJECT (upload year gap): %r pub=%s' % (
                        lang or 'xx', vtitle[:80], it.get('snippet', {}).get('publishedAt', '')[:10]))
                else:
                    _log('  YouTube-%s %s: %r' % (lang or 'xx', 'PASS' if ok else 'REJECT', vtitle[:80]))
                if ok:
                    results.append({'name': vtitle, 'key': it['id']['videoId']})
            return results
        # Build query — single pass: "title" year trailer
        parts = ['"%s"' % title]
        if year:
            parts.append(str(year))
        parts.append('trailer')
        query = ' '.join(parts)
        url = ('https://www.googleapis.com/youtube/v3/search?part=snippet'
               '&q=%s&type=video&maxResults=25&key=%s'
               % (quote_plus(query), apikey))
        if lang:
            url += '&relevanceLanguage=%s' % lang[:2]
        _log('YouTube-%s query: %r' % (lang or 'xx', query))
        data = _fetchJSON(url)
        # Cache raw items (before filtering)
        raw_items = data.get('items', [])
        _yt_search_cache[cache_key] = raw_items
        # Filter
        results = []
        for it in raw_items:
            vtitle = it['snippet']['title']
            ok     = _titleOkGlobal(vtitle, title, year)
            if ok and not _uploadYearOk(it.get('snippet', {}), year):
                ok = False
                _log('  YouTube-%s REJECT (upload year gap): %r pub=%s' % (
                    lang or 'xx', vtitle[:80], it.get('snippet', {}).get('publishedAt', '')[:10]))
            else:
                _log('  YouTube-%s %s: %r' % (lang or 'xx', 'PASS' if ok else 'REJECT', vtitle[:80]))
            if ok:
                results.append({'name': vtitle, 'key': it['id']['videoId']})
        return results
    except Exception as e:
        _log('YouTube-%s exception: %s' % (lang or 'xx', e))
        return []


# ── IMDB direct MP4 lookup ───────────────────────────────────────────────────

# Quality preference: 1080p > 720p > 480p > SD > HLS
_IMDB_QUALITY_ORDER = ['DEF_1080p', 'DEF_720p', 'DEF_480p', 'DEF_SD']

_IMDB_GRAPHQL_URL = 'https://caching.graphql.imdb.com/'
_IMDB_GRAPHQL_QUERY = '{"query":"query($id:ID!){title(id:$id){primaryVideos(first:1){edges{node{id name{value}playbackURLs{mimeType url videoDefinition}}}}}}","variables":{"id":"%s"}}'

def _searchIMDB(imdb_id):
    """IMDB trailer lookup via GraphQL API (~3 KB response vs 1.5 MB title page).
    Returns (mp4_url, quality) on success, ('', '') on failure.
    Result cached with 1h TTL (CloudFront signed URLs expire in ~24h)."""
    import time, json
    global _imdb_dead
    if not imdb_id:
        return ('', '')
    if _imdb_dead:
        _log('IMDB: dead flag set, skipping')
        return ('', '')
    # Check cache
    cached = _imdb_cache.get(imdb_id)
    if cached:
        url, quality, expiry = cached
        if time.time() < expiry:
            _log('IMDB cache hit: %s -> %s (%s)' % (imdb_id, url[:80] if url else '', quality))
            return (url, quality)
        else:
            del _imdb_cache[imdb_id]
    # GraphQL query for primary video + playback URLs
    _log('IMDB GraphQL: %s' % imdb_id)
    from urllib.request import Request, urlopen
    from urllib.error import HTTPError
    try:
        body = (_IMDB_GRAPHQL_QUERY % imdb_id).encode('utf-8')
        req = Request(_IMDB_GRAPHQL_URL, data=body, method='POST')
        req.add_header('Content-Type', 'application/json')
        req.add_header('Accept', 'application/json')
        req.add_header('User-Agent',
                       'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
                       'AppleWebKit/537.36 (KHTML, like Gecko) '
                       'Chrome/120.0.0.0 Safari/537.36')
        resp = urlopen(req, timeout=5)
        data = json.loads(resp.read().decode('utf-8'))
    except HTTPError as e:
        if e.code in (403, 429):
            _imdb_dead = True
            _log('IMDB blocked: HTTP %d — skipping IMDB for rest of session' % e.code)
        else:
            _log('IMDB GraphQL HTTP %s' % e.code)
        return ('', '')
    except Exception as e:
        _log('IMDB GraphQL error: %s' % e)
        return ('', '')
    # Parse response: data.title.primaryVideos.edges[0].node.playbackURLs
    try:
        edges = data['data']['title']['primaryVideos']['edges']
    except (KeyError, TypeError):
        _log('IMDB: unexpected GraphQL structure for %s' % imdb_id)
        _imdb_cache[imdb_id] = ('', '', time.time() + _IMDB_CACHE_TTL)
        return ('', '')
    if not edges:
        _log('IMDB: no trailer for %s' % imdb_id)
        _imdb_cache[imdb_id] = ('', '', time.time() + _IMDB_CACHE_TTL)
        return ('', '')
    node = edges[0].get('node', {})
    video_name = (node.get('name') or {}).get('value', '')
    urls = node.get('playbackURLs', [])
    _log('IMDB: video=%s name=%r urls=%d' % (node.get('id', ''), video_name, len(urls)))
    if not urls:
        _imdb_cache[imdb_id] = ('', '', time.time() + _IMDB_CACHE_TTL)
        return ('', '')
    # Pick best quality MP4
    best_url = ''
    best_quality = ''
    for pref in _IMDB_QUALITY_ORDER:
        for entry in urls:
            if entry.get('videoDefinition') == pref and entry.get('mimeType') == 'video/mp4':
                best_url = entry['url']
                best_quality = pref.replace('DEF_', '')
                break
        if best_url:
            break
    # Fallback to HLS (M3U8)
    if not best_url:
        for entry in urls:
            if 'mpegurl' in (entry.get('mimeType') or '').lower():
                best_url = entry['url']
                best_quality = 'HLS'
                break
    # Fallback to any MP4
    if not best_url:
        for entry in urls:
            if entry.get('mimeType') == 'video/mp4':
                best_url = entry['url']
                best_quality = (entry.get('videoDefinition') or '').replace('DEF_', '') or '?'
                break
    _log('IMDB result: quality=%s url=%s' % (best_quality, best_url[:80] if best_url else ''))
    _imdb_cache[imdb_id] = (best_url, best_quality, time.time() + _IMDB_CACHE_TTL)
    return (best_url, best_quality)


# ── Notification + playback ───────────────────────────────────────────────────

def _notify(search_title, step, source, vtype, lang, poster):
    """3-second notification popup (upper-right).
    Heading: search title used (DE or EN).
    Message: source - type [lang]  e.g. 'TMDB - Trailer [DE]'
    If lang is empty (e.g. IMDB): 'IMDB - Trailer'
    """
    try:
        import xbmcgui
        icon = poster if poster else xbmcgui.NOTIFICATION_INFO
        msg = '%s - %s [%s]' % (source, vtype, lang) if lang else '%s - %s' % (source, vtype)
        xbmcgui.Dialog().notification(
            search_title,
            msg,
            icon,
            3000,
            False,
        )
    except Exception:
        pass


def _postJSON(url, payload, headers=None, timeout=12):
    """POST JSON and return a decoded dict. No external Python module required."""
    import json
    from urllib.request import Request, urlopen
    try:
        body = json.dumps(payload, separators=(',', ':')).encode('utf-8')
        req = Request(url, data=body)
        req.add_header('Content-Type', 'application/json')
        req.add_header('Accept-Language', 'de-DE,de;q=0.9,en;q=0.7')
        for key, value in (headers or {}).items():
            req.add_header(key, value)
        with urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode('utf-8'))
    except Exception as exc:
        _log('POST JSON failed: %s' % exc)
        return {}


def _trailerPrefs():
    """Read trailer playback preferences from Kodi settings."""
    try:
        import xbmcaddon
        addon = xbmcaddon.Addon()
        lang = int(addon.getSetting('trailer.language') or '1')
        profile = int(addon.getSetting('trailer.profile') or '2')
        adaptive = addon.getSetting('trailer.inputstream') != 'false'
        hdr = addon.getSetting('trailer.hdr') == 'true'
        av1 = addon.getSetting('trailer.av1') == 'true'
    except Exception:
        lang, profile, adaptive, hdr, av1 = 1, 1, True, False, False
    return lang, profile, adaptive, hdr, av1


def _trailerProfileRules(profile, allow_hdr=False, allow_av1=False):
    """Return binding limits for the selected trailer device profile.

    Resolution is evaluated using the real video height because cinematic
    YouTube trailers often use 2:1 sizes such as 1280x640 or 1920x960.
    """
    rules = {
        0: {'name': 'Automatisch', 'max_height': 4320, 'max_fps': 60, 'codecs': ('h264', 'vp9')},
        1: {'name': '720p, nur H.264', 'max_height': 720, 'max_fps': 30, 'codecs': ('h264',)},
        2: {'name': '1080p/30 fps', 'max_height': 1080, 'max_fps': 30, 'codecs': ('h264',)},
        3: {'name': '1080p/60 fps', 'max_height': 1080, 'max_fps': 60, 'codecs': ('h264', 'vp9')},
        4: {'name': '4K/30 fps', 'max_height': 2160, 'max_fps': 30, 'codecs': ('h264', 'vp9')},
        5: {'name': '4K/60 fps', 'max_height': 2160, 'max_fps': 60, 'codecs': ('h264', 'vp9')},
        6: {'name': '4K/60 fps, AV1', 'max_height': 2160, 'max_fps': 60, 'codecs': ('h264', 'vp9', 'av1')},
        7: {'name': '8K/60 fps, AV1', 'max_height': 4320, 'max_fps': 60, 'codecs': ('h264', 'vp9', 'av1')},
    }
    rule = dict(rules.get(profile, rules[1]))
    if profile == 0 and allow_av1:
        rule['codecs'] = rule['codecs'] + ('av1',)
    rule['allow_hdr'] = bool(allow_hdr)
    return rule


def _videoCodecFamily(codec_text):
    text = (codec_text or '').lower()
    if 'av01' in text or 'av1' in text:
        return 'av1'
    if 'vp09' in text or 'vp9' in text:
        return 'vp9'
    if 'avc1' in text or 'avc3' in text or 'h264' in text:
        return 'h264'
    return 'unknown'


def _isHdrVariant(text):
    value = (text or '').lower()
    return any(marker in value for marker in ('hdr', 'smpte2084', 'arib-std-b67', 'hlg', 'pq'))


def _profileAcceptsVideo(height, fps, codec, hdr, rule):
    height = int(height or 0)
    fps = int(round(float(fps or 0))) or 30
    if height and height > rule['max_height']:
        return False
    if fps > rule['max_fps']:
        return False
    if codec not in rule['codecs']:
        return False
    if hdr and not rule['allow_hdr']:
        return False
    return True


def _codecPreference(codec, rule):
    # H.264 is the safest Fire-TV baseline. Higher profiles can still choose
    # VP9/AV1 when they provide a genuinely better resolution.
    return {'h264': 3, 'vp9': 2, 'av1': 1}.get(codec, 0)


def _serveLocalMpd(video_id, profile, mpd_text, video_url, audio_url, user_agent):
    """Serve MPD plus proxied Googlevideo video/audio streams on 127.0.0.1.

    Proxying is required because inputstream.adaptive does not attach the
    YouTube client headers to BaseURL requests. The proxy forwards Range
    requests and the response metadata needed for smooth seeking/buffering.
    """
    global _trailer_http_server, _trailer_http_thread
    try:
        import threading
        from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
        from urllib.parse import urlsplit
        from urllib.request import Request, urlopen
        from urllib.error import HTTPError

        token = '%s_%s_%s' % (video_id, profile, abs(hash(mpd_text)))
        manifest_path = '/xship-trailer/%s.mpd' % token
        video_path = '/xship-trailer/%s/video' % token
        audio_path = '/xship-trailer/%s/audio' % token

        # Start the server first so its selected port can be embedded in MPD.
        if _trailer_http_server is None:
            manifests = _trailer_http_manifests
            streams = _trailer_http_streams

            class Handler(BaseHTTPRequestHandler):
                protocol_version = 'HTTP/1.1'

                def do_HEAD(self):
                    self._dispatch(False)

                def do_GET(self):
                    self._dispatch(True)

                def _dispatch(self, include_body):
                    req_path = urlsplit(self.path).path
                    body = manifests.get(req_path)
                    _diag('HTTP %s %s found=%s bytes=%s content-type=application/vnd.apple.mpegurl' % ('GET' if include_body else 'HEAD', req_path, body is not None, len(body) if body is not None else 0))
                    if body is not None:
                        self.send_response(200)
                        self.send_header('Content-Type', 'application/vnd.apple.mpegurl' if req_path.endswith('.m3u8') else 'application/dash+xml')
                        self.send_header('Content-Length', str(len(body)))
                        self.send_header('Cache-Control', 'no-store')
                        self.send_header('Access-Control-Allow-Origin', '*')
                        self.send_header('Connection', 'close')
                        self.end_headers()
                        if include_body:
                            self.wfile.write(body)
                        self.close_connection = True
                        return

                    target = streams.get(req_path)
                    if target is None:
                        self.send_response(404)
                        self.send_header('Content-Length', '0')
                        self.send_header('Connection', 'close')
                        self.end_headers()
                        self.close_connection = True
                        return
                    self._proxy(target, include_body)

                def _proxy(self, target, include_body):
                    req = Request(target['url'], method='GET' if include_body else 'HEAD')
                    req.add_header('User-Agent', target['user_agent'])
                    req.add_header('Referer', 'https://www.youtube.com/')
                    req.add_header('Origin', 'https://www.youtube.com')
                    req.add_header('Accept', '*/*')
                    req.add_header('Accept-Encoding', 'identity')
                    range_header = self.headers.get('Range')
                    if range_header:
                        req.add_header('Range', range_header)
                    try:
                        upstream = urlopen(req, timeout=60)
                    except HTTPError as exc:
                        upstream = exc
                    except Exception as exc:
                        _log('Trailer proxy request failed: %s' % exc)
                        self.send_response(502)
                        self.send_header('Content-Length', '0')
                        self.send_header('Connection', 'close')
                        self.end_headers()
                        self.close_connection = True
                        return

                    try:
                        status = getattr(upstream, 'status', None) or upstream.getcode()
                        self.send_response(status)
                        passthrough = (
                            'Content-Type', 'Content-Length', 'Content-Range',
                            'Accept-Ranges', 'ETag', 'Last-Modified', 'Expires'
                        )
                        for name in passthrough:
                            value = upstream.headers.get(name)
                            if value:
                                self.send_header(name, value)
                        self.send_header('Cache-Control', 'no-store')
                        self.send_header('Access-Control-Allow-Origin', '*')
                        self.send_header('Connection', 'close')
                        self.end_headers()
                        if include_body and status not in (204, 304):
                            while True:
                                chunk = upstream.read(1024 * 1024)
                                if not chunk:
                                    break
                                self.wfile.write(chunk)
                                self.wfile.flush()
                    except (BrokenPipeError, ConnectionResetError):
                        pass
                    except Exception as exc:
                        _log('Trailer proxy transfer failed: %s' % exc)
                    finally:
                        try:
                            upstream.close()
                        except Exception:
                            pass
                        self.close_connection = True

                def log_message(self, fmt, *args):
                    return

            class TrailerProxyServer(ThreadingHTTPServer):
                daemon_threads = True
                allow_reuse_address = True
                request_queue_size = 32

                def server_bind(self):
                    ThreadingHTTPServer.server_bind(self)
                    try:
                        import socket
                        self.socket.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
                    except Exception:
                        pass

            _trailer_http_server = TrailerProxyServer(('127.0.0.1', 0), Handler)
            _trailer_http_thread = threading.Thread(
                target=_trailer_http_server.serve_forever,
                name='xShipTrailerHTTP',
                daemon=True
            )
            _trailer_http_thread.start()
            _log('Trailer HTTP proxy server started on port %d' % _trailer_http_server.server_port)

        base = 'http://127.0.0.1:%d' % _trailer_http_server.server_port
        _trailer_http_streams[video_path] = {'url': video_url, 'user_agent': user_agent}
        _trailer_http_streams[audio_path] = {'url': audio_url, 'user_agent': user_agent}

        # Replace placeholders only after the actual local port is known.
        mpd_text = mpd_text.replace('__XSHIP_VIDEO_URL__', base + video_path)
        mpd_text = mpd_text.replace('__XSHIP_AUDIO_URL__', base + audio_path)
        _trailer_http_manifests[manifest_path] = mpd_text.encode('utf-8')

        manifest_url = base + manifest_path
        _log('Trailer MPD served at %s' % manifest_url)
        _log('Trailer media proxied via %s and %s' % (base + video_path, base + audio_path))
        return manifest_url
    except Exception as exc:
        _log('Trailer HTTP proxy server failed: %s' % exc)
        return ''


def _serveLocalHlsMaster(video_id, master_text, child_manifests=None):
    """Serve a reduced VOD HLS master, media playlists and segments locally.

    Segment requests are proxied through loopback paths with explicit file
    extensions and MIME types. This gives inputstream.adaptive reliable
    container hints while preserving Range requests and YouTube headers.
    """
    global _trailer_http_server, _trailer_http_thread
    try:
        import threading
        from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
        from urllib.parse import urlsplit
        from urllib.request import Request, urlopen
        from urllib.error import HTTPError

        token = '%s_%s' % (video_id, abs(hash(master_text)))
        manifest_path = '/xship-trailer/%s.m3u8' % token
        audio_manifest_path = '/xship-trailer/%s-audio.m3u8' % token
        video_manifest_path = '/xship-trailer/%s-video.m3u8' % token

        if _trailer_http_server is None:
            manifests = _trailer_http_manifests
            streams = _trailer_http_streams

            class Handler(BaseHTTPRequestHandler):
                protocol_version = 'HTTP/1.1'

                def do_HEAD(self):
                    self._dispatch(False)

                def do_GET(self):
                    self._dispatch(True)

                def _dispatch(self, include_body):
                    req_path = urlsplit(self.path).path
                    body = manifests.get(req_path)
                    if body is not None:
                        _diag('HTTP %s manifest path=%s bytes=%s content-type=application/vnd.apple.mpegurl range=%s' %
                              ('GET' if include_body else 'HEAD', req_path, len(body), self.headers.get('Range')))
                        self.send_response(200)
                        self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
                        self.send_header('Content-Length', str(len(body)))
                        self.send_header('Cache-Control', 'no-store')
                        self.send_header('Access-Control-Allow-Origin', '*')
                        self.send_header('Accept-Ranges', 'bytes')
                        self.send_header('Connection', 'close')
                        self.end_headers()
                        if include_body:
                            self.wfile.write(body)
                        self.close_connection = True
                        return

                    target = streams.get(req_path)
                    if target is None:
                        _diag('HTTP %s missing path=%s' % ('GET' if include_body else 'HEAD', req_path))
                        self.send_response(404)
                        self.send_header('Content-Length', '0')
                        self.send_header('Connection', 'close')
                        self.end_headers()
                        self.close_connection = True
                        return
                    self._proxy(req_path, target, include_body)

                def _proxy(self, req_path, target, include_body):
                    global _trailer_segment_cache
                    started = time.monotonic()
                    cached = _trailer_segment_cache.get(req_path)
                    if cached is not None:
                        _trailer_segment_cache.move_to_end(req_path)
                        body, meta = cached
                        cache_state = 'hit'
                    else:
                        req = Request(target['url'], method='GET')
                        for name, value in (target.get('headers') or {}).items():
                            if value is not None:
                                req.add_header(str(name), str(value))
                        req.add_header('Accept-Encoding', 'identity')
                        try:
                            upstream = urlopen(req, timeout=60)
                        except HTTPError as exc:
                            upstream = exc
                        except Exception as exc:
                            _log('Trailer HLS segment proxy failed path=%s: %s' % (req_path, exc))
                            self.send_response(502)
                            self.send_header('Content-Length', '0')
                            self.send_header('Connection', 'close')
                            self.end_headers()
                            self.close_connection = True
                            return
                        try:
                            upstream_status = getattr(upstream, 'status', None) or upstream.getcode()
                            if upstream_status not in (200, 206):
                                self.send_response(upstream_status)
                                self.send_header('Content-Length', '0')
                                self.send_header('Connection', 'close')
                                self.end_headers()
                                self.close_connection = True
                                return
                            body = upstream.read()
                            meta = {
                                'upstream_status': upstream_status,
                                'upstream_type': upstream.headers.get('Content-Type') or '',
                                'etag': upstream.headers.get('ETag'),
                                'last_modified': upstream.headers.get('Last-Modified'),
                                'expires': upstream.headers.get('Expires'),
                                'upstream_length': upstream.headers.get('Content-Length'),
                                'upstream_range': upstream.headers.get('Content-Range'),
                                'upstream_accept_ranges': upstream.headers.get('Accept-Ranges'),
                            }
                        finally:
                            try:
                                upstream.close()
                            except Exception:
                                pass
                        _trailer_segment_cache[req_path] = (body, meta)
                        _trailer_segment_cache.move_to_end(req_path)
                        while len(_trailer_segment_cache) > _TRAILER_SEGMENT_CACHE_MAX:
                            _trailer_segment_cache.popitem(last=False)
                        cache_state = 'miss'

                    total = len(body)
                    start_byte, end_byte = 0, max(total - 1, 0)
                    status = 200
                    range_header = self.headers.get('Range')
                    if range_header and total:
                        match = re.match(r'^bytes=(\d*)-(\d*)$', range_header.strip())
                        if match:
                            first, last = match.groups()
                            try:
                                if first:
                                    start_byte = int(first)
                                    end_byte = int(last) if last else total - 1
                                elif last:
                                    suffix = min(int(last), total)
                                    start_byte = total - suffix
                                    end_byte = total - 1
                                if start_byte < 0 or start_byte >= total or end_byte < start_byte:
                                    raise ValueError('invalid range')
                                end_byte = min(end_byte, total - 1)
                                status = 206
                            except Exception:
                                self.send_response(416)
                                self.send_header('Content-Range', 'bytes */%d' % total)
                                self.send_header('Content-Length', '0')
                                self.send_header('Accept-Ranges', 'bytes')
                                self.send_header('Connection', 'close')
                                self.end_headers()
                                self.close_connection = True
                                return

                    payload = body[start_byte:end_byte + 1] if total else b''
                    forced_type = target.get('content_type') or meta.get('upstream_type') or 'application/octet-stream'
                    try:
                        _diag('SEGMENT %s path=%s kind=%s ext=%s status=%s range=%s cache=%s upstream-status=%s upstream-type=%s served-type=%s upstream-length=%s served-length=%s total=%s content-range=%s upstream-content-range=%s upstream-accept-ranges=%s elapsed=%.3f url=%s' %
                              ('GET' if include_body else 'HEAD', req_path, target.get('kind'), target.get('ext'), status,
                               range_header, cache_state, meta.get('upstream_status'), meta.get('upstream_type'), forced_type,
                               meta.get('upstream_length'), len(payload), total,
                               ('bytes %d-%d/%d' % (start_byte, end_byte, total)) if status == 206 else None,
                               meta.get('upstream_range'), meta.get('upstream_accept_ranges'),
                               time.monotonic() - started, _safe_url(target['url'])))
                    except Exception as diag_exc:
                        _log('Trailer HLS segment diagnostic failed path=%s: %s' % (req_path, diag_exc))

                    try:
                        self.send_response(status)
                        self.send_header('Content-Type', forced_type)
                        self.send_header('Content-Length', str(len(payload)))
                        self.send_header('Accept-Ranges', 'bytes')
                        if status == 206:
                            self.send_header('Content-Range', 'bytes %d-%d/%d' % (start_byte, end_byte, total))
                        for source_name, output_name in (
                                ('etag', 'ETag'), ('last_modified', 'Last-Modified'), ('expires', 'Expires')):
                            value = meta.get(source_name)
                            if value:
                                self.send_header(output_name, value)
                        self.send_header('Cache-Control', 'private, max-age=120')
                        self.send_header('Access-Control-Allow-Origin', '*')
                        self.send_header('Connection', 'close')
                        self.end_headers()
                        if include_body and payload and status not in (204, 304):
                            try:
                                _diag('SEGMENT magic path=%s bytes=%s' % (req_path, payload[:16].hex()))
                            except Exception as diag_exc:
                                _log('Trailer HLS segment magic diagnostic failed path=%s: %s' % (req_path, diag_exc))
                            self.wfile.write(payload)
                            self.wfile.flush()
                    except (BrokenPipeError, ConnectionResetError):
                        pass
                    except Exception as exc:
                        _log('Trailer HLS segment transfer failed path=%s: %s' % (req_path, exc))
                    finally:
                        self.close_connection = True

                def log_message(self, fmt, *args):
                    return

            class TrailerHlsServer(ThreadingHTTPServer):
                daemon_threads = True
                allow_reuse_address = True
                request_queue_size = 32

            _trailer_http_server = TrailerHlsServer(('127.0.0.1', 0), Handler)
            _trailer_http_thread = threading.Thread(
                target=_trailer_http_server.serve_forever,
                name='xShipTrailerHLS', daemon=True)
            _trailer_http_thread.start()
            _log('Trailer HLS segment proxy server started on port %d' % _trailer_http_server.server_port)

        base = 'http://127.0.0.1:%d' % _trailer_http_server.server_port
        if child_manifests:
            for kind, local_path in (('audio', audio_manifest_path), ('video', video_manifest_path)):
                snapshot = child_manifests.get(kind) or {}
                text = snapshot.get('text') if isinstance(snapshot, dict) else snapshot
                entries = snapshot.get('streams', []) if isinstance(snapshot, dict) else []
                for entry in entries:
                    local_segment_path = '/xship-trailer/%s-%s-%04d.%s' % (
                        token, kind, int(entry['index']), entry['ext'])
                    _trailer_http_streams[local_segment_path] = {
                        'url': entry['url'], 'headers': entry.get('headers') or {},
                        'content_type': entry['content_type'], 'kind': kind,
                        'ext': entry['ext']}
                    text = text.replace(entry['placeholder'], base + local_segment_path)
                if text:
                    _diag_manifest(kind.upper() + '_LOCAL', text)
                    _trailer_http_manifests[local_path] = text.encode('utf-8')
            master_text = master_text.replace('__XSHIP_AUDIO_PLAYLIST__', base + audio_manifest_path)
            master_text = master_text.replace('__XSHIP_VIDEO_PLAYLIST__', base + video_manifest_path)
        _diag_manifest('MASTER_LOCAL', master_text)
        _trailer_http_manifests[manifest_path] = master_text.encode('utf-8')
        url = base + manifest_path
        _log('Trailer fixed-audio VOD HLS with local segments served at %s' % url)
        return url
    except Exception as exc:
        _log('Trailer fixed-audio HLS server failed: %s' % exc)
        return ''

def _stopTrailerHttpServer():
    """Stop loopback proxy after trailer playback and clear per-play state."""
    global _trailer_http_server, _trailer_http_thread
    server = _trailer_http_server
    _trailer_http_server = None
    _trailer_http_thread = None
    _trailer_http_manifests.clear()
    _trailer_http_streams.clear()
    _trailer_segment_cache.clear()
    if server is not None:
        try:
            server.shutdown()
        except Exception:
            pass
        try:
            server.server_close()
        except Exception:
            pass
        _log('Trailer HTTP proxy server stopped')


def _makeHlsVodSnapshot(playlist_url, headers, media_kind):
    """Download an HLS media playlist and build a finite local VOD snapshot.

    Every segment and URI attribute is replaced by a local placeholder. The
    HLS server later maps these placeholders to extension-bearing loopback
    proxy URLs, preserving headers and Range semantics.
    """
    import re
    import requests
    from urllib.parse import urljoin

    response = requests.get(playlist_url, headers=headers or {}, timeout=8, verify=False)
    response.raise_for_status()
    source = [line.strip() for line in response.text.splitlines() if line.strip()]
    _diag('snapshot fetch kind=%s status=%s content-type=%s length=%s url=%s' %
          (media_kind, response.status_code, response.headers.get('Content-Type'),
           response.headers.get('Content-Length'), _safe_url(playlist_url)))
    _diag_manifest('CHILD_REMOTE_' + media_kind.upper(), response.text)

    streams = []
    counter = [0]

    def local_entry(uri, attr=False):
        absolute = urljoin(playlist_url, uri)
        index = counter[0]
        counter[0] += 1
        if media_kind == 'audio':
            ext, content_type = 'aac', 'audio/aac'
        else:
            ext, content_type = 'ts', 'video/mp2t'
        placeholder = '__XSHIP_%s_SEGMENT_%04d__' % (media_kind.upper(), index)
        streams.append({'index': index, 'url': absolute, 'headers': dict(headers or {}),
                        'ext': ext, 'content_type': content_type,
                        'placeholder': placeholder, 'attribute': bool(attr)})
        _diag('SEGMENT_MAP kind=%s index=%d ext=%s content-type=%s attribute=%s remote=%s' %
              (media_kind, index, ext, content_type, bool(attr), _safe_url(absolute)))
        return placeholder

    rewritten = []
    has_type = False
    for line in source:
        upper = line.upper()
        if upper.startswith('#EXT-X-PLAYLIST-TYPE:'):
            if not has_type:
                rewritten.append('#EXT-X-PLAYLIST-TYPE:VOD')
                has_type = True
            continue
        if upper == '#EXT-X-ENDLIST':
            continue
        if line.startswith('#'):
            line = re.sub(r'URI="([^"]+)"',
                          lambda m: 'URI="%s"' % local_entry(m.group(1), True), line)
            rewritten.append(line)
        else:
            rewritten.append(local_entry(line, False))

    if not rewritten or rewritten[0] != '#EXTM3U':
        rewritten.insert(0, '#EXTM3U')
    if not has_type:
        insert_at = 1
        while insert_at < len(rewritten) and rewritten[insert_at].startswith(('#EXT-X-VERSION:', '#EXT-X-INDEPENDENT-SEGMENTS')):
            insert_at += 1
        rewritten.insert(insert_at, '#EXT-X-PLAYLIST-TYPE:VOD')
    rewritten.append('#EXT-X-ENDLIST')
    rewritten.append('')
    result = '\n'.join(rewritten)
    _diag_manifest('CHILD_VOD_' + media_kind.upper(), result)
    if streams:
        _diag_probe('FIRST_SEGMENT_' + media_kind.upper(), streams[0]['url'], headers)
    return {'text': result, 'streams': streams}

def _resolveYouTubeVendored(video_id):
    """Resolve with the embedded plugin.video.youtube player engine.

    Priority: combined progressive -> direct HLS -> resolved adaptive DASH.
    The embedded engine handles signatureCipher and the n parameter before
    xShip passes any URL to Kodi.
    """
    try:
        import os, sys
        from urllib.parse import quote_plus
        vendor_root = os.path.join(os.path.dirname(__file__), 'trailer_core')
        if vendor_root not in sys.path:
            sys.path.insert(0, vendor_root)
        from resolver import resolve as yt_resolve
        _lang, profile, adaptive, allow_hdr, allow_av1 = _trailerPrefs()
        rule = _trailerProfileRules(profile, allow_hdr, allow_av1)
        max_height = rule['max_height']
        _log('Trailer profile active: %s max_height=%d max_fps=%d codecs=%s hdr=%s' %
             (rule['name'], rule['max_height'], rule['max_fps'],
              ','.join(rule['codecs']), rule['allow_hdr']))
        streams = list(yt_resolve(video_id, sort=False, addon_id='plugin.video.xship') or [])

        def with_headers(st):
            url = st.get('url', '')
            headers = st.get('headers') or {}
            if headers and url:
                text = '&'.join('%s=%s' % (quote_plus(str(k)), quote_plus(str(v)))
                                for k, v in headers.items() if v is not None)
                if text:
                    url += '|' + text
            return url

        # 1) Most stable: one real media file containing video and audio.
        # Do not mistake HLS/MPD manifest entries for progressive files.
        progressive = []
        for st in streams:
            video = st.get('video') or {}
            audio = st.get('audio') or {}
            height = int(video.get('height') or 0)
            fps = int(video.get('fps') or 30)
            codec = _videoCodecFamily(video.get('codec') or video.get('mimeType') or st.get('codec'))
            hdr_variant = bool(video.get('hdr')) or _isHdrVariant(str(video))
            raw_url = (st.get('url') or '').lower()
            container = (st.get('container') or '').lower()
            is_manifest = ('/manifest/' in raw_url or '.m3u8' in raw_url or '.mpd' in raw_url
                           or container in ('hls', 'mpd') or st.get('hls/video') or st.get('hls/audio'))
            if video and audio and not st.get('adaptive') and st.get('url') and not is_manifest:
                if _profileAcceptsVideo(height, fps, codec, hdr_variant, rule):
                    progressive.append(st)
        if progressive:
            progressive.sort(key=lambda st: (
                int((st.get('video') or {}).get('height') or 0),
                int((st.get('video') or {}).get('fps') or 30),
                _codecPreference(_videoCodecFamily((st.get('video') or {}).get('codec')), rule),
                int((st.get('video') or {}).get('bitrate') or 0),
                int((st.get('audio') or {}).get('bitrate') or 0)), reverse=True)
            chosen = progressive[0]
            height = int((chosen.get('video') or {}).get('height') or 0)
            _log('YT full-engine progressive selected: %dp' % height)
            return {'url': with_headers(chosen), 'manifest': '', 'height': height,
                    'fps': int((chosen.get('video') or {}).get('fps') or 30)}

        # 2) Official engine supplied HLS master playlist (already signed).
        # Build a reduced local master with one H.264 video rendition and one
        # AAC audio rendition. YouTube often exposes two anonymous audio
        # renditions; Kodi selected the first one, which stalled. The last
        # rendition is the one that played correctly after manual selection.
        hls = [st for st in streams if st.get('url') and
               ((st.get('hls/audio') and st.get('hls/video')) or
                (st.get('container') or '').lower() == 'hls' or
                '/manifest/hls_' in (st.get('url') or '').lower() or
                '.m3u8' in (st.get('url') or '').lower())]
        if hls:
            chosen = sorted(hls, key=lambda st: int(st.get('sort', [0])[0] if isinstance(st.get('sort'), list) else st.get('sort') or 0), reverse=True)[0]
            master_url = chosen.get('url') or ''
            headers = chosen.get('headers') or {}
            try:
                import re, requests
                from urllib.parse import urljoin
                response = requests.get(master_url, headers=headers, timeout=8, verify=False)
                response.raise_for_status()
                raw_lines = [line.strip() for line in response.text.splitlines() if line.strip()]
                _diag('master fetch status=%s content-type=%s length=%s url=%s' % (response.status_code, response.headers.get('Content-Type'), response.headers.get('Content-Length'), _safe_url(master_url)))
                _diag_manifest('MASTER_REMOTE', response.text)

                def attr(line, name):
                    match = re.search(r'(?:^|,)%s=(?:"([^"]*)"|([^,]*))' % re.escape(name), line, re.I)
                    return (match.group(1) if match and match.group(1) is not None else
                            match.group(2) if match else '')

                header_text = '&'.join('%s=%s' % (quote_plus(str(k)), quote_plus(str(v)))
                                       for k, v in headers.items() if v is not None)
                def child_url(uri):
                    absolute = urljoin(master_url, uri)
                    return absolute + (('|' + header_text) if header_text else '')

                audio_entries = []
                for line in raw_lines:
                    if not line.startswith('#EXT-X-MEDIA:') or 'TYPE=AUDIO' not in line.upper():
                        continue
                    uri = attr(line.split(':', 1)[1], 'URI')
                    if uri:
                        audio_entries.append({'uri': uri, 'group': attr(line.split(':', 1)[1], 'GROUP-ID')})

                variants = []
                for idx, line in enumerate(raw_lines):
                    if not line.startswith('#EXT-X-STREAM-INF:') or idx + 1 >= len(raw_lines):
                        continue
                    uri = raw_lines[idx + 1]
                    if uri.startswith('#'):
                        continue
                    attrs = line.split(':', 1)[1]
                    resolution = re.search(r'RESOLUTION=(\d+)x(\d+)', attrs, re.I)
                    frame_rate = re.search(r'FRAME-RATE=([0-9.]+)', attrs, re.I)
                    bandwidth = re.search(r'BANDWIDTH=(\d+)', attrs, re.I)
                    codecs = attr(attrs, 'CODECS').lower()
                    width = int(resolution.group(1)) if resolution else 0
                    height = int(resolution.group(2)) if resolution else 0
                    fps = int(round(float(frame_rate.group(1)))) if frame_rate else 30
                    codec = _videoCodecFamily(codecs)
                    hdr_variant = _isHdrVariant(attrs)
                    if not _profileAcceptsVideo(height, fps, codec, hdr_variant, rule):
                        continue
                    variants.append({
                        'uri': uri, 'attrs': attrs, 'width': width, 'height': height,
                        'fps': fps, 'bandwidth': int(bandwidth.group(1)) if bandwidth else 0,
                        'codec': codec, 'codecs': attr(attrs, 'CODECS'),
                        'hdr': hdr_variant, 'aac': ('mp4a' in codecs or not codecs)
                    })

                if variants and audio_entries:
                    variants.sort(key=lambda v: (
                        v['height'], v['fps'], _codecPreference(v['codec'], rule),
                        v['aac'], v['bandwidth']), reverse=True)
                    variant = variants[0]
                    audio = audio_entries[-1]
                    audio_playlist_url = urljoin(master_url, audio['uri'])
                    _diag('selection variants=%d audios=%d chosen_height=%s fps=%s bandwidth=%s codec=%s aac=%s audio_group=%s audio_url=%s video_url=%s' % (len(variants), len(audio_entries), variant.get('height'), variant.get('fps'), variant.get('bandwidth'), variant.get('codec'), variant.get('aac'), audio.get('group'), _safe_url(audio_playlist_url), _safe_url(urljoin(master_url, variant['uri']))))
                    video_playlist_url = urljoin(master_url, variant['uri'])
                    audio_vod = _makeHlsVodSnapshot(audio_playlist_url, headers, 'audio')
                    video_vod = _makeHlsVodSnapshot(video_playlist_url, headers, 'video')
                    reduced = [
                        '#EXTM3U',
                        '#EXT-X-VERSION:6',
                        '#EXT-X-INDEPENDENT-SEGMENTS',
                        '#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID="xship-audio",NAME="Deutsch",LANGUAGE="de",DEFAULT=YES,AUTOSELECT=YES,URI="__XSHIP_AUDIO_PLAYLIST__"',
                        '#EXT-X-STREAM-INF:BANDWIDTH=%d,AVERAGE-BANDWIDTH=%d,RESOLUTION=%dx%d,FRAME-RATE=%d.000,CODECS="%s",AUDIO="xship-audio"' % (max(variant['bandwidth'], 1000000), max(variant['bandwidth'], 1000000), variant['width'] or 1280, variant['height'] or 720, variant['fps'], variant['codecs'] or 'avc1.4d401f,mp4a.40.5'),
                        '__XSHIP_VIDEO_PLAYLIST__',
                        ''
                    ]
                    local_url = _serveLocalHlsMaster(
                        video_id, '\n'.join(reduced),
                        {'audio': audio_vod, 'video': video_vod})
                    if local_url:
                        _log('YT HLS fixed-audio VOD selected: %dp/%dfps audio=%d/%d name=Deutsch' %
                             (variant['height'], variant['fps'], len(audio_entries), len(audio_entries)))
                        return {'url': local_url, 'manifest': 'hls',
                                'height': variant['height'], 'fps': variant['fps'],
                                'audio_reinit': True}
                _log('YT fixed-audio HLS unavailable; using signed master playlist')
            except Exception as hls_exc:
                _log('YT fixed-audio HLS build failed: %s' % hls_exc)
            _log('YT full-engine direct HLS master selected')
            return {'url': with_headers(chosen), 'manifest': 'hls', 'height': max_height, 'fps': 30,
                    'headers': '&'.join('%s=%s' % (quote_plus(str(k)), quote_plus(str(v)))
                                        for k, v in headers.items())}

        # 3) Use adaptive URLs after the official engine has deciphered them.
        videos, audios = [], []
        for st in streams:
            if not st.get('url'):
                continue
            video = st.get('video') or {}
            audio = st.get('audio') or {}
            height = int(video.get('height') or 0)
            fps = int(video.get('fps') or 30)
            codec = _videoCodecFamily(video.get('codec') or video.get('mimeType') or st.get('codec'))
            hdr_variant = bool(video.get('hdr')) or _isHdrVariant(str(video))
            if (st.get('dash/video') and video and not audio and height and
                    _profileAcceptsVideo(height, fps, codec, hdr_variant, rule)):
                videos.append(st)
            if st.get('dash/audio') and audio and not video:
                audios.append(st)
        if videos and audios and adaptive:
            videos.sort(key=lambda st: (
                int((st.get('video') or {}).get('height') or 0),
                int((st.get('video') or {}).get('fps') or 30),
                _codecPreference(_videoCodecFamily((st.get('video') or {}).get('codec')), rule),
                int((st.get('video') or {}).get('bitrate') or 0)), reverse=True)
            audios.sort(key=lambda st: int((st.get('audio') or {}).get('bitrate') or 0), reverse=True)
            v, a = videos[0], audios[0]
            # Convert official-engine stream dictionaries to the existing MPD helper schema.
            vf = {'url': v.get('url'), 'itag': str(v.get('itag') or 'v'),
                  'bitrate': int((v.get('video') or {}).get('bitrate') or 0),
                  'width': int((v.get('video') or {}).get('width') or 0),
                  'height': int((v.get('video') or {}).get('height') or 0),
                  'fps': int((v.get('video') or {}).get('fps') or 30),
                  'mimeType': 'video/mp4; codecs="%s"' % ((v.get('video') or {}).get('codec') or 'avc1.640028'),
                  'approxDurationMs': int(v.get('duration_ms') or 0),
                  'initRange': v.get('initRange') or {'start':'0','end':'0'},
                  'indexRange': v.get('indexRange') or {'start':'0','end':'0'}}
            af = {'url': a.get('url'), 'itag': str(a.get('itag') or 'a'),
                  'bitrate': int((a.get('audio') or {}).get('bitrate') or 128) * 1000,
                  'audioSampleRate': int((a.get('audio') or {}).get('sample_rate') or 48000),
                  'mimeType': 'audio/mp4; codecs="%s"' % ((a.get('audio') or {}).get('codec') or 'mp4a.40.2'),
                  'approxDurationMs': int(a.get('duration_ms') or 0),
                  'initRange': a.get('initRange') or {'start':'0','end':'0'},
                  'indexRange': a.get('indexRange') or {'start':'0','end':'0'}}
            # Some official stream dictionaries do not expose byte ranges. In that case
            # let Kodi use the direct official MPD/HLS entry instead of generating one.
            _log('YT full-engine adaptive URLs resolved: %dp + audio' % vf['height'])

        # The embedded engine may expose a ready MPD URL generated by its own logic.
        mpds = [st for st in streams if st.get('url') and
                ((st.get('dash/audio') and st.get('dash/video')) or
                 (st.get('container') or '').lower() == 'mpd')]
        if mpds:
            chosen = mpds[0]
            _log('YT full-engine direct MPD selected')
            return {'url': with_headers(chosen), 'manifest': 'mpd', 'height': max_height, 'fps': 30,
                    'headers': '&'.join('%s=%s' % (quote_plus(str(k)), quote_plus(str(v)))
                                        for k, v in (chosen.get('headers') or {}).items())}

        _log('YT full-engine: no playable progressive/HLS/MPD stream')
        return None
    except Exception as exc:
        _log('YT full-engine failed: %s' % exc)
        return None


def _resolveYouTube(video_id):
    """Resolve a YouTube ID with xShip's embedded engine.

    The previously bundled yt-dlp preflight was removed because current
    YouTube clients require a PO token. It never produced a playable stream
    in this setup and only delayed the working HLS fallback.
    """
    stream = _resolveYouTubeVendored(video_id)
    if stream:
        return stream
    _log('YT embedded engine found no playable stream; legacy DASH proxy disabled')
    return None

def _play(video_id, step, source, vtype, lang, poster, search_title, metadata=None):
    """Resolve and play a YouTube trailer entirely inside xShip."""
    _log('PLAY-INTERNAL video_id=%s step=%d source=%s vtype=%s lang=%s title=%r'
         % (video_id, step, source, vtype, lang, search_title))
    stream = _resolveYouTube(video_id)
    if not stream:
        _log('PLAY-INTERNAL resolver failed for %s' % video_id)
        return False
    _playDirect(stream, step, source, vtype, lang, poster, search_title, metadata)
    return True


class _TrailerPlayer(object):
    """Kodi player wrapper with callbacks for immediate stop/end detection."""
    def __init__(self):
        import xbmc as _xbmc
        class _P(_xbmc.Player):
            def __init__(s): super().__init__(); s.done = False
            def onPlayBackStopped(s): s.done = True
            def onPlayBackEnded(s): s.done = True
            def onPlayBackError(s): s.done = True
        self._p = _P()
        self._mon = _xbmc.Monitor()
        self._xbmc = _xbmc
    def play(self, url, item=None):
        self._p.play(url, item) if item is not None else self._p.play(url)
        timeout = time.time() + 15
        while time.time() < timeout:
            try:
                if self._p.isPlaying():
                    break
            except Exception:
                pass
            self._xbmc.sleep(250)
        _busy_close()
    def stop(self): self._p.stop()
    def set_audio_stream(self, index=0):
        try:
            self._p.setAudioStream(int(index))
            return True
        except Exception as exc:
            _log('PLAY-DIRECT audio reinit failed: %s' % exc)
            return False
    @property
    def done(self): return self._p.done
    def wait(self, secs): return self._mon.waitForAbort(secs)
    @property
    def aborted(self): return self._mon.abortRequested()
    def fullscreen(self):
        return self._xbmc.getCondVisibility('Window.IsVisible(fullscreenvideo)')


def _playDirect(stream, step, source, vtype, lang, poster, search_title, metadata=None):
    """Show source popup then play a direct MP4/M3U8 URL via Kodi's native player.
    Monitors fullscreen — stops playback when user presses back."""
    import xbmcgui
    if isinstance(stream, dict):
        url = stream.get('url', '')
        manifest = stream.get('manifest', '')
        # Direct progressive URLs need the same request headers yt-dlp used.
        # Kodi accepts them after a pipe separator.
        if not manifest and stream.get('headers_dict') and '|' not in url:
            try:
                from urllib.parse import quote_plus
                header_text = '&'.join('%s=%s' % (quote_plus(str(k)), quote_plus(str(v)))
                                       for k, v in stream.get('headers_dict', {}).items())
                if header_text:
                    url = url + '|' + header_text
            except Exception as exc:
                _log('Trailer direct header warning: %s' % exc)
    else:
        url, manifest = stream, ''
    _log('PLAY-DIRECT url=%s step=%d source=%s vtype=%s title=%r'
         % (url[:80], step, source, vtype, search_title))
    _notify(search_title, step, source, vtype, lang, poster)

    meta = metadata or {}
    display_title = meta.get('title') or search_title or 'Trailer'
    year_text = str(meta.get('year') or '').strip()
    label = '%s%s – %s %s' % (display_title, (' (' + year_text + ')') if year_text else '', lang, vtype)
    item = xbmcgui.ListItem(label=label, path=url)
    item.setArt({'poster': poster or meta.get('poster',''), 'thumb': poster or meta.get('poster',''),
                 'icon': poster or meta.get('poster',''), 'fanart': meta.get('fanart') or poster or ''})
    try:
        tag = item.getVideoInfoTag()
        tag.setTitle(label)
        if meta.get('original_title'): tag.setOriginalTitle(str(meta.get('original_title')))
        if year_text.isdigit(): tag.setYear(int(year_text))
        tag.setPlot(meta.get('plot') or ('Offizieller %s Trailer von %s' % (lang, source)))
        genres = meta.get('genres') or []
        if genres: tag.setGenres([str(x) for x in genres])
        if meta.get('runtime'): tag.setDuration(int(meta.get('runtime')) * 60)
        if meta.get('rating'): tag.setRating(float(meta.get('rating')))
        tag.setMediaType('video')
    except Exception as exc:
        _log('Trailer metadata warning: %s' % exc)
    if manifest in ('mpd', 'hls'):
        item.setProperty('inputstream', 'inputstream.adaptive')
        if manifest == 'hls':
            item.setMimeType('application/vnd.apple.mpegurl')
        else:
            item.setMimeType('application/dash+xml')
        if isinstance(stream, dict) and stream.get('headers'):
            item.setProperty('inputstream.adaptive.stream_headers', stream.get('headers'))
    tp = _TrailerPlayer()
    tp.play(url, item)
    # Wait for fullscreen to appear — exit early if playback fails
    fs_seen = False
    while not tp.aborted and not tp.done:
        if tp.fullscreen():
            fs_seen = True
            break
        tp.wait(0.1)
    if not fs_seen:
        _log('PLAY-DIRECT: playback ended before fullscreen')
        _stopTrailerHttpServer()
        return

    # Kodi 21/inputstream.adaptive may detect the single HE-AAC rendition but
    # not initialize its sample reader until the audio pipeline is reopened.
    # Re-selecting the only stream performs the same harmless reinitialization
    # as opening the audio menu, without changing passthrough globally.
    if isinstance(stream, dict) and stream.get('audio_reinit'):
        _diag('AAC reinit scheduled delay=1.4s url=%s' % _safe_url(url))
        waited = 0.0
        while waited < 1.4 and not tp.aborted and not tp.done:
            tp.wait(0.1)
            waited += 0.1
        _diag('AAC reinit state waited=%.1f aborted=%s done=%s fullscreen=%s' % (waited, tp.aborted, tp.done, tp.fullscreen()))
        if not tp.aborted and not tp.done and tp.set_audio_stream(0):
            _log('PLAY-DIRECT: AAC stream 1/1 reinitialized after %.1fs' % waited)
            _diag('AAC reinit result=success stream=0')
        else:
            _diag('AAC reinit result=skipped-or-failed stream=0')

    # Monitor: stop when user leaves fullscreen (back = stop for trailers)
    while not tp.aborted and not tp.done:
        if not tp.fullscreen():
            tp.stop()
            _log('PLAY-DIRECT stopped (user left fullscreen)')
            break
        tp.wait(0.3)
    _stopTrailerHttpServer()


# ── One-time guidance popups (v7) ─────────────────────────────────────────────

def _showHintIfNeeded(has_yt_player, has_own_key, found_german, played_imdb):
    """Show guidance popup after trailer plays (or at give-up). Once per Kodi session.
    Popup 1: no player installed, IMDB played → suggest SmartTube / YT addon.
    Popup 2: has player but no own key, no German found → suggest own API key.
    Returns True if a popup was shown."""
    try:
        import xbmc, xbmcgui
        win = xbmcgui.Window(10000)

        if not has_yt_player and played_imdb:
            # Popup 1: IMDB worked but no player for KinoCheck/TMDB/YouTube
            if not win.getProperty('xship.trailer.hint.player'):
                xbmc.sleep(2000)
                is_android = xbmc.getCondVisibility('System.Platform.Android')
                if is_android:
                    msg = ('Tipp: Für deutsche Trailer (KinoCheck/TMDB) SmartTube installieren.\n'
                           'Für YouTube-Suche zusätzlich: YouTube Add-on mit eigenem API-Key einrichten.')
                else:
                    msg = ('Tipp: YouTube Add-on mit eigenem API-Key installieren für '
                           'deutsche Trailer (KinoCheck/TMDB) und YouTube-Suche.')
                xbmcgui.Dialog().ok('Trailer', msg)
                win.setProperty('xship.trailer.hint.player', '1')
                _log('hint: showed player popup')
                return True

        elif has_yt_player and not has_own_key and not found_german:
            # Popup 2: has player but no own key, no German trailer found
            if not win.getProperty('xship.trailer.hint.apikey'):
                xbmc.sleep(2000)
                msg = ('Kein deutscher Trailer bei KinoCheck/TMDB/IMDB gefunden.\n'
                       'YouTube Add-on mit eigenem API-Key einrichten für zusätzliche YouTube-Trailersuche.')
                xbmcgui.Dialog().ok('Trailer', msg)
                win.setProperty('xship.trailer.hint.apikey', '1')
                _log('hint: showed apikey popup')
                return True

    except Exception as e:
        _log('hint popup error: %s' % e)
    return False


# ── Main entry point ──────────────────────────────────────────────────────────

def playTrailer(tmdb_id, mediatype='movie', title='', year='', poster=''):
    """Trailer waterfall for xShip — search phase + play phase.

    Args:
        tmdb_id:   TMDB numeric ID (string)
        mediatype: 'movie' or 'tv'
        title:     display title in German (for YouTube fallback searches)
        year:      release year string  (for YouTube fallback searches)
        poster:    poster image URL     (shown as notification icon)
    """
    import xbmc, xbmcgui
    from resources.lib.tmdb import cTMDB

    url_type  = 'movie' if mediatype == 'movie' else 'tv'
    title_key = 'title' if mediatype == 'movie' else 'name'
    tmdb_de   = cTMDB()
    tmdb_en   = cTMDB(lang='en')

    try:
        de_data = tmdb_de.getUrl('%s/%s' % (url_type, tmdb_id)) or {}
    except Exception:
        de_data = {}
    genre_names = [g.get('name') for g in (de_data.get('genres') or []) if isinstance(g, dict) and g.get('name')]
    ep_runtime = de_data.get('episode_run_time') or []
    trailer_meta = {
        'title': title or de_data.get(title_key, ''),
        'original_title': de_data.get('original_title') or de_data.get('original_name') or '',
        'year': year or str((de_data.get('release_date') or de_data.get('first_air_date') or '')[:4]),
        'plot': de_data.get('overview') or '',
        'genres': genre_names,
        'runtime': de_data.get('runtime') or (ep_runtime[0] if ep_runtime else 0),
        'rating': de_data.get('vote_average') or 0,
        'poster': poster,
        'fanart': ('https://image.tmdb.org/t/p/original' + de_data.get('backdrop_path')) if de_data.get('backdrop_path') else '',
    }

    _log('START tmdb_id=%s title=%r year=%s mediatype=%s' % (tmdb_id, title, year, mediatype))
    lang_mode, profile, adaptive, allow_hdr, allow_av1 = _trailerPrefs()
    _log('Settings: language=%d profile=%d adaptive=%s hdr=%s av1=%s' % (lang_mode, profile, adaptive, allow_hdr, allow_av1))
    _busy_open()

    # ── Internal playback: no YouTube/SmartTube/TMDbHelper dependency ──
    has_yt_player = True
    has_own_key = bool(_getUserKey())
    skip_api = True          # use free existence checks; playback is resolved internally
    _vf = _api_checksum
    _log('Player: xShip internal resolver | has_own_key: %s' % has_own_key)

    # ── Fetch English title + IMDB ID up front ───────────────────────
    en_data = None
    try:
        if url_type == 'tv':
            en_data = tmdb_en.getUrl('%s/%s' % (url_type, tmdb_id), term='append_to_response=external_ids')
        else:
            en_data = tmdb_en.getUrl('%s/%s' % (url_type, tmdb_id))
        en_title = (en_data or {}).get(title_key, '') or title
    except Exception:
        en_title = title
    # Extract IMDB ID (movies: top-level; TV: external_ids sub-object)
    imdb_id = (en_data or {}).get('imdb_id', '')
    if not imdb_id and url_type == 'tv':
        imdb_id = (en_data or {}).get('external_ids', {}).get('imdb_id', '') or ''
    _log('EN title: %r (DE title: %r) imdb_id: %s' % (en_title, title, imdb_id))

    # ── Steps 1-3: YouTube-based sources via internal resolver ──────
    if has_yt_player:
        # ── Step 1: KinoCheck API (exact TMDB ID, free, no YT quota) ─────
        _log('--- Step 1: KinoCheck API ---')
        kc_api_hits, kc_api_ok = _searchKinoCheckAPI(tmdb_id, mediatype)
        _log('Step1 KinoCheck-API: hits=%d api_ok=%s' % (len(kc_api_hits), kc_api_ok))
        if kc_api_hits:
            # Red Band trailers may be age-restricted — prefer non-Red-Band on YT addon
            if not skip_api:
                non_rb = [h for h in kc_api_hits if 'red band' not in h.get('name', '').lower()]
                if non_rb:
                    kc_api_hits = non_rb
                else:
                    # Only Red Band results — age-check before playing on YT addon
                    _log('Step1 KinoCheck-API: only Red Band, running age-check')
                    kc_api_hits = _filterAgeRestricted(kc_api_hits, skip_api=False, api_key=_vf)
            else:
                # SmartTube — still verify video exists (free oEmbed check)
                kc_api_hits = _filterExistence(kc_api_hits)
            if kc_api_hits:
                if _play(kc_api_hits[0]['key'], 1, 'KinoCheck', 'Trailer', 'DE', poster, title, trailer_meta):
                    return
            _log('Step1 KinoCheck-API: all results unavailable, continuing waterfall')

        # ── Step 1b: KinoCheck YT channel (API down + own key for search.list) ─
        if not kc_api_ok and has_own_key:
            _log('--- Step 1b: KinoCheck YT fallback (API was down) ---')
            kc_raw = _searchKinoCheck(title, year)
            kc_hit = _filterByDuration(kc_raw, skip_api=skip_api, api_key=_vf)
            _log('Step1b KinoCheck-YT: raw=%d filtered=%d' % (len(kc_raw), len(kc_hit)))
            if kc_hit:
                if _play(kc_hit[0]['key'], 1, 'KinoCheck', 'Trailer', 'DE', poster, title, trailer_meta):
                    return

        # ── Step 2: TMDB videos (German) ──────────────────────────────────
        _log('--- Step 2: TMDB-DE videos ---')
        tmdb_de_raw = tmdb_de.getUrl('%s/%s/videos' % (url_type, tmdb_id))
        videos = _filterAgeRestricted(_tmdbVideos(tmdb_de_raw, lang='de'), skip_api=skip_api, api_key=_vf)
        _log('Step2 TMDB-DE: raw=%d filtered=%d' % (len((tmdb_de_raw or {}).get('results', [])), len(videos)))
        if videos:
            _norm = lambda s: re.sub(r"[^a-z0-9äöüß]+", '', (s or '').lower())
            german_videos = [v for v in videos if _norm(title) and _norm(title) in _norm(v.get('name', ''))]
            _log('Step2 strict-DE: candidates=%d accepted=%d' % (len(videos), len(german_videos)))
            if german_videos:
                video = german_videos[0]
                if _play(video['key'], 2, 'TMDB', video.get('type', 'Trailer'), 'DE', poster, title, trailer_meta):
                    return

        # ── Step 3: TMDB videos (English) ─────────────────────────────────
        if lang_mode == 0:
            tmdb_en_raw = None
        else:
            _log('--- Step 3: TMDB-EN videos ---')
            tmdb_en_raw = tmdb_en.getUrl('%s/%s/videos' % (url_type, tmdb_id))
            videos = _filterAgeRestricted(_tmdbVideos(tmdb_en_raw, lang='en'), skip_api=skip_api, api_key=_vf)
            _log('Step3 TMDB-EN: raw=%d filtered=%d' % (len((tmdb_en_raw or {}).get('results', [])), len(videos)))
            if videos:
                if _play(videos[0]['key'], 3, 'TMDB', videos[0].get('type', 'Trailer'), 'EN', poster, en_title, trailer_meta):
                    return
    else:
        tmdb_en_raw = None  # not fetched — no YT player to play TMDB results

    # ── Step 3b: IMDB (direct MP4, no player needed) ─────────────────
    if lang_mode != 0 and imdb_id and not _imdb_dead:
        _log('--- Step 3b: IMDB ---')
        imdb_url, imdb_quality = _searchIMDB(imdb_id)
        _log('Step3b IMDB: url=%s quality=%s' % (imdb_url[:80] if imdb_url else '', imdb_quality))
        if imdb_url:
            _playDirect(imdb_url, 3, 'IMDB', 'Trailer', '', poster, en_title or title)
            return

    # ── Steps 4-5b: YouTube search + TMDB-ANY ────────────────────────
    if has_yt_player:
        # ── Steps 4-5: YouTube search (needs own API key for search.list) ─
        if has_own_key:
            user_key = _getUserKey()

            # ── Step 4: YouTube search (German) ───────────────────────────
            _log('--- Step 4: YouTube-DE ---')
            yt_de_raw = _searchYouTube(title, year, lang='de')
            yt_de_hit = _filterByDuration(yt_de_raw, skip_api=skip_api, api_key=user_key)
            _log('Step4 YouTube-DE: raw=%d filtered=%d' % (len(yt_de_raw), len(yt_de_hit)))
            if yt_de_hit and _oembedSanityCheck(yt_de_hit[0]['key'], title, year):
                if _play(yt_de_hit[0]['key'], 4, 'YouTube', 'Trailer', 'DE', poster, title, trailer_meta):
                    return

            # ── Step 5: YouTube search (English TMDB title) ───────────────
            if lang_mode != 0:
                _log('--- Step 5: YouTube-EN ---')
                yt_en_raw = _searchYouTube(en_title, year, lang='en')
                yt_en_hit = _filterByDuration(yt_en_raw, skip_api=skip_api, api_key=user_key)
                _log('Step5 YouTube-EN title=%r raw=%d filtered=%d' % (en_title, len(yt_en_raw), len(yt_en_hit)))
                if yt_en_hit and _oembedSanityCheck(yt_en_hit[0]['key'], en_title, year):
                    if _play(yt_en_hit[0]['key'], 5, 'YouTube', 'Trailer', 'EN', poster, en_title):
                        return

        # ── Step 5b: TMDB videos (any language — catches ES, KO, ZH, JA, etc.) ─
        if lang_mode == 2:
            _log('--- Step 5b: TMDB-ANY videos ---')
            # Reuse tmdb_en_raw (EN endpoint returns all videos, we just filtered for EN before)
            if tmdb_en_raw:
                videos = _filterAgeRestricted(_tmdbVideos(tmdb_en_raw), skip_api=skip_api, api_key=_vf)
                # Exclude DE/EN videos we already tried
                videos = [v for v in videos if v.get('iso_639_1') not in ('de', 'en')]
            else:
                videos = []
            _log('Step5b TMDB-ANY: filtered=%d' % len(videos))
            if videos:
                vlang = (videos[0].get('iso_639_1') or '??').upper()
                if _play(videos[0]['key'], 5, 'TMDB', videos[0].get('type', 'Trailer'), vlang, poster, en_title, trailer_meta):
                    return

    # ── Step 6: Give up ───────────────────────────────────────────────
    _log('Step6 give up — has_yt_player=%s has_own_key=%s' % (has_yt_player, has_own_key))
    xbmcgui.Dialog().notification(
        'Trailer', ('Kein deutscher Trailer gefunden' if lang_mode == 0 else 'Kein direkt abspielbarer Trailer gefunden'),
        xbmcgui.NOTIFICATION_WARNING, 3500,
    )
