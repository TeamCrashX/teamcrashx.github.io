# edit 2025-06-12
import sys
import re, json, random, time, os, threading, traceback, uuid
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FutureTimeoutError
from resources.lib import log_utils, utils, control
from resources.lib.control import py2_decode, py2_encode, quote_plus, parse_qsl
import resolveurl as resolver
# from functools import reduce
from resources.lib.control import getKodiVersion

if int(getKodiVersion()) >= 20: from infotagger.listitem import ListItemInfoTag

# für self.sysmeta - zur späteren verwendung als meta
_params = dict(parse_qsl(sys.argv[2].replace('?',''))) if len(sys.argv) > 1 else dict()

class _SilentProgress:
    def create(self, *args, **kwargs): pass
    def update(self, *args, **kwargs): pass
    def close(self, *args, **kwargs): pass
    def iscanceled(self): return False


class sources:
    def __init__(self):
        self.getConstants()
        self.sources = []
        self.current = int(time.time())
        if 'sysmeta' in _params: self.sysmeta = _params['sysmeta'] # string zur späteren verwendung als meta
        self.watcher = False
        self.executor = ThreadPoolExecutor(max_workers=20)
        self.url = None
        self.scraper_stats = {}
        self.scraper_stats_lock = threading.Lock()
        self._series_next_autoplay = False

    def get(self, params):
        data = json.loads(params['sysmeta'])
        self.mediatype = data.get('mediatype')
        self.aliases = data.get('aliases') if 'aliases' in data else []
        # Folgewechsel nach dem Ja-Dialog: Quellen komplett im Hintergrund suchen.
        # Normale Aufrufe (inkl. Filme) behalten ihre bisherigen Dialoge.
        self._series_next_autoplay = bool(data.get('_series_next_autoplay')) and data.get('mediatype') != 'movie'

        title = py2_encode(data.get('title'))
        originaltitle = py2_encode(data.get('originaltitle')) if 'originaltitle' in data else title
        year = data.get('year') if 'year' in data else None
        imdb = data.get('imdb_id') if 'imdb_id' in data else data.get('imdbnumber') if 'imdbnumber' in data else None
        if not imdb and 'imdb' in data: imdb = data.get('imdb')
        tmdb = data.get('tmdb_id') if 'tmdb_id' in data else None
        #if tmdb and not imdb: print 'hallo' #TODO
        season = data.get('season') if 'season' in data else 0
        episode = data.get('episode') if 'episode' in data else 0
        premiered = data.get('premiered') if 'premiered' in data else None
        meta = params['sysmeta']
        select = data.get('select') if 'select' in data else None
        return title, year, imdb, season, episode, originaltitle, premiered, meta, select

    def play(self, params):
        title, year, imdb, season, episode, originaltitle, premiered, meta, select = self.get(params)
        try:
            url = None
            #Liste der gefundenen Streams
            items = self.getSources(title, year, imdb, season, episode, originaltitle, premiered)
            if select == None:
                # Filme und Serien besitzen getrennte Standard-Aktionen.
                # GUI-Reihenfolge: Autoplay|Dialog|Verzeichnis -> intern: 2|0|1.
                is_series = bool(int(season or 0))
                mode = control.getSetting('series.play.mode' if is_series else 'movie.play.mode')
                select = {'0': '2', '1': '0', '2': '1'}.get(mode, '2')
            ## unnötig
            #select = '1' if control.getSetting('downloads') == 'true' and not (control.getSetting('download.movie.path') == '' or control.getSetting('download.tv.path') == '') else select

            # # TODO überprüfen wofür mal gedacht
            # if control.window.getProperty('PseudoTVRunning') == 'True':
            #     return control.resolveUrl(int(sys.argv[1]), True, control.item(path=str(self.sourcesDirect(items))))

            if len(items) > 0:
                # Auswahl Verzeichnis
                if select == '1' and 'plugin' in control.infoLabel('Container.PluginName'):
                    # Treffer auf Fire-TV-schonend in eine kleine Cache-Datei schreiben.
                    # In der Kodi-Liste werden jeweils nur 100 ListItems erzeugt.
                    cache_id = self._write_sources_cache(items)
                    control.window.clearProperty(self.metaProperty)
                    control.window.setProperty(self.metaProperty, meta)
                    control.sleep(1)
                    return control.execute('Container.Update(%s?action=addItem&title=%s&page=0&cacheid=%s)' % (
                        sys.argv[0], quote_plus(title), cache_id))
                # Auswahl Dialog
                elif select == '0' or select == '1':
                    url = self.sourcesDialog(items)
                    if  url == 'close://': return
                # Autoplay
                else:
                    url = self.sourcesDirect(items)

            if url == None: return self.errorForSources()

            try: meta = json.loads(meta)
            except: pass

            from resources.lib.player import player
            player().run(title, url, meta)
        except Exception as e:
            log_utils.log('Error %s' % str(e), log_utils.LOGERROR)


# Liste gefundene Streams Indexseite|Hoster
    def addItem(self, title, page=0, cache_id=''):
        control.playlist.clear()

        try:
            page = max(0, int(page or 0))
        except:
            page = 0

        items = self._read_sources_cache(cache_id)
        if items is None:
            # Rückwärtskompatibilität für alte Aufrufe innerhalb derselben Sitzung.
            try:
                items = json.loads(control.window.getProperty(self.itemsProperty))
            except:
                items = []
        if not items:
            control.infoDialog('Treffer-Cache ist abgelaufen. Bitte Suche erneut starten.', sound=True, icon='WARNING')
            control.idle()
            return

        page_size = 100
        start = page * page_size
        end = min(start + page_size, len(items))
        page_items = items[start:end]

        sysaddon = sys.argv[0]
        syshandle = int(sys.argv[1])
        systitle = sysname = quote_plus(title)

        meta = control.window.getProperty(self.metaProperty)
        meta = json.loads(meta)
#TODO
        if meta['mediatype'] == 'movie':
            # downloads = True if control.getSetting('downloads') == 'true' and control.exists(control.translatePath(control.getSetting('download.movie.path'))) else False
            downloads = True if control.getSetting('downloads') == 'true' and control.getSetting('download.movie.path') else False
        else:
            # downloads = True if control.getSetting('downloads') == 'true' and control.exists(control.translatePath(control.getSetting('download.tv.path'))) else False
            downloads = True if control.getSetting('downloads') == 'true' and control.getSetting('download.tv.path') else False

        addonPoster, addonBanner = control.addonPoster(), control.addonBanner()
        addonFanart, settingFanart = control.addonFanart(), control.getSetting('fanart')

        if 'backdrop_url' in meta and 'http' in meta['backdrop_url']: fanart = meta['backdrop_url']
        elif 'fanart' in meta and 'http' in meta['fanart']: fanart = meta['fanart']
        else: fanart = addonFanart

        if 'cover_url' in meta and 'http' in meta['cover_url']: poster = meta['cover_url']
        elif 'poster' in meta and 'http' in meta['poster']: poster = meta['poster']
        else:  poster = addonPoster
        sysimage = poster

        if 'season' in meta and 'episode' in meta:
            sysname += quote_plus(' S%02dE%02d' % (int(meta['season']), int(meta['episode'])))
        elif 'year' in meta:
            sysname += quote_plus(' (%s)' % meta['year'])

        for i in range(len(page_items)):
            try:
                label = page_items[i]['label']

                # FILMO/Byse kann auf Kodi ohne Browser die vorgeschaltete
                # interaktive Attestation nicht abschließen. Für diese Einträge
                # geben wir deshalb ein paar normale Alternativen mit an playItem
                # weiter. Die ausgewählte Byse-Quelle bleibt sichtbar, wird beim
                # Start aber ohne 40-Sekunden-Timeout übersprungen.
                source_payload = [page_items[i]]
                try:
                    _selected = page_items[i]
                    _is_filmo_byse = (
                        str(_selected.get('provider', '')).lower() == 'filmo' and
                        'byse' in str(_selected.get('source', '')).lower()
                    )
                    if _is_filmo_byse:
                        _fallbacks = []
                        # Zuerst ein anderer FILMO-Hoster (z.B. VOE), danach
                        # gleichwertige Quellen anderer Provider, dann der Rest.
                        _groups = (0, 1, 2)
                        for _group in _groups:
                            for _candidate in page_items:
                                if _candidate is _selected:
                                    continue
                                if (str(_candidate.get('provider', '')).lower() == 'filmo' and
                                        'byse' in str(_candidate.get('source', '')).lower()):
                                    continue
                                if _group == 0 and str(_candidate.get('provider', '')).lower() != 'filmo':
                                    continue
                                if _group == 1 and str(_candidate.get('quality', '')).lower() != str(_selected.get('quality', '')).lower():
                                    continue
                                if _group == 2:
                                    pass
                                elif _group == 0:
                                    pass
                                # Gruppe 1 soll FILMO-Duplikate nicht erneut aufnehmen.
                                if _candidate in _fallbacks:
                                    continue
                                _fallbacks.append(_candidate)
                                if len(_fallbacks) >= 3:
                                    break
                            if len(_fallbacks) >= 3:
                                break
                        source_payload.extend(_fallbacks)
                except Exception:
                    pass

                syssource = quote_plus(json.dumps(source_payload))

                item = control.item(label=label, offscreen=True)
                item.setProperty('IsPlayable', 'true')
                item.setArt({'poster': poster, 'banner': addonBanner})
                if settingFanart == 'true': item.setProperty('Fanart_Image', fanart)

                cm = []
                if downloads:
                    cm.append(("Download", 'RunPlugin(%s?action=download&name=%s&image=%s&source=%s)' % (sysaddon, sysname, sysimage, syssource)))
                if control.getSetting('jd_enabled') == 'true':
                    cm.append(("Sende zum JDownloader", 'RunPlugin(%s?action=sendToJD&name=%s&source=%s)' % (sysaddon, sysname, syssource)))
                if control.getSetting('jd2_enabled') == 'true':
                    cm.append(("Sende zum JDownloader2", 'RunPlugin(%s?action=sendToJD2&name=%s&source=%s)' % (sysaddon, sysname, syssource)))
                if control.getSetting('myjd_enabled') == 'true':
                    cm.append(("Sende zu My.JDownloader", 'RunPlugin(%s?action=sendToMyJD&name=%s&source=%s)' % (sysaddon, sysname, syssource)))
                if control.getSetting('pyload_enabled') == 'true':
                    cm.append(("Sende zu PyLoad", 'RunPlugin(%s?action=sendToPyLoad&name=%s&source=%s)' % (sysaddon, sysname, syssource)))
                cm.append(("Medien-Info", 'RunPlugin(%s?action=mediaInfo&source=%s)' % (sysaddon, syssource)))
                cm.append(('Einstellungen', 'RunPlugin(%s?action=addonSettings)' % sysaddon))
                item.addContextMenuItems(cm)

                url = "%s?action=playItem&title=%s&source=%s" % (sysaddon, systitle, syssource)

                # ## Notwendig für Library Exporte ##
                # ## Amazon Scraper Details ##
                # if "amazon" in label.lower():
                #     aid = re.search(r'asin%3D(.*?)%22%2C', url)
                #     url = "plugin://plugin.video.amazon-test/?mode=PlayVideo&asin=" + aid.group(1)

                ##https: // codedocs.xyz / AlwinEsch / kodi / group__python__xbmcgui__listitem.html  # ga0b71166869bda87ad744942888fb5f14

                name = '%s%sStaffel: %s   Episode: %s' % (title, "\n", meta['season'], meta['episode']) if 'season' in meta else title
                plot = meta['plot'] if 'plot' in meta and len(meta['plot'].strip()) >= 1 else ''
                plot = '[COLOR blue]%s[/COLOR]%s%s' % (name, "\n\n", py2_encode(plot))

                if 'duration' in meta:
                    infolable = {'plot': plot,'duration': meta['duration']}
                else:
                    infolable = {'plot': plot}

                # TODO
                # if 'cast' in meta and meta['cast']: item.setCast(meta['cast'])
                # # # remove unsupported InfoLabels
                meta.pop('cast', None)  # ersetzt durch item.setCast(i['cast'])
                meta.pop('number_of_seasons', None)
                meta.pop('imdb_id', None)
                meta.pop('tvdb_id', None)
                meta.pop('tmdb_id', None)

                ## Quality Video Stream from source.append quality - page_items[i]['quality']
                video_streaminfo ={}
                if "4k" in page_items[i]['quality'].lower():
                    video_streaminfo.update({'width': 3840, 'height': 2160})
                elif "1080p" in page_items[i]['quality'].lower():
                    video_streaminfo.update({'width': 1920, 'height': 1080})
                elif "hd" in page_items[i]['quality'].lower() or "720p" in page_items[i]['quality'].lower():
                    video_streaminfo.update({'width': 1280,'height': 720})
                else:
                    # video_streaminfo.update({"width": 720, "height": 576})
                    video_streaminfo.update({})

                ## Codec for Video Stream from extra info - page_items[i]['info']
                if 'hevc' in page_items[i]['label'].lower():
                    video_streaminfo.update({'codec': 'hevc'})
                elif '265' in page_items[i]['label'].lower():
                    video_streaminfo.update({'codec': 'h265'})
                elif 'mkv' in page_items[i]['label'].lower():
                    video_streaminfo.update({'codec': 'mkv'})
                elif 'mp4' in page_items[i]['label'].lower():
                    video_streaminfo.update({'codec': 'mp4'})
                else:
                    # video_streaminfo.update({'codec': 'h264'})
                    video_streaminfo.update({'codec': ''})

                ## Quality & Channels Audio Stream from extra info - page_items[i]['info']
                audio_streaminfo = {}
                if 'dts' in page_items[i]['label'].lower():
                    audio_streaminfo.update({'codec': 'dts'})
                elif 'plus' in page_items[i]['label'].lower() or 'e-ac3' in page_items[i]['label'].lower():
                    audio_streaminfo.update({'codec': 'eac3'})
                elif 'dolby' in page_items[i]['label'].lower() or 'ac3' in page_items[i]['label'].lower():
                    audio_streaminfo.update({'codec': 'ac3'})
                else:
                    # audio_streaminfo.update({'codec': 'aac'})
                    audio_streaminfo.update({'codec': ''})

                ## Channel update ##
                if '7.1' in page_items[i].get('info','').lower():
                    audio_streaminfo.update({'channels': 8})
                elif '5.1' in page_items[i].get('info','').lower():
                    audio_streaminfo.update({'channels': 6})
                else:
                    # audio_streaminfo.update({'channels': 2})
                    audio_streaminfo.update({'channels': ''})

                if int(getKodiVersion()) <= 19:
                    item.setInfo(type='Video', infoLabels=infolable)
                    item.addStreamInfo('video', video_streaminfo)
                    item.addStreamInfo('audio', audio_streaminfo)
                else:
                    info_tag = ListItemInfoTag(item, 'video')
                    info_tag.set_info(infolable)
                    stream_details = {
                        'video': [video_streaminfo],
                        'audio': [audio_streaminfo]}
                    info_tag.set_stream_details(stream_details)
                    # info_tag.set_cast(aActors)

                control.addItem(handle=syshandle, url=url, listitem=item, isFolder=False)
            except:
                pass

        if end < len(items):
            try:
                remaining = len(items) - end
                next_label = '[B]► Weitere Treffer laden[/B]  (%s verbleibend)' % remaining
                next_item = control.item(label=next_label, offscreen=True)
                next_item.setProperty('IsPlayable', 'false')
                next_item.setArt({'poster': addonPoster, 'banner': addonBanner})
                if settingFanart == 'true': next_item.setProperty('Fanart_Image', fanart)
                next_url = '%s?action=addItem&title=%s&page=%s&cacheid=%s' % (
                    sysaddon, systitle, page + 1, cache_id)
                control.addItem(handle=syshandle, url=next_url, listitem=next_item, isFolder=True)
            except Exception as e:
                log_utils.log('[PAGING] Weitere-Treffer-Eintrag Fehler: %s' % e, log_utils.LOGWARNING)

        control.content(syshandle, 'videos')
        control.plugincategory(syshandle, '%s | Seite %s' % (control.addonVersion, page + 1))
        control.endofdirectory(syshandle, cacheToDisc=False)


    def _sources_cache_dir(self):
        path = os.path.join(control.dataPath, 'source_pages')
        try:
            if not os.path.isdir(path):
                os.makedirs(path)
        except:
            pass
        return path

    def _cleanup_sources_cache(self, max_age=1800, max_files=1):
        path = self._sources_cache_dir()
        now = time.time()
        files = []
        try:
            for name in os.listdir(path):
                if not name.startswith('sources_') or not name.endswith('.json'):
                    continue
                full = os.path.join(path, name)
                try:
                    mtime = os.path.getmtime(full)
                    if now - mtime > max_age:
                        os.remove(full)
                    else:
                        files.append((mtime, full))
                except:
                    pass
            files.sort(reverse=True)
            for _, full in files[max_files:]:
                try: os.remove(full)
                except: pass
        except:
            pass

    def _write_sources_cache(self, items):
        self._cleanup_sources_cache()
        cache_id = uuid.uuid4().hex
        path = os.path.join(self._sources_cache_dir(), 'sources_%s.json' % cache_id)
        tmp = path + '.tmp'
        try:
            with open(tmp, 'w', encoding='utf-8') as fh:
                json.dump(items, fh, ensure_ascii=False, separators=(',', ':'))
            os.replace(tmp, path)
            log_utils.log('[PAGING] %s Treffer gespeichert: %s' % (len(items), path), log_utils.LOGWARNING)
            return cache_id
        except Exception as e:
            log_utils.log('[PAGING] Cache schreiben fehlgeschlagen: %s' % e, log_utils.LOGERROR)
            try:
                if os.path.exists(tmp): os.remove(tmp)
            except:
                pass
            control.window.setProperty(self.itemsProperty, json.dumps(items))
            return ''

    def _read_sources_cache(self, cache_id):
        if not cache_id:
            return None
        # Nur hexadezimale IDs zulassen, damit kein beliebiger Pfad gelesen werden kann.
        if not re.match(r'^[a-f0-9]{32}$', str(cache_id)):
            return None
        path = os.path.join(self._sources_cache_dir(), 'sources_%s.json' % cache_id)
        try:
            if time.time() - os.path.getmtime(path) > 1800:
                os.remove(path)
                return None
            with open(path, 'r', encoding='utf-8') as fh:
                data = json.load(fh)
            return data if isinstance(data, list) else None
        except:
            return None

    def playItem(self, title, source):
        isDebug = False
        if isDebug: log_utils.log('start playItem', log_utils.LOGWARNING)
        try:
            meta = control.window.getProperty(self.metaProperty)
            meta = json.loads(meta)

            header = control.addonInfo('name')
            # control.idle() #ok
            progressDialog = control.progressDialog if control.getSetting('progress.dialog') == '0' else control.progressDialogBG
            progressDialog.create(header, '')
            progressDialog.update(0)

            source_items = json.loads(source)
            item = source_items[0]
            #if isDebug: log_utils.log('playItem 237', log_utils.LOGWARNING)
            if item['source'] == None: raise Exception()

            # FILMO/Byse: der Browser-Test und die Diagnose haben gezeigt, dass
            # ResolveURL bis zur serverseitigen Attestation kommt, dort aber ohne
            # Browser-Interaktion hängen bleibt. Auf Fire TV/Cube und Desktop
            # überspringen wir Byse daher sofort und nehmen die erste mitgelieferte
            # normale Alternative. Kein CAPTCHA/PoW wird automatisiert oder umgangen.
            if (str(item.get('provider', '')).lower() == 'filmo' and
                    'byse' in str(item.get('source', '')).lower()):
                fallback = None
                for candidate in source_items[1:]:
                    if not isinstance(candidate, dict):
                        continue
                    if (str(candidate.get('provider', '')).lower() == 'filmo' and
                            'byse' in str(candidate.get('source', '')).lower()):
                        continue
                    if candidate.get('url'):
                        fallback = candidate
                        break
                if fallback is None:
                    try:
                        progressDialog.close()
                    except Exception:
                        pass
                    return
                # Erfolgreicher Auto-Fallback bleibt im Normalbetrieb still.
                item = fallback

            # Nur Serien verwenden den verzögerten MovieScout-ähnlichen Pfad:
            # genau den gewählten Provider erneut abfragen und höchstens drei
            # frische Kandidaten versuchen. Der Filmzweig darunter bleibt gleich.
            if item.get('isSeries') and item.get('_seriesRefresh'):
                self.url = self._resolveSeriesDeferred(item, progressDialog)
                try: progressDialog.close()
                except: pass
                control.execute('Dialog.Close(virtualkeyboard)')
                control.execute('Dialog.Close(yesnoDialog)')
                if self.url is None:
                    return
                from resources.lib.player import player
                player().run(title, self.url, meta)
                return self.url
            
            future = self.executor.submit(self.sourcesResolve, item)
            
            # Serien-Hosterlinks laufen häufiger ab. Auf einem Fire TV
            # soll ein defekter Link die Oberfläche deshalb nicht 30 Sekunden
            # blockieren. Filme behalten exakt das bisherige 30-Sekunden-Limit.
            waiting_time = 15 if item.get('isSeries') else 30
            resolve_timeout = waiting_time
            while waiting_time > 0:
                try:
                    if control.abortRequested: return sys.exit()
                    if progressDialog.iscanceled(): return progressDialog.close()
                except:
                    pass
                if future.done(): break
                control.sleep(1)
                waiting_time = waiting_time - 1
                progressDialog.update(int(100 - 100. / resolve_timeout * waiting_time), str(item['label']))
                #if isDebug: log_utils.log('playItem 252', log_utils.LOGWARNING)
                if control.condVisibility('Window.IsActive(virtualkeyboard)') or \
                        control.condVisibility('Window.IsActive(yesnoDialog)'):
                        # or control.condVisibility('Window.IsActive(PopupRecapInfoWindow)'):
                    waiting_time = waiting_time + 1  # dont count down while dialog is presented
                if future.done(): break

            try: progressDialog.close()
            except: pass
            if isDebug: log_utils.log('playItem 261', log_utils.LOGWARNING)
            control.execute('Dialog.Close(virtualkeyboard)')
            control.execute('Dialog.Close(yesnoDialog)')

            if isDebug: log_utils.log('playItem url: %s' % self.url, log_utils.LOGWARNING)
            if self.url == None:
                #self.errorForSources()
                return

            from resources.lib.player import player
            player().run(title, self.url, meta)
            return self.url
        except Exception as e:
            log_utils.log('Error %s' % str(e), log_utils.LOGERROR)


    def _resolveSeriesDeferred(self, original_item, progressDialog):
        """Fire-TV-schonende Serienauflösung ohne Änderung am Filmcode."""
        started = time.time()
        total_limit = 8.0
        refresh = original_item.get('_seriesRefresh') or {}
        provider = str(refresh.get('provider') or original_item.get('provider') or '')

        try:
            call = [entry[1] for entry in self.sourceDict if entry[0] == provider][0]
        except:
            log_utils.log('[SERIES-DEFERRED] Provider nicht gefunden: %s' % provider, log_utils.LOGERROR)
            return None

        titles = refresh.get('titles') or []
        originaltitle = refresh.get('originaltitle') or ''
        year = refresh.get('year')
        imdb = refresh.get('imdb')
        season = int(original_item.get('season') or 0)
        episode = int(original_item.get('episode') or 0)

        # Provider-Neuabfrage auf sechs Sekunden begrenzen. Es wird ausschließlich
        # der bereits ausgewählte Provider gestartet, niemals die komplette Suche.
        candidates = []
        try:
            progressDialog.update(5, 'Serienquelle wird aktualisiert')
            if provider == 'kinokiste':
                refresh_future = self.executor.submit(
                    call.run, titles, year, season, episode, imdb,
                    None, originaltitle
                )
            else:
                refresh_future = self.executor.submit(
                    call.run, titles, year, season, episode, imdb
                )
            fresh = refresh_future.result(timeout=6.0)
            if fresh:
                seen = set()
                for candidate in fresh:
                    if not isinstance(candidate, dict):
                        continue
                    candidate = dict(candidate)
                    candidate.update({
                        'provider': provider,
                        'isSeries': True,
                        'season': season,
                        'episode': episode,
                        '_seriesRefresh': refresh
                    })
                    candidate.setdefault('priority', 100)
                    candidate.setdefault('prioHoster', 100)
                    key = str(candidate.get('url') or '').strip()
                    if not key or key in seen:
                        continue
                    seen.add(key)
                    candidates.append(candidate)
        except FutureTimeoutError:
            try: refresh_future.cancel()
            except: pass
            log_utils.log('[SERIES-DEFERRED] Provider-Refresh Timeout: %s S%02dE%02d' % (
                provider, season, episode), log_utils.LOGWARNING)
        except Exception as exc:
            log_utils.log('[SERIES-DEFERRED] Provider-Refresh Fehler %s: %s' % (provider, exc), log_utils.LOGWARNING)

        # Den ursprünglich gewählten Hoster bevorzugen, danach Qualität und
        # Hosterpriorität. Der alte Link bleibt nur als letzter Fallback erhalten.
        old_host = str(original_item.get('source') or '').lower()
        quality_rank = {'4k': 0, '2160p': 0, '1440p': 1, '1080p': 2,
                        '720p': 3, 'hd': 3, '480p': 4, 'sd': 4,
                        'scr': 5, 'cam': 6, 'ts': 6}

        # Fire-TV-freundliche Hosterreihenfolge für Serien. Bekannte, meist
        # stabile Resolver kommen zuerst; CAPTCHA/Cloudflare-lastige Hoster
        # werden nur als letzter Fallback versucht.
        preferred_hosts = {
            'vidsonic': 0,
            'dropload': 1,
            'dr0pstream': 1,
            'dropstream': 1,
            'streamtape': 2,
            'voe': 3,
            'vidoza': 4,
            'dood': 5,
            'supervideo': 6,
            'upstream': 7,
            'filemoon': 90,
            'gupload': 91,
            'byse': 92,
        }

        def _host_rank(candidate):
            text = ('%s %s' % (candidate.get('source') or '', candidate.get('url') or '')).lower()
            for marker, rank in preferred_hosts.items():
                if marker in text:
                    return rank
            return 50

        def candidate_key(candidate):
            host = str(candidate.get('source') or '').lower()
            quality = str(candidate.get('quality') or '').lower()
            qrank = 99
            for marker, rank in quality_rank.items():
                if marker in quality:
                    qrank = rank
                    break
            return (_host_rank(candidate), 0 if host == old_host else 1,
                    qrank, candidate.get('prioHoster', 100))

        # Serienhoster, die in den aktuellen Logs wiederholt nur 404,
        # Cloudflare oder Timeouts liefern, gar nicht erst an ResolveURL geben.
        # Das spart auf dem Fire TV mehrere blockierende Resolver-Aufrufe.
        hard_skip_markers = ('byse', 'dood', 'firestream', 'voe')
        usable_candidates = []
        for candidate in candidates:
            host_text = ('%s %s' % (candidate.get('source') or '',
                                     candidate.get('url') or '')).lower()
            if any(marker in host_text for marker in hard_skip_markers):
                log_utils.log('[SERIES-DEFERRED] Hoster vor Resolver uebersprungen: %s' %
                              (candidate.get('source') or candidate.get('url')),
                              log_utils.LOGWARNING)
                continue
            usable_candidates.append(candidate)
        candidates = usable_candidates

        candidates.sort(key=candidate_key)
        old_url = str(original_item.get('url') or '').strip()
        if old_url and all(str(c.get('url') or '').strip() != old_url for c in candidates):
            candidates.append(original_item)
        candidates = candidates[:4]

        log_utils.log('[SERIES-DEFERRED] %s S%02dE%02d: %s Kandidaten, max. 4, Hoster-Prioritaet aktiv' % (
            provider, season, episode, len(candidates)), log_utils.LOGWARNING)

        # Nacheinander prüfen, damit der Fire TV Stick keine Resolver-Spitze bekommt.
        for index, candidate in enumerate(candidates):
            remaining = total_limit - (time.time() - started)
            if remaining <= 0.5:
                break
            per_candidate = min(2.25, remaining)
            try:
                progressDialog.update(35 + index * 20, 'Quelle %s von %s wird geprüft' % (
                    index + 1, len(candidates)))
                resolve_future = self.executor.submit(self._resolveSeriesCandidate, candidate)
                resolved = resolve_future.result(timeout=per_candidate)
                if resolved:
                    log_utils.log('[SERIES-DEFERRED] Wiedergabelink gefunden: %s / %s' % (
                        provider, candidate.get('source')), log_utils.LOGWARNING)
                    return resolved
            except FutureTimeoutError:
                try: resolve_future.cancel()
                except: pass
                log_utils.log('[SERIES-DEFERRED] Resolver Timeout: %s / %s' % (
                    provider, candidate.get('source')), log_utils.LOGWARNING)
            except Exception as exc:
                log_utils.log('[SERIES-DEFERRED] Kandidat fehlgeschlagen %s / %s: %s' % (
                    provider, candidate.get('source'), exc), log_utils.LOGWARNING)
        return None

    def _resolveSeriesCandidate(self, item):
        """Wie sourcesResolve, aber ohne gemeinsam genutztes self.url."""
        try:
            url = item['url']
            direct = item['direct']
            local = item.get('local', False)
            provider = item['provider']
            call = [entry[1] for entry in self.sourceDict if entry[0] == provider][0]
            url = call.resolve(url)

            if direct is not True:
                hmf = resolver.HostedMediaFile(url=url, include_disabled=True,
                                               include_universal=False, include_popups=False)
                if not hmf.valid_url():
                    hmf = resolver.HostedMediaFile(url=url, include_disabled=True,
                                                   include_universal=False, include_popups=True)
                if hmf.valid_url():
                    url = hmf.resolve()
                    if url in (False, None, ''):
                        url = None
            elif item.get('prioHoster', 0) >= 999:
                hmf = resolver.HostedMediaFile(url=url, include_disabled=True,
                                               include_universal=False, include_popups=True)
                if hmf.valid_url():
                    url = hmf.resolve()
                    if url in (False, None, ''):
                        url = None

            if url is None or ('://' not in str(url) and not local):
                return None
            return url
        except Exception as exc:
            try:
                log_utils.log('[SERIES-DEFERRED] Resolver uebersprungen: %s / %s' % (
                    item.get('source'), exc), log_utils.LOGWARNING)
            except:
                pass
            return None

    def getSources(self, title, year, imdb, season, episode, originaltitle, premiered, quality='HD', timeout=30):
#TODO
        # self._getHostDict()
        control.idle() #ok
        if getattr(self, '_series_next_autoplay', False):
            progressDialog = _SilentProgress()
        else:
            progressDialog = control.progressDialog if control.getSetting('progress.dialog') == '0' else control.progressDialogBG
            progressDialog.create(control.addonInfo('name'), '')
            progressDialog.update(0)
            progressDialog.update(0, "Quellen werden vorbereitet")

        sourceDict = self.sourceDict
        sourceDict = [(i[0], i[1], i[1].priority) for i in sourceDict]
        random.shuffle(sourceDict)
        sourceDict = sorted(sourceDict, key=lambda i: i[2])
        content = 'movies' if season == 0 or season == '' or season == None else 'shows'
        aliases, localtitle = utils.getAliases(imdb, content)
        if localtitle and title != localtitle and originaltitle != localtitle:
            if not title in aliases: aliases.append(title)
            title = localtitle
        for i in self.aliases:
            if not i in aliases:
                aliases.append(i)
        titles = utils.get_titles_for_search(title, originaltitle, aliases)

        search_started = time.time()
        with self.scraper_stats_lock:
            self.scraper_stats = {}
        # Auch deaktivierte und bereits beim Import gescheiterte Module aufführen.
        for load_stat in getattr(self, 'scraper_load_stats', []):
            state = load_stat.get('status')
            name = load_stat.get('provider', 'unknown')
            if state == 'DISABLED':
                self._record_scraper_stat(name, 'DISABLED', 0, 0, 'In den Add-on-Einstellungen deaktiviert oder Domain-Check fehlgeschlagen')
            elif state == 'LOAD_ERROR':
                self._record_scraper_stat(name, 'LOAD_ERROR', 0, 0, load_stat.get('error', 'Modul konnte nicht geladen werden'))

        # Beim automatischen Wechsel zur naechsten Serienepisode zuerst nur
        # SerienStream pruefen. Liefert der Provider Quellen, koennen wir sofort
        # in den Resolver/Autoplay-Schritt gehen und muessen nicht auf langsamere
        # Provider (Byse/Filemoon/Cloudflare usw.) warten. Erst wenn SerienStream
        # nichts liefert, startet wie bisher die Suche ueber die restlichen Provider.
        if getattr(self, '_series_next_autoplay', False):
            serienstream_provider = next((provider for provider in sourceDict
                                          if str(provider[0]).lower() == 'serienstream'), None)
            if serienstream_provider is not None:
                try:
                    ss_future = self.executor.submit(
                        self._getSource, titles, year, season, episode, imdb,
                        serienstream_provider[0], serienstream_provider[1], originaltitle
                    )
                    # Kurz warten: SerienStream war in den Tests schnell und VOE
                    # wurde dort erfolgreich aufgeloest. Timeout fuehrt sauber zum
                    # normalen Provider-Fallback.
                    ss_future.result(timeout=6.0)
                except FutureTimeoutError:
                    try: ss_future.cancel()
                    except: pass
                except Exception:
                    pass

                if self.sources:
                    self.sourcesFilter()
                    return self.sources

                sourceDict = [provider for provider in sourceDict
                              if str(provider[0]).lower() != 'serienstream']

        futures = {self.executor.submit(
            self._getSource, titles, year, season, episode, imdb,
            provider[0], provider[1], originaltitle
        ): provider[0] for provider in sourceDict}
        provider_names = {provider[0].upper() for provider in sourceDict}

        string4 = "Total"

        try: timeout = int(control.getSetting('scrapers.timeout'))
        except: pass
        
        quality = control.getSetting('hosts.quality')
        if quality == '': quality = '0'

        source_4k = 0
        source_1080 = 0
        source_720 = 0
        source_sd = 0
        total = d_total = 0
        total_format = '[COLOR %s][B]%s[/B][/COLOR]'
        pdiag_format = ' 4K: %s | 1080p: %s | 720p: %s | SD: %s | %s: %s                                         '.split('|')

        for i in range(0, 4 * timeout):
            try:
                if control.abortRequested: return sys.exit()
                try:
                    if progressDialog.iscanceled(): break
                except:
                    pass

                if len(self.sources) > 0:
                    if quality in ['0']:
                        source_4k = len([e for e in self.sources if e['quality'] == '4K'])
                        source_1080 = len([e for e in self.sources if e['quality'] in ['1440p','1080p']])
                        source_720 = len([e for e in self.sources if e['quality'] in ['720p','HD']])
                        source_sd = len([e for e in self.sources if e['quality'] not in ['4K','1440p','1080p','720p','HD']])
                    elif quality in ['1']:
                        source_1080 = len([e for e in self.sources if e['quality'] in ['1440p','1080p']])
                        source_720 = len([e for e in self.sources if e['quality'] in ['720p','HD']])
                        source_sd = len([e for e in self.sources if e['quality'] not in ['4K','1440p','1080p','720p','HD']])
                    elif quality in ['2']:
                        source_1080 = len([e for e in self.sources if e['quality'] in ['1080p']])
                        source_720 = len([e for e in self.sources if e['quality'] in ['720p','HD']])
                        source_sd = len([e for e in self.sources if e['quality'] not in ['4K','1440p','1080p','720p','HD']])
                    elif quality in ['3']:
                        source_720 = len([e for e in self.sources if e['quality'] in ['720p','HD']])
                        source_sd = len([e for e in self.sources if e['quality'] not in ['4K','1440p','1080p','720p','HD']])
                    else:
                        source_sd = len([e for e in self.sources if e['quality'] not in ['4K','1440p','1080p','720p','HD']])

                    total = source_4k + source_1080 + source_720 + source_sd

                source_4k_label = total_format % ('red', source_4k) if source_4k == 0 else total_format % ('lime', source_4k)
                source_1080_label = total_format % ('red', source_1080) if source_1080 == 0 else total_format % ('lime', source_1080)
                source_720_label = total_format % ('red', source_720) if source_720 == 0 else total_format % ('lime', source_720)
                source_sd_label = total_format % ('red', source_sd) if source_sd == 0 else total_format % ('lime', source_sd)
                source_total_label = total_format % ('red', total) if total == 0 else total_format % ('lime', total)

                try:
                    info = [name.upper() for future, name in futures.items() if not future.done()]

                    percent = int(100 * float(i) / (2 * timeout) + 1)

                    if quality in ['0']:
                        line1 = '|'.join(pdiag_format) % (source_4k_label, source_1080_label, source_720_label, source_sd_label, str(string4), source_total_label)
                    elif quality in ['1']:
                        line1 = '|'.join(pdiag_format[1:]) % (source_1080_label, source_720_label, source_sd_label, str(string4), source_total_label)
                    elif quality in ['2']:
                        line1 = '|'.join(pdiag_format[1:]) % (source_1080_label, source_720_label, source_sd_label, str(string4), source_total_label)
                    elif quality in ['3']:
                        line1 = '|'.join(pdiag_format[2:]) % (source_720_label, source_sd_label, str(string4), source_total_label)
                    else:
                        line1 = '|'.join(pdiag_format[3:]) % (source_sd_label, str(string4), source_total_label)

                    if (i / 2) < timeout:
                        string = "Verbleibende Indexseiten: %s"
                    else:
                        string = 'Waiting for: %s'

                    if len(info) > 6: line = line1 + string % (str(len(info)))
                    elif len(info) > 1: line = line1 + string % (', '.join(info))
                    elif len(info) == 1: line = line1 + string % (''.join(info))
                    else: line = line1 + 'Suche beendet!'

                    progressDialog.update(max(1, percent), line)
                    if len(info) == 0: break

                except Exception as e:
                    log_utils.log('Exception Raised: %s' % str(e), log_utils.LOGERROR)

                control.sleep(1)
            except:
                pass

        time.sleep(1)

        try: progressDialog.close()
        except: pass

        # Futures, die nach Ablauf des Zeitlimits noch laufen, sichtbar als TIMEOUT markieren.
        for future, provider_name in futures.items():
            if not future.done():
                self._record_scraper_stat(provider_name, 'TIMEOUT', 0, time.time() - search_started,
                                          'Zeitlimit von %ss überschritten' % timeout)

        self._write_scraper_report(title, year, season, episode, time.time() - search_started)
        self.sourcesFilter()
        return self.sources


    def _record_scraper_stat(self, provider, status, count, duration, error=''):
        stat = {
            'provider': str(provider),
            'status': str(status),
            'count': int(count or 0),
            'duration_seconds': round(float(duration or 0), 3),
            'error': str(error or '')[:1000],
            'timestamp': time.strftime('%Y-%m-%d %H:%M:%S')
        }
        with self.scraper_stats_lock:
            # Ein später TIMEOUT-Eintrag darf ein bereits abgeschlossenes Ergebnis nicht überschreiben.
            old = self.scraper_stats.get(str(provider))
            if old and status == 'TIMEOUT' and old.get('status') != 'RUNNING':
                return
            self.scraper_stats[str(provider)] = stat

    def _write_scraper_report(self, title, year, season, episode, total_duration):
        # Diagnose-Datei und Vollprotokoll wurden aus der Produktionsversion entfernt.
        return


    def _getSource(self, titles, year, season, episode, imdb, source, call, originaltitle=''):
        started = time.time()
        self._record_scraper_stat(source, 'RUNNING', 0, 0)
        try:
            if source == 'kinokiste' and season and episode:
                found_sources = call.run(
                    titles, year, season, episode, imdb,
                    originaltitle=originaltitle
                )
            else:
                found_sources = call.run(titles, year, season, episode, imdb)  # kasi self.hostDict
            if not found_sources:
                self._record_scraper_stat(source, 'EMPTY', 0, time.time() - started)
                return
            found_sources = [json.loads(t) for t in set(json.dumps(d, sort_keys=True) for d in found_sources)]
            for item in found_sources:
                item.update({'provider': source})
                if season and episode:
                    # Serienquellen speichern nur die kleinen Angaben, die zum
                    # frischen Nachladen beim Anklicken benötigt werden. Filme
                    # erhalten diese Felder nicht und bleiben vollständig unverändert.
                    item.update({
                        'isSeries': True,
                        'season': int(season),
                        'episode': int(episode),
                        '_seriesRefresh': {
                            'titles': [str(t) for t in titles[:5]],
                            'originaltitle': str(originaltitle or ''),
                            'year': year,
                            'imdb': imdb,
                            'provider': source
                        }
                    })
                if 'priority' not in item: item.update({'priority': 100})
                if 'prioHoster' not in item: item.update({'prioHoster': 100})
            self.sources.extend(found_sources)
            self._record_scraper_stat(source, 'OK', len(found_sources), time.time() - started)
        except Exception as e:
            error_text = '%s: %s' % (e.__class__.__name__, str(e))
            trace = traceback.format_exc(limit=5).strip()
            if trace and 'NoneType: None' not in trace:
                error_text += ' | ' + trace.replace('\n', ' <- ')
            self._record_scraper_stat(source, 'ERROR', 0, time.time() - started, error_text)


    def sourcesFilter(self):
        # hostblockDict = utils.getHostDict()
        # self.sources = [i for i in self.sources if i['source'].split('.')[0] not in str(hostblockDict)] # Hoster ausschließen (Liste)

        quality = control.getSetting('hosts.quality')
        if quality == '': quality = '0'

        random.shuffle(self.sources)

        self.sources = sorted(self.sources, key=lambda k: k['prioHoster'], reverse=False)

        # Qualitäts-Rangfolge für Sortierung (niedrigerer Wert = höhere Qualität)
        _QUALITY_RANK = {'4K': 0, '2160p': 0, '1440p': 1, '1080p': 2, '720p': 3, 'HD': 3, 'SD': 4, 'SCR': 5, 'CAM': 6}

        for i in range(len(self.sources)):
            q = self.sources[i]['quality']
            if q.lower() == 'hd': self.sources[i].update({'quality': '720p'})

        filter = []
        if quality in ['0']: filter += [i for i in self.sources if i['quality'] == '4K']
        if quality in ['0', '1']: filter += [i for i in self.sources if i['quality'] == '1440p']
        if quality in ['0', '1', '2']: filter += [i for i in self.sources if i['quality'] == '1080p']
        if quality in ['0', '1', '2', '3']: filter += [i for i in self.sources if i['quality'] == '720p']
        #filter += [i for i in self.sources if i['quality'] in ['SD', 'SCR', 'CAM']]
        filter += [i for i in self.sources if i['quality'] not in ['4K', '2160p', '1440p', '1080p', '720p']]
        self.sources = filter

        # Primär nach Qualität sortieren, sekundär prioHoster beibehalten
        self.sources = sorted(self.sources, key=lambda k: _QUALITY_RANK.get(k['quality'], 99))

        if control.getSetting('hosts.sort.provider') == 'true':
            self.sources = sorted(self.sources, key=lambda k: (_QUALITY_RANK.get(k['quality'], 99), k.get('prioHoster', 0) >= 999, k['provider']))

        if control.getSetting('hosts.sort.priority') == 'true' and self.mediatype == 'tvshow':
            self.sources = sorted(self.sources, key=lambda k: (_QUALITY_RANK.get(k['quality'], 99), k.get('prioHoster', 0) >= 999, k['priority']), reverse=False)

        # Fire-TV-optimierte Ergebnisverteilung. Jeder Scraper darf maximal
        # acht sichtbare Treffer beitragen; die vorhandene Hoster-Einstellung
        # bleibt davon unabhängig und wird nicht verändert.
        batch_per_scraper = 5
        max_per_scraper = 8
        max_total = 200

        # Nur Duplikate innerhalb desselben Scrapers entfernen.
        # Dieselbe Stream-URL darf bei unterschiedlichen Providern sichtbar bleiben,
        # damit jeder Scraper mit seinen Treffern in der Liste vertreten ist.
        unique_sources = []
        seen_provider_urls = set()
        for item in self.sources:
            url_key = str(item.get('url', '')).strip()
            provider_key = str(item.get('provider', 'unknown')).strip().lower()
            dedupe_key = (provider_key, url_key)
            if not url_key or dedupe_key in seen_provider_urls:
                continue
            seen_provider_urls.add(dedupe_key)
            unique_sources.append(item)

        # Faire Verteilung in 5er-Blöcken. Dies ändert ausschließlich die Reihenfolge;
        # kein Provider und kein Hoster wird dabei gekürzt.
        provider_order = []
        provider_items = {}
        for item in unique_sources:
            provider = item.get('provider', 'unknown')
            if provider not in provider_items:
                provider_order.append(provider)
                provider_items[provider] = []
            # Die Liste ist bereits nach Qualität/Hosterpriorität sortiert.
            # Daher bleiben pro Scraper die besten acht Treffer erhalten.
            if len(provider_items[provider]) < max_per_scraper:
                provider_items[provider].append(item)

        fair_sources = []
        offset = 0
        while len(fair_sources) < max_total:
            added = 0
            for provider in provider_order:
                chunk = provider_items[provider][offset:offset + batch_per_scraper]
                if chunk:
                    room = max_total - len(fair_sources)
                    selected = chunk[:room]
                    fair_sources.extend(selected)
                    added += len(selected)
                if len(fair_sources) >= max_total:
                    break
            if added == 0:
                break
            offset += batch_per_scraper

        # Nach dem fairen Begrenzen global nach Qualität absteigend sortieren.
        # Der ursprüngliche Fair-Merge-Index dient als stabiler Tie-Breaker, damit
        # innerhalb derselben Qualitätsstufe die Provider-Verteilung erhalten bleibt.
        _GLOBAL_QUALITY_RANK = {
            '4K': 0, '2160P': 0, 'UHD': 0,
            '1440P': 1,
            '1080P': 2, 'FHD': 2, 'FULL HD': 2, 'FULLHD': 2,
            '720P': 3, 'HD': 3,
            '480P': 4, 'SD': 4,
            'SCR': 5, 'SCREENER': 5,
            'CAM': 6, 'TS': 6, 'TELESYNC': 6
        }

        def _global_quality_rank(item):
            quality = str(item.get('quality') or '').strip().upper()
            info = str(item.get('info') or '').strip().upper()

            # Manche Scraper liefern Zusätze wie "1080P WEB-DL" statt eines
            # exakt passenden Qualitätswerts. Daher zuerst nach Markern suchen.
            for marker, rank in (
                ('2160P', 0), ('4K', 0), ('UHD', 0),
                ('1440P', 1),
                ('1080P', 2), ('FULL HD', 2), ('FULLHD', 2), ('FHD', 2),
                ('720P', 3),
                ('480P', 4),
                ('SCREENER', 5), ('SCR', 5),
                ('TELESYNC', 6), ('CAM', 6), ('TS', 6)
            ):
                if marker in quality:
                    return rank

            if quality == 'HD':
                return 3
            if quality == 'SD':
                return 4

            # CAM/TS kann bei einigen Quellen nur im Info-Feld stehen.
            if 'TELESYNC' in info or re.search(r'(^|\W)TS($|\W)', info):
                return 6
            if re.search(r'(^|\W)CAM($|\W)', info):
                return 6
            if 'SCREENER' in info or re.search(r'(^|\W)SCR($|\W)', info):
                return 5

            # Fehlende oder unbekannte Qualität immer ans Ende setzen.
            return 99

        def _series_hoster_rank(item):
            if not item.get('isSeries') and not (item.get('season') or item.get('episode')):
                return 0
            text = ('%s %s' % (item.get('source') or '', item.get('url') or '')).lower()
            order = (
                ('vidsonic', 0), ('dropload', 1), ('dr0pstream', 1),
                ('dropstream', 1), ('streamtape', 2), ('voe', 3),
                ('vidoza', 4), ('dood', 5), ('supervideo', 6),
                ('upstream', 7), ('filemoon', 90), ('gupload', 91), ('byse', 92)
            )
            for marker, rank in order:
                if marker in text:
                    return rank
            return 50

        indexed_fair_sources = list(enumerate(fair_sources))
        indexed_fair_sources.sort(key=lambda pair: (
            _global_quality_rank(pair[1]),
            str(pair[1].get('provider') or '').strip().lower(),
            _series_hoster_rank(pair[1]),
            pair[1].get('prioHoster', 100),
            pair[0]
        ))
        self.sources = [item for _, item in indexed_fair_sources]

        log_utils.log('[PAGING] Fair-Merge: %s Provider-Treffer, %s Provider, Batch=%s, Max/Provider=%s, Dedupe=Provider+URL, Sort=Qualitaet+Provider+Hoster' % (
            len(self.sources), len(provider_order), batch_per_scraper, max_per_scraper), log_utils.LOGWARNING)

        for i in range(len(self.sources)):
            p = self.sources[i]['provider']
            q = self.sources[i]['quality']
            s = self.sources[i]['source']
            ## s = s.rsplit('.', 1)[0]
            l = self.sources[i]['language']

            try:
                info_parts = []
                for info in self.sources[i]['info'].split('|'):
                    info = info.strip()
                    if not info or re.fullmatch(r'(?:19|20)\d{2}', info):
                        continue
                    info_parts.append('[I]%s [/I]' % info)
                f = ' | '.join(info_parts)
            except:
                f = ''

            if str(p).lower() == 'kinokiste':
                # Gleiches Feldformat wie bei den übrigen Providern:
                # PROVIDER | HOSTER | QUALITAET | DE.
                # Auch SD wird ausdrücklich angezeigt und nicht ausgeblendet.
                label = '%02d | [B]%s[/B] | %s' % (int(i + 1), p, s)
                if q:
                    label += ' | [B][I]%s [/I][/B]' % q
                if f:
                    label += ' | %s' % f
                label += ' | DE'
            else:
                label = '%02d | [B]%s[/B] | ' % (int(i + 1), p)
                if q in ['4K', '1440p', '1080p', '720p']: label += '%s | [B][I]%s [/I][/B] | %s' % (s, q, f)
                elif q == 'SD': label += '%s | %s' % (s, f)
                else: label += '%s | %s | [I]%s [/I]' % (s, f, q)
                label += ' | DE'

            label = label.replace('| 0 |', '|').replace(' | [I]0 [/I]', '')
            label = re.sub(r'\[I\]\s+\[/I\]', ' ', label)
            label = re.sub(r'\|\s+\|', '|', label)
            label = re.sub(r'\|(?:\s+|)$', '', label)

            if self.sources[i].get('prioHoster', 0) >= 999:
                label += ' | [COLOR red]CAPTCHA[/COLOR]'
            self.sources[i]['label'] = label.upper()

            # ## EMBY shown as premium link ##
            # if self.sources[i]['provider']=="emby" or self.sources[i]['provider']=="amazon" or self.sources[i]['provider']=="netflix" or self.sources[i]['provider']=="maxdome":
            #     prem_identify = 'blue'
            #     self.sources[i]['label'] = ('[COLOR %s]' % (prem_identify)) + label.upper() + '[/COLOR]'

        self.sources = [i for i in self.sources if 'label' in i]
        return self.sources


    def sourcesResolve(self, item, info=False):
        try:
            self.url = None
            url = item['url']
            direct = item['direct']
            local = item.get('local', False)
            provider = item['provider']
            call = [i[1] for i in self.sourceDict if i[0] == provider][0]
            url = call.resolve(url)

            if not direct == True:
                resolve_input = url
                is_filmo_byse = (provider == 'filmo' and 'byse' in str(item.get('source', '')).lower())
                try:
                    # Safety net: raw FILMO/Byse must never enter the known
                    # interactive attestation timeout. Normal fallback happens in playItem.
                    if is_filmo_byse:
                        url = None
                        raise Exception('Byse requires interactive browser attestation')
                    hmf = resolver.HostedMediaFile(url=url, include_disabled=True, include_universal=False, include_popups=False)
                    valid = hmf.valid_url()
                    if not valid:
                        hmf = resolver.HostedMediaFile(url=url, include_disabled=True, include_universal=False, include_popups=True)
                        valid = hmf.valid_url()
                    if valid:
                        url = hmf.resolve()
                        if url == False or url == None or url == '': url = None
                    else:
                        url = None
                except Exception:
                    url = None
            elif item.get('prioHoster', 0) >= 999:
                try:
                    hmf = resolver.HostedMediaFile(url=url, include_disabled=True, include_universal=False, include_popups=True)
                    if hmf.valid_url():
                        url = hmf.resolve()
                        if url == False or url == None or url == '': url = None
                except:
                    url = None

            if url == None or (not '://' in str(url) and not local):
                log_utils.log('Kein Video Link gefunden: Provider %s / %s / %s ' % (item['provider'], item['source'] , str(item['source'])), log_utils.LOGERROR)
                raise Exception()

            # if not utils.test_stream(url):
            #     log_utils.log('URL Test Error: %s' % url, log_utils.LOGERROR)
            #     raise Exception()

            # url = utils.m3u8_check(url)

            if url:
                self.url = url
                return url
            else:
                raise Exception()
        except:
            if info: self.errorForSources()
            return


    def sourcesDialog(self, items):
        labels = [i['label'] for i in items]

        select = control.selectDialog(labels)
        if select == -1: return 'close://'

        next = [y for x,y in enumerate(items) if x >= select]
        prev = [y for x,y in enumerate(items) if x < select][::-1]

        items = [items[select]]
        items = [i for i in items+next+prev][:40]

        header = control.addonInfo('name')
        header2 = header.upper()

        progressDialog = control.progressDialog if control.getSetting('progress.dialog') == '0' else control.progressDialogBG
        progressDialog.create(header, '')
        progressDialog.update(0)

        block = None

        try:
            for i in range(len(items)):
                try:
                    if items[i]['source'] == block: raise Exception()

                    future = self.executor.submit(self.sourcesResolve, items[i])

                    try:
                        if progressDialog.iscanceled(): break
                        progressDialog.update(int((100 / float(len(items))) * i), str(items[i]['label']))
                    except:
                        progressDialog.update(int((100 / float(len(items))) * i), str(header2) + str(items[i]['label']))

                    waiting_time = 30
                    while waiting_time > 0:
                        try:
                            if control.abortRequested: return sys.exit() #xbmc.Monitor().abortRequested()
                            if progressDialog.iscanceled(): return progressDialog.close()
                        except:
                            pass

                        if future.done(): break
                        control.sleep(1)

                        waiting_time = waiting_time - 1

                        if control.condVisibility('Window.IsActive(virtualkeyboard)') or \
                                control.condVisibility('Window.IsActive(yesnoDialog)') or \
                                control.condVisibility('Window.IsActive(ProgressDialog)'):
                            waiting_time = waiting_time + 1 #dont count down while dialog is presented ## control.condVisibility('Window.IsActive(PopupRecapInfoWindow)') or \

                    if not future.done(): block = items[i]['source']

                    if self.url == None: raise Exception()

                    self.selectedSource = items[i]['label']

                    try: progressDialog.close()
                    except: pass

                    control.execute('Dialog.Close(virtualkeyboard)')
                    control.execute('Dialog.Close(yesnoDialog)')
                    return self.url
                except:
                    pass

            try: progressDialog.close()
            except: pass

        except Exception as e:
            try: progressDialog.close()
            except: pass
            log_utils.log('Error %s' % str(e), log_utils.LOGINFO)


    def sourcesDirect(self, items):
        # TODO - OK
        # filter = [i for i in items if i['source'].lower() in self.hostcapDict and i['debrid'] == '']
        # items = [i for i in items if not i in filter]
        # items = [i for i in items if ('autoplay' in i and i['autoplay'] == True) or not 'autoplay' in i]

        u = None

        header = control.addonInfo('name')
        header2 = header.upper()

        try:
            control.sleep(1)

            if getattr(self, '_series_next_autoplay', False):
                progressDialog = _SilentProgress()
            else:
                progressDialog = control.progressDialog if control.getSetting('progress.dialog') == '0' else control.progressDialogBG
                progressDialog.create(header, '')
                progressDialog.update(0)
        except:
            progressDialog = _SilentProgress()

        if getattr(self, '_series_next_autoplay', False):
            # Sicherheitsnetz fuer bereits gemischte Trefferlisten: beim
            # Folgewechsel SerienStream immer vor allen anderen Providern testen.
            items = sorted(items, key=lambda item: (
                0 if str(item.get('provider') or '').lower() == 'serienstream' else 1
            ))

        for i in range(len(items)):
            try:
                if progressDialog.iscanceled(): break
                progressDialog.update(int((100 / float(len(items))) * i), str(items[i]['label']))
            except:
                progressDialog.update(int((100 / float(len(items))) * i), str(header2) + str(items[i]['label']))

            try:
                if control.abortRequested: return sys.exit()

                # Autoplay must not hand a recognised hoster/embed page directly
                # to Kodi. Some scrapers mark such links as direct even though
                # ResolveURL still has to turn them into a media URL. For autoplay
                # only, force that resolver step; on failure continue with the
                # next candidate instead of starting an unplayable page (e.g. 403).
                candidate = dict(items[i])
                try:
                    if candidate.get('direct') is True:
                        probe_url = str(candidate.get('url') or '')
                        probe = resolver.HostedMediaFile(url=probe_url, include_disabled=True,
                                                        include_universal=False, include_popups=True)
                        if probe.valid_url():
                            # A resolver-known hoster is not a real direct media URL.
                            # Force sourcesResolve() through ResolveURL.
                            candidate['direct'] = False
                        else:
                            # VAVOO currently returns some Dood/Playmogo embed pages as
                            # direct links after its own resolver attempt failed. Kodi then
                            # receives the HTML page and dies with HTTP 403. In autoplay we
                            # must skip those candidates and continue with the next source.
                            low_url = probe_url.lower()
                            low_src = str(candidate.get('source') or '').lower()
                            if ('playmogo.' in low_url or 'doodstream' in low_src or
                                    'dood.' in low_url or 'doodstream.' in low_url):
                                continue
                except Exception:
                    pass

                url = self.sourcesResolve(candidate)
                if u == None: u = url
                if not url == None: break
            except:
                pass

        try: progressDialog.close()
        except: pass

        return u

    def mediaInfo(self, source, dialog=None):
        import xbmcgui
        try:
            import urllib3
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        except: pass
        try:
            item = json.loads(source)[0]
            if item['source'] is None:
                raise Exception()

            import time as _time
            from resources.lib.mediainfo import TOTAL_TIMEOUT
            deadline = _time.time() + TOTAL_TIMEOUT

            if dialog is None:
                dialog = xbmcgui.DialogProgress()
                dialog.create('Medien-Info', 'Löse Stream-URL auf...')
                dialog.update(0)

            future = self.executor.submit(self.sourcesResolve, item)

            # Wait for resolve with responsive cancel (check every 250ms)
            # Cap at deadline so resolve + probe share the TOTAL_TIMEOUT budget
            for i in range(120):  # 120 * 250ms = 30s max
                remaining = int(deadline - _time.time())
                if remaining <= 0:
                    break
                dialog.update(int(50.0 * i / 120), 'Löse Stream-URL auf...')
                try:
                    if dialog.iscanceled():
                        try: dialog.close()
                        except: pass
                        return
                except: pass
                if future.done():
                    break
                control.sleep(0.25)  # 250ms — control.sleep() takes seconds, not ms
                # Don't count down while resolver shows interactive dialogs
                if control.condVisibility('Window.IsActive(virtualkeyboard)') or \
                        control.condVisibility('Window.IsActive(yesnoDialog)'):
                    continue

            url = self.url if future.done() else None
            control.execute('Dialog.Close(virtualkeyboard)')
            control.execute('Dialog.Close(yesnoDialog)')

            try:
                if dialog.iscanceled():
                    try: dialog.close()
                    except: pass
                    return
            except: pass

            if url is None:
                try: dialog.close()
                except: pass
                control.infoDialog("Stream-URL konnte nicht aufgelöst werden", sound=False, icon='INFO')
                return

            log_utils.log('mediaInfo: resolve done, url=%s deadline_remaining=%.1f' % (url[:80], deadline - _time.time()), log_utils.LOGWARNING)
            dialog.update(50, 'Analysiere Stream...')

            from resources.lib import mediainfo
            t_probe = _time.time()
            info = mediainfo.getMediaInfo(url, dialog, deadline)
            log_utils.log('mediaInfo: probe done in %.1fs, got_info=%s' % (_time.time() - t_probe, bool(info)), log_utils.LOGWARNING)

            try: dialog.close()
            except: pass

            if info:
                xbmcgui.Dialog().textviewer('Medien-Info', info)
            else:
                control.infoDialog("Auflösung konnte nicht ermittelt werden", sound=False, icon='INFO')

        except Exception as e:
            try:
                if dialog: dialog.close()
            except: pass
            log_utils.log('mediaInfo Error: %s' % str(e), log_utils.LOGERROR)
            control.infoDialog("Auflösung konnte nicht ermittelt werden", sound=False, icon='INFO')


    def errorForSources(self):
        control.infoDialog("Keine Streams verfügbar oder ausgewählt", sound=False, icon='INFO')

    def getTitle(self, title):
        title = utils.normalize(title)
        return title

    def getConstants(self):
        self.itemsProperty = '%s.container.items' % control.Addon.getAddonInfo('id')
        self.metaProperty = '%s.container.meta'  % control.Addon.getAddonInfo('id')
        import scrapers as scraper_loader
        self.sourceDict = scraper_loader.sources()
        self.scraper_load_stats = scraper_loader.getLoadDiagnostics()
