

#2021-07-15
# edit 2025-08-02 switch from treads to concurrent.futures 

import sys, os, datetime
import json
from resources.lib.requestHandler import cRequestHandler
from resources.lib import control

_params = dict(control.parse_qsl(sys.argv[2].replace('?', ''))) if len(sys.argv) > 1 else dict()

#TV-Film
# {"genres":[{"id":10759,"name":"Action & Adventure"},{"id":16,"name":"Animation"},{"id":35,"name":"Komödie"},{"id":80,"name":"Krimi"},{"id":99,"name":"Dokumentarfilm"},{"id":18,"name":"Drama"},{"id":10751,"name":"Familie"},{"id":10762,"name":"Kids"},{"id":9648,"name":"Mystery"},{"id":10763,"name":"News"},{"id":10764,"name":"Reality"},{"id":10765,"name":"Sci-Fi & Fantasy"},{"id":10766,"name":"Soap"},{"id":10767,"name":"Talk"},{"id":10768,"name":"War & Politics"},{"id":37,"name":"Western"}]}

_genresTv = [{"id":10759,"name":"Action & Abenteuer"},{"id":16,"name":"Animation"},{"id":35,"name":"Komödie"},{"id":80,"name":"Krimi"},{"id":18,"name":"Drama"},{"id":10751,"name":"Familie"},
			 {"id":10762,"name":"Kids"},{"id":9648,"name":"Mystery"},{"id":10764,"name":"Reality"},{"id":10765,"name":"Sci-Fi & Fantasy"},{"id":10768,"name":"War & Politics"},
			 {"id":37,"name":"Western"}]

_genresMovie = [{"id":28,"name":"Action"},{"id":12,"name":"Abenteuer"},{"id":16,"name":"Animation"},{"id":35,"name":"Komödie"},{"id":80,"name":"Krimi"},{"id":18,"name":"Drama"},
				{"id":10751,"name":"Familie"},{"id":14,"name":"Fantasy"},{"id":36,"name":"Historie"},{"id":27,"name":"Horror"},{"id":10402,"name":"Musik"},{"id":9648,"name":"Mystery"},
				{"id":10749,"name":"Liebesfilm"},{"id":878,"name":"Science Fiction"},{"id":10770,"name":"TV-Film"},{"id":53,"name":"Thriller"},{"id":10752,"name":"Kriegsfilm"},{"id":37,"name":"Western"}]

class listings:
	def __init__(self):
		self.URL = 'https://api.themoviedb.org/3/discover'
		self.api_key = '86dd18b04874d9c94afadde7993d94e3'
		self.lang = 'de'
		self.list = []
		self.total_pages = 0
		self.query = ''
		self.media_type = ''
		#self.year_params = 'release_date.gte=%s-01-01&release_date.lte=%s-12-31&with_release_type=2|3&without_genres=%s&sort_by=popularity.desc'
		#self.year_params = 'primary_release_year=%s&with_release_type=2|3&without_genres=%s&sort_by=vote_count.desc' #&sort_by= vote_average.desc / popularity.desc / vote_count
		self.genres_params = ''
		self.popular_link = ''
		self.datetime = datetime.datetime.utcnow()

	def get(self, params):
		try:
			if params.get('next_pages'):
				next_pages = int(params.get('next_pages'))
			else:
				next_pages = 1

			append_to_response = 'page=%s' % next_pages
			self.media_type = params.get('media_type')
			url = params.get('url')
			if url == 'tv_new':
				# Neue Serien direkt über TMDb Discover laden. Dieser Pfad ist bewusst
				# unabhängig vom alten/defekten tvNetworks-Menüpunkt.
				from datetime import datetime, timedelta
				today = datetime.today()
				fromday = today - timedelta(days=120)
				url = ('first_air_date.gte=%s&first_air_date.lte=%s&'
				       'sort_by=first_air_date.desc&vote_count.gte=3&'
				       'without_genres=99,10763,10767,10766') % (
				           fromday.strftime('%Y-%m-%d'), today.strftime('%Y-%m-%d'))

			if url == 'kino':
				from datetime import datetime, timedelta
				today = datetime.today() - timedelta(days=21)
				fromday = datetime.today() - timedelta(days=90)
				_today = today.strftime('%Y-%m-%d')
				_fromday = fromday.strftime('%Y-%m-%d')
				url = 'primary_release_date.gte=%s&primary_release_date.lte=%s' % (_fromday, _today)

			if url == 'tmdb_trending':
				try:
					current_page = int(params.get('next_pages') or 1)
					tmdb_url = (
						'https://api.themoviedb.org/3/trending/movie/week'
						'?api_key=%s&language=de-DE&page=%s'
						% (self.api_key, current_page)
					)
					oRequestHandler = cRequestHandler(tmdb_url, ignoreErrors=True)
					response = oRequestHandler.request()
					data = __import__('json').loads(response)

					tmdb_ids = [
						int(item['id'])
						for item in data.get('results', [])
						if item.get('id')
					]
					total_pages = min(int(data.get('total_pages') or 1), 20)

					if tmdb_ids:
						params.update({
							'list': tmdb_ids,
							'media_type': 'movie',
							'next_pages': current_page,
							'total_pages': total_pages
						})
						from resources.lib.indexers import movies
						movies.movies().getDirectory(params)
					return self.list
				except Exception as e:
					from resources.lib.tools import logger
					logger.error('[listings] tmdb_trending Fehler: ' + str(e))
					return self.list

			if url == 'trakt_trending':
				try:
					import json, requests
					PAGE_SIZE    = 15
					MAX_PAGES    = 5
					current_page = int(params.get('next_pages') or 1)
					V2_API_KEY = 'be7210b254bac9245b335ff8febecc3bb98038b3f5ff731db27f4c1851ec6614'
					headers = {'Content-Type': 'application/json', 'trakt-api-key': V2_API_KEY, 'trakt-api-version': '2'}
					r = requests.get('https://api.trakt.tv/movies/trending?limit=%s&extended=full' % (PAGE_SIZE * MAX_PAGES), headers=headers)
					if r.status_code != 200: return self.list
					data = json.loads(r.content)
					all_ids = []
					for item in data:
						movie = item.get('movie', {})
						ids = movie.get('ids', {})
						tmdb_id = ids.get('tmdb')
						if tmdb_id: all_ids.append(int(tmdb_id))
					# Aktuelle Seite ausschneiden
					start    = (current_page - 1) * PAGE_SIZE
					tmdb_ids = all_ids[start:start + PAGE_SIZE]
					if tmdb_ids:
						self.media_type = 'movie'
						params.update({'list': tmdb_ids, 'media_type': 'movie', 'next_pages': current_page, 'total_pages': MAX_PAGES})
						from resources.lib.indexers import movies
						# Subklasse um Trakt-Reihenfolge nach worker() zu erhalten
						order = {int(tid): idx for idx, tid in enumerate(tmdb_ids)}
						class TraktMovies(movies.movies):
							def worker(self_inner):
								super().worker()
								# meta hat tmdb_id noch — nach Trakt-Reihenfolge sortieren
								self_inner.meta.sort(key=lambda x: order.get(int(x.get('tmdb_id') or 0), 9999))
								self_inner.list = self_inner.meta
						mov = TraktMovies()
						mov.getDirectory(params)
						return self.list
				except Exception as e:
					from resources.lib.tools import logger
					logger.error('[listings] trakt_trending Fehler: ' + str(e))
					return self.list

			if url == 'im_kino':
				from datetime import datetime, timedelta
				today = datetime.today()
				fromday = datetime.today() - timedelta(days=60)
				_today = today.strftime('%Y-%m-%d')
				_fromday = fromday.strftime('%Y-%m-%d')
				url = 'primary_release_date.gte=%s&primary_release_date.lte=%s&with_release_type=3&sort_by=popularity.desc' % (_fromday, _today)

			list, total_pages = self._call(url, append_to_response=append_to_response)
			params.update({'list': list})
			params.update({'next_pages': next_pages})
			params.update({'total_pages': total_pages})
			params.update({'media_type': self.media_type})
			if self.media_type == 'movie':
				from resources.lib.indexers import movies
				movies.movies().getDirectory(params)
			else:
				from resources.lib.indexers import tvshows
				tvshows.tvshows().getDirectory(params)
			return self.list
		except:
			pass

	def movieYears(self):
		year = (self.datetime.strftime('%Y'))
		without = '99,10762,10767,10766,16' # doku, kids, Talk, Soap, Animation
		for i in range(int(year), 1960, -1):
			self.list.append({'name': str(i), 'url': 'primary_release_year=%s&with_release_type=2|3&without_genres=%s&sort_by=vote_count.desc' % (str(i), without), 'image': 'years.png', 'action': 'listings'})
		self.media_type = 'movie'
		self.addDirectory(self.list)
		return self.list

	def movieGenres(self):
		without = '99,16'
		self.media_type = 'movie'
		for i in _genresMovie:
			if i['id'] == 16: without = '99'
			self.list.append({'name': i['name'], 'url': 'with_genres=%s&without_genres=%s&sort_by=vote_count.desc' % (str(i['id']), without), 'image': 'genres.png', 'action': 'listings'})
		self.addDirectory(self.list)
		return self.list

	def tvGenres(self):
		without = '99,10762,10767,10766,16' # doku, kids, Talk, Soap, Animation
		self.media_type = 'tv'
		for i in _genresTv:
			if i['id'] == 16 or i['id'] == 10762: without = '99,10767,10766'
			self.list.append({'name': i['name'], 'url': 'with_genres=%s&without_genres=%s&sort_by=vote_count.desc' % (str(i['id']), without), 'image': 'genres.png', 'action': 'listings'})
		self.addDirectory(self.list)
		return self.list

	def tvYears(self):
		year = (self.datetime.strftime('%Y'))
		without = '99,10762,10767,10766,16' # doku, kids, Talk, Soap, Animation
		for i in range(int(year), 1960, -1):
			self.list.append({'name': str(i), 'url': 'first_air_date_year=%s&without_genres=%s&sort_by=vote_count.desc' % (str(i), without), 'image': 'years.png', 'action': 'listings'})
		self.media_type = 'tv'
		self.addDirectory(self.list)
		return self.list



	def streambarProviders(self, params):
		"""TMDb-Anbieterliste für Deutschland, getrennt nach Film und Serie."""
		try:
			media_type = params.get('media_type') or 'movie'
			if media_type not in ('movie', 'tv'):
				media_type = 'movie'
			self.media_type = media_type

			endpoint = 'https://api.themoviedb.org/3/watch/providers/%s?api_key=%s&language=de-DE&watch_region=DE' % (media_type, self.api_key)
			raw = cRequestHandler(endpoint, ignoreErrors=True).request()
			data = json.loads(raw or '{}')
			providers = data.get('results') or []

			# TMDb kann einzelne Anbieter mehrfach oder ohne brauchbare Angaben liefern.
			# Nur kleine Metadaten werden gehalten; Logos lädt Kodi bei Bedarf.
			unique = {}
			for provider in providers:
				try:
					provider_id = int(provider.get('provider_id'))
				except (TypeError, ValueError):
					continue
				name = str(provider.get('provider_name') or '').strip()
				if not name:
					continue
				priority = provider.get('display_priority')
				try:
					priority = int(priority)
				except (TypeError, ValueError):
					priority = 9999
				current = unique.get(provider_id)
				if current is None or priority < current['priority']:
					unique[provider_id] = {
						'id': provider_id,
						'name': name,
						'priority': priority,
						'logo': str(provider.get('logo_path') or '')
					}

			providers = sorted(unique.values(), key=lambda x: (x['priority'], x['name'].lower()))
			if not providers:
				control.infoDialog('Keine TMDb-Anbieter für Deutschland gefunden', icon='WARNING', time=3500)
				control.endofdirectory(int(sys.argv[1]), succeeded=True, cacheToDisc=False)
				return []

			sysaddon = sys.argv[0]
			syshandle = int(sys.argv[1])
			fanart = control.addonFanart()
			fallback = os.path.join(control.artPath(), 'tmdb_search.png')

			for provider in providers:
				provider_id = provider['id']
				name = provider['name']
				logo = provider['logo']
				thumb = ('https://image.tmdb.org/t/p/w185%s' % logo) if logo else fallback
				# flatrate = Abo, free = kostenlos, ads = werbefinanziert.
				query = 'watch_region=DE&with_watch_providers=%s&with_watch_monetization_types=flatrate|free|ads&sort_by=popularity.desc' % provider_id
				url = '%s?action=listings&media_type=%s&url=%s' % (sysaddon, media_type, control.quote_plus(query))
				item = control.item(label=name, offscreen=True)
				item.setArt({'thumb': thumb, 'poster': thumb, 'icon': thumb})
				if fanart:
					item.setProperty('Fanart_Image', fanart)
				kind = 'Filme' if media_type == 'movie' else 'Serien'
				item.setInfo('video', {'overlay': 4, 'plot': '%s bei %s laut TMDb (Region Deutschland)' % (kind, name)})
				item.setIsFolder(True)
				control.addItem(handle=syshandle, url=url, listitem=item, isFolder=True)

			control.content(syshandle, 'videos')
			control.plugincategory(syshandle, 'Streambar / ' + control.addonVersion)
			control.endofdirectory(syshandle, succeeded=True, cacheToDisc=True)
			return providers
		except Exception:
			control.infoDialog('Streambar konnte nicht geladen werden', icon='WARNING', time=3500)
			try:
				control.endofdirectory(int(sys.argv[1]), succeeded=True, cacheToDisc=False)
			except Exception:
				pass
			return []

	def _call(self, url, append_to_response=''):
		vote_filter = '' if 'vote_count.gte=' in url else 'vote_count.gte=20&'
		url = '%s/%s?api_key=%s&language=de-DE&region=DE&%sinclude_adult=false&include_video=false&%s' % (self.URL, self.media_type, self.api_key, vote_filter, url)
		if not 'without_genres' in url: url += '&without_genres=99' # doku
		if append_to_response:
			url += '&%s' % append_to_response
		oRequestHandler = cRequestHandler(url, ignoreErrors=True)
		name = oRequestHandler.request()
		data = json.loads(name)
		if 'status_code' in data and data['status_code'] == 34:
			return [], 0
		list = []
		for i in data['results']:
			list.append(i['id'])

		return list, data['total_pages']


	def addDirectory(self, items):
		if items is None or len(items) == 0:
			control.idle()
			sys.exit()
		sysaddon = sys.argv[0]
		syshandle = int(sys.argv[1])
		addonPoster, addonFanart, addonThumb, artPath = control.addonFanart(), control.addonFanart(), control.addonThumb(), control.artPath()

		for i in items:
			try:
				name = i['name']
				if self.media_type == 'movie':
					if 'primary_release_year' in i['url']:
						plot = 'Filme aus dem Jahr:  %s' % name
					else:
						plot = 'Filme aus der Kategorie:  %s' % name
				else:
					plot = 'Serien aus der Kategorie:  %s' % name

				try:
					poster = os.path.join(artPath, i['image'])
					thumb = os.path.join(artPath, i['image'])
				except:
					thumb = addonThumb
					poster = addonPoster

				url = '%s?action=%s' % (sysaddon, i['action'])
				url += '&media_type=%s' % self.media_type
				try:
					url += '&url=%s' % control.quote_plus(i['url'])
				except:
					pass

				item = control.item(label=name, offscreen=True)
				# item.setArt({'icon': thumb, 'thumb': thumb})
				item.setArt({'thumb': thumb, 'poster': poster})
				if not addonFanart is None: item.setProperty('Fanart_Image', addonFanart)

				#  -> gesehen/ungesehen im cm und "Keine Informationen verfügbar" ausblenden (abhängig vom Skin)
				item.setInfo('video', {'overlay': 4, 'plot': plot})
				item.setIsFolder(True)

				control.addItem(handle=syshandle, url=url, listitem=item, isFolder=True)
			except:
				pass

		control.content(syshandle, 'videos')
		control.plugincategory(syshandle, control.addonVersion)
		control.endofdirectory(syshandle, cacheToDisc=True)

