

#2021-11-22
#edit 2025-03-02

import sys, re, json
from urllib.parse import parse_qsl, urlencode, urlsplit
import hashlib,os,codecs
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from sqlite3 import dbapi2 as database
import xbmc, xbmcplugin, xbmcgui
from resources.lib.control import py2_encode, translatePath, executebuiltin
from resources.lib import log_utils, control, playcountDB

try:
    import xmlrpclib as _xmlrpclib
    from StringIO import StringIO as _io
except:
    import xmlrpc.client as _xmlrpclib
    from io import BytesIO as _io



class _IncVideoProxyHandler(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'

    def log_message(self, fmt, *args):
        return

    def do_HEAD(self):
        self._relay(head_only=True)

    def do_GET(self):
        self._relay(head_only=False)

    def _relay(self, head_only=False):
        import requests
        upstream = self.server.upstream_url
        headers = dict(self.server.upstream_headers)
        range_header = self.headers.get('Range')
        if range_header:
            headers['Range'] = range_header
        headers['Connection'] = 'close'
        try:
            response = requests.request('HEAD' if head_only else 'GET', upstream, headers=headers,
                                        stream=not head_only, allow_redirects=True, timeout=(5, 15))
            self.send_response(response.status_code)
            for key in ('Content-Type', 'Content-Length', 'Content-Range', 'Accept-Ranges',
                        'Last-Modified', 'ETag'):
                value = response.headers.get(key)
                if value:
                    self.send_header(key, value)
            self.send_header('Connection', 'close')
            self.end_headers()
            if not head_only:
                for chunk in response.iter_content(chunk_size=128 * 1024):
                    if not chunk:
                        continue
                    try:
                        self.wfile.write(chunk)
                    except (BrokenPipeError, ConnectionResetError, OSError):
                        break
        except Exception as exc:
            try:
                self.send_error(502, 'upstream error')
            except Exception:
                pass
        finally:
            try:
                response.close()
            except Exception:
                pass
            self.close_connection = True


def _start_incvideo_proxy(kodi_url):
    """Put incvideo behind a local HTTP relay so Kodi Stop only closes localhost."""
    stream_url = kodi_url
    raw_headers = ''
    if '|' in kodi_url:
        stream_url, raw_headers = kodi_url.split('|', 1)
    if 'incvideo' not in stream_url.lower():
        return kodi_url, None
    headers = dict(parse_qsl(raw_headers, keep_blank_values=True)) if raw_headers else {}
    # These are transport hints for Kodi, not required by the upstream server.
    headers.pop('Connection', None)
    headers.pop('Accept-Encoding', None)
    server = ThreadingHTTPServer(('127.0.0.1', 0), _IncVideoProxyHandler)
    server.daemon_threads = True
    server.upstream_url = stream_url
    server.upstream_headers = headers
    thread = threading.Thread(target=server.serve_forever, name='xShipIncVideoProxy')
    thread.daemon = True
    thread.start()
    return 'http://127.0.0.1:%d/stream.mp4' % server.server_address[1], server

# eventuell zur spÃ¤teren verwendung als meta
#_params = dict(parse_qsl(sys.argv[2].replace('?',''))) if len(sys.argv) > 1 else dict()

class player(xbmc.Player):
    def __init__(self, *args, **kwargs):
        xbmc.Player.__init__(self, *args, **kwargs)
        self.streamFinished = False
        self.totalTime = 0
        self.currentTime = 0
        self.playcount = 0
        self.watcher_control = False
        self.isdebug = True if control.getSetting('status.debug') == 'true' else False
        self._next_episode_after_playback = False


    def run(self, title, url, meta):
        import xbmc
        try:
            self.meta = meta
            self._next_episode_after_playback = False
            self.mediatype = meta['mediatype']
            self.title = meta['title']
            self.year = str(meta['year']) if 'year' in meta else ''
            if meta['mediatype'] == 'movie':
                self.name = title + ' (%s)' % meta['year'] if meta.get('year', False) else title
            else:
                self.name = title + ' S%02dE%02d' % (int(meta['season']), int(meta['episode']))

            if control.is_python2 and type(self.name) != unicode:
                self.name = self.name.decode('utf-8')
            self.imdb = meta['imdb_id'] if 'imdb_id' in meta else None
            self.number_of_seasons = meta['number_of_seasons'] if 'number_of_seasons' in meta else None
            self.season = meta['season'] if 'season' in meta else None
            self.number_of_episodes = meta['number_of_episodes'] if 'number_of_episodes' in meta else None
            self.episode = meta['episode'] if 'episode' in meta else None

            self.playcount = meta['playcount'] if 'playcount' in meta else 0
            self.offset = bookmarks().get(self.name, self.year)

            from glob import glob
            os.chdir(os.path.join(control.translatePath('special://database/')))
            self.videoDB = os.path.join(control.translatePath('special://database/'), sorted(glob("MyVideos*.db"), reverse=True)[0])

            self.fileID = self.getVideoDB()

            plot = control.unquote(meta['plot']) if 'plot' in meta else ''

            Info = {'plot': plot}
            Info.setdefault('IMDBNumber', meta['imdbnumber'])
            if meta['mediatype'] == 'movie':
                Info.setdefault('OriginalTitle', meta['title'])
                Info.setdefault('year', meta['year'])
            else:
                Info.setdefault('TVshowtitle', meta['title'])
                Info.setdefault('Season', self.season)
                Info.setdefault('Episode', self.episode)

            item = control.item(label=self.name)

            # TS: video/mp2t
            # HLS: application/x-mpegURL oder application/vnd.apple.mpegurl
            # DASH: application/dash+xml
            #
            # Serien-HLS ist oft durch Referer/Origin und kurzlebige Tokens geschützt.
            # Auf Fire-TV-Geräten verwenden wir inputstream.adaptive nur, wenn es
            # wirklich installiert ist. Sonst bleibt die Kodi-native URL|Header-
            # Wiedergabe erhalten, damit keine harte Abhängigkeit entsteht.
            kodiver = int(xbmc.getInfoLabel("System.BuildVersion").split(".")[0])
            is_manifest = ".m3u" in url or '.mpd' in url
            if is_manifest:
                is_series = self.mediatype != 'movie'
                stream_url = url
                raw_headers = ''
                if '|' in url:
                    stream_url, raw_headers = url.split('|', 1)

                # Vorhandene Header erhalten und nur bei Serien sinnvoll ergänzen.
                header_pairs = dict(parse_qsl(raw_headers, keep_blank_values=True)) if raw_headers else {}
                if is_series:
                    header_pairs.setdefault('User-Agent', 'Mozilla/5.0 (Linux; Android 9; AFTMM Build/PS7624.3337N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36')
                    header_pairs.setdefault('Accept', '*/*')
                    header_pairs.setdefault('Accept-Language', 'de-DE,de;q=0.9,en;q=0.8')
                    header_pairs.setdefault('Connection', 'keep-alive')
                    header_pairs.setdefault('Sec-Fetch-Dest', 'empty')
                    header_pairs.setdefault('Sec-Fetch-Mode', 'cors')
                    header_pairs.setdefault('Sec-Fetch-Site', 'cross-site')

                    referer = header_pairs.get('Referer') or header_pairs.get('referer') or ''
                    if referer and not header_pairs.get('Origin'):
                        try:
                            parts = urlsplit(referer)
                            if parts.scheme and parts.netloc:
                                header_pairs['Origin'] = '%s://%s' % (parts.scheme, parts.netloc)
                        except Exception:
                            pass

                encoded_headers = urlencode(header_pairs) if header_pairs else ''
                has_isa = xbmc.getCondVisibility('System.HasAddon(inputstream.adaptive)')

                if has_isa:
                    item.setProperty("inputstream", "inputstream.adaptive")
                    if '.mpd' in stream_url:
                        if kodiver < 21:
                            item.setProperty('inputstream.adaptive.manifest_type', 'mpd')
                        item.setMimeType('application/dash+xml')
                    else:
                        if kodiver < 21:
                            item.setProperty('inputstream.adaptive.manifest_type', 'hls')
                        item.setMimeType('application/vnd.apple.mpegurl')
                    item.setContentLookup(False)
                    if encoded_headers:
                        item.setProperty('inputstream.adaptive.stream_headers', encoded_headers)
                        item.setProperty('inputstream.adaptive.manifest_headers', encoded_headers)
                    url = stream_url
                else:
                    # Native Kodi-Wiedergabe: Header müssen an der URL bleiben.
                    item.setMimeType('application/vnd.apple.mpegurl' if '.m3u' in stream_url else 'application/dash+xml')
                    item.setContentLookup(False)
                    url = stream_url + (('|' + encoded_headers) if encoded_headers else '')

            # incvideo direct MP4 can block Kodi's native HTTP reader for several
            # seconds during Stop. Relay only this host through localhost; Range and
            # authentication headers are forwarded upstream, while Kodi can tear down
            # its local socket immediately.
            self._transport_proxy = None
            if 'incvideo' in str(url).lower():
                try:
                    url, self._transport_proxy = _start_incvideo_proxy(str(url))
                except Exception:
                    self._transport_proxy = None

            item.setPath(url)
            try:
                item.setArt({'poster': meta['poster']})
                item.setInfo(type='Video', infoLabels=Info)
            except:
                pass
            item.setProperty('IsPlayable', 'true')

            if int(sys.argv[1]) > 0:
                xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
            else:
                xbmc.Player().play(url, item)
            self.keepPlaybackAlive()
            if self._transport_proxy is not None:
                try:
                    self._transport_proxy.shutdown()
                    self._transport_proxy.server_close()
                except Exception:
                    pass
                self._transport_proxy = None
            # Serienfunktion erst nach sauber beendetem Player-Lauf starten.
            # Filme gelangen niemals in diesen Pfad.
            if self._next_episode_after_playback:
                self._offer_next_episode()
            return
        except:
            try:
                if getattr(self, '_transport_proxy', None) is not None:
                    self._transport_proxy.shutdown()
                    self._transport_proxy.server_close()
            except Exception:
                pass
            return


    def keepPlaybackAlive(self):
        if self.isdebug: log_utils.log('Start - keepPlaybackAlive', log_utils.LOGINFO)
        for i in range(0, 240):
            if self.isPlayingVideo(): break
            control.sleep(1)

        if self.isPlayingVideo():
            try:
                playcountDB.createEntry(self.mediatype, self.title, self.name, self.imdb, self.number_of_seasons, self.season, self.number_of_episodes, self.episode)
            except:
                pass

        monitor = xbmc.Monitor()
        self.watcher_control = False
        while (not monitor.abortRequested()) & (not self.streamFinished):
            if self.isPlayingVideo():
                self.totalTime = self.getTotalTime()
                self.currentTime = self.getTime()
                watcher = (self.currentTime / self.totalTime >= .9)
                if watcher and not self.watcher_control:
                    playcountDB.updatePlaycount(self.mediatype, self.title, self.name, self.imdb, self.number_of_seasons, self.season, self.number_of_episodes, self.episode, 1)
                    #control.setSetting(id='watcher.control', value='true')
                    self.watcher_control = True
            monitor.waitForAbort(3)

        if self.isdebug: log_utils.log('Ende - keepPlaybackAlive', log_utils.LOGINFO)


    def idleForPlayback(self):
        for i in range(0, 200):
            if control.condVisibility('Window.IsActive(busydialog)') == 1: control.idle()
            else: break
            control.sleep(1)


    def onAVStarted(self):
        if self.isdebug: log_utils.log('Start - onAVStarted', log_utils.LOGINFO)
        control.execute('Dialog.Close(all,true)')
        if not self.offset == '0': self.seekTime(float(self.offset))
        self.idleForPlayback()
        if control.getSetting('subtitles') == 'true':
            subtitles().get(self.name, self.imdb, self.season, self.episode)
            # Subtitles in Player MenÃ¼ ausschalten - wird dann bei Bedarf per "Hand" eingeschaltet
            # xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Player.SetSubtitle", "params": {"playerid": 1, "subtitle" : "on"}, "id": "1"}')
            xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "Player.SetSubtitle", "params": {"playerid": 1, "subtitle" : "off"}, "id": "1"}')
        if self.isdebug: log_utils.log('Ende - onAVStarted', log_utils.LOGINFO)


    def onPlayBackStopped(self):
        if self.isdebug: log_utils.log('Start - onPlayBackStopped', log_utils.LOGINFO)
        self.runVideoDB()
        self.streamFinished = True
        bookmarks().reset(self.currentTime, self.totalTime, self.name, self.year)
        if self.isdebug: log_utils.log('vor parentDir - onPlayBackStopped', log_utils.LOGINFO)
        if self.watcher_control:
            self.parentDir()
            self.watcher_control = False
        if self.isdebug: log_utils.log('Ende - onPlayBackStopped', log_utils.LOGINFO)

    def onPlayBackEnded(self):
        # Ein echtes Dateiende darf bei Serien optional die nächste Episode anbieten.
        # Ein manueller Stop ruft ausschließlich onPlayBackStopped() auf und löst dies nicht aus.
        self.runVideoDB()
        self.streamFinished = True
        bookmarks().reset(self.currentTime, self.totalTime, self.name, self.year)
        if self.watcher_control:
            self.parentDir()
            self.watcher_control = False
        if self.mediatype != 'movie' and self._has_next_episode():
            self._next_episode_after_playback = True
        if self.isdebug: log_utils.log('Ende - onPlayBackEnded', log_utils.LOGINFO)

    def _has_next_episode(self):
        try:
            season = int(self.season)
            episode = int(self.episode)
            episodes = int(self.number_of_episodes) if self.number_of_episodes not in (None, '', 'None') else 0
            seasons = int(self.number_of_seasons) if self.number_of_seasons not in (None, '', 'None') else 0
            if episodes and episode < episodes:
                return True
            if episodes and episode >= episodes and seasons and season < seasons:
                return True
        except Exception:
            return False
        return False

    def _next_episode_meta(self):
        try:
            meta = dict(self.meta)
            season = int(self.season)
            episode = int(self.episode)
            episodes = int(self.number_of_episodes) if self.number_of_episodes not in (None, '', 'None') else 0
            if episodes and episode < episodes:
                meta['episode'] = episode + 1
            else:
                meta['season'] = season + 1
                meta['episode'] = 1
                # Die Episodenanzahl gehört zur bisherigen Staffel und darf für
                # die neue Staffel nicht als Grenze weiterverwendet werden.
                meta.pop('number_of_episodes', None)
            meta['playcount'] = 0
            meta.pop('overlay', None)
            # Nur der automatische Folgewechsel nutzt die direkte Streamwahl.
            # Normale Episodenaufrufe und Filme behalten die konfigurierte Hosterliste.
            meta['select'] = '2'
            meta['_series_next_autoplay'] = True
            return meta
        except Exception:
            return None

    def _offer_next_episode(self):
        # Ausschließlich Serien. Bei deaktivierter Option endet die Episode normal.
        # Bei aktivierter Option gibt es keinen Dialog: die nächste Episode wird
        # direkt über die stille Serien-Autoplay-Suche gestartet.
        if self.mediatype == 'movie':
            return
        if control.getSetting('series.next.autoplay') != 'true':
            return
        meta = self._next_episode_meta()
        if not meta:
            return
        try:
            # Kleine, nicht blockierende Kodi-Info bevor die stille Suche startet.
            # Nur dieser automatische Serien-Folgewechsel gelangt hierher.
            try:
                next_season = int(meta.get('season', self.season))
                next_episode = int(meta.get('episode', 0))
                message = 'Episode S%02dE%02d wird gestartet ...' % (next_season, next_episode)
                xbmcgui.Dialog().notification('xShip - Nächste Episode', message,
                                              xbmcgui.NOTIFICATION_INFO, 3500, False)
            except Exception:
                pass
            sysmeta = control.quote_plus(json.dumps(meta))
            control.execute('RunPlugin(%s?action=play&sysmeta=%s)' % (sys.argv[0], sysmeta))
        except Exception:
            return


    def parentDir(self):
        refreshtime = 2
        control.sleep(refreshtime)
        ccont = ''
        if control.getSetting('series.play.mode' if self.mediatype != 'movie' else 'movie.play.mode') == '2': # Verzeichnis
            count = 0
            # prÃ¼fen ob Hosterliste aktiv ist - content ist da 'videos'
            for count in range(1, 25+1):
                control.sleep(2)
                ccont = control.getInfoLabel("Container.Content")
                if ccont == 'videos': break

            if self.isdebug: log_utils.log(__name__ + ' - count: %s - Container.Content (1):  %s' % (count, control.getInfoLabel("Container.Content")), log_utils.LOGINFO)
            if count == 25: return

            # zur Film- bzw. Episodenliste wechseln  - von content 'videos' dann zu content 'videos'
            if control.getInfoLabel("Container.Content") != 'movies' and ccont == 'videos':
                control.execute('Action(ParentDir)')
                for count in range(1, 15 + 1):
                    control.sleep(2)
                    ccont = control.getInfoLabel("Container.Content")
                    if ccont == 'movies': break

                if self.isdebug: log_utils.log(__name__ + ' - count: %s - Container.Content (2):  %s' % (count, control.getInfoLabel("Container.Content")), log_utils.LOGINFO)
                if count == 15:
                    return
                else:
                    refreshtime = 0

        if self.playcount == 0:
            ## auch abhÃ¤ngig von control.content()
            refresh = False
            if control.getSetting('status.refresh.movies') == 'true' and self.mediatype == 'movie': # immer!
                refresh = True
            elif control.getSetting('status.refresh.episodes') == 'true' and self.mediatype != 'movie':
                if xbmc.getCondVisibility('system.platform.linux') and xbmc.getCondVisibility('system.platform.android'): refresh = True  # Android
                elif control.getSetting('series.play.mode') == '2': refresh = True

            if refresh:
                if refreshtime != 0: control.sleep(refreshtime)
                control.execute('Container.Refresh')

# keine EintrÃ¤ge fÃ¼r bookmarks und files in die Kodi DB 'MyVideos116.db' anlegen bzw. sofort lÃ¶schen
    def runVideoDB(self):
        idFile = self.getVideoDB()
        if idFile != self.fileID:
            self.removeVideoDB(idFile)

    def getVideoDB(self):
        dbcon = database.connect(self.videoDB)
        dbcur = dbcon.cursor()
        dbcur.execute("SELECT * FROM files")
        match = dbcur.fetchall()
        dbcon.close()
        if match and len(match) > 0: idFile = len(match)
        else: idFile = 0
        return idFile

    def removeVideoDB(self, idFile):
        dbcon = database.connect(self.videoDB)
        dbcur = dbcon.cursor()
        dbcur.execute("DELETE FROM files WHERE idFile = '%s'" % idFile) # in DB vorhandener Trigger lÃ¶scht auch den bookmark
        dbcon.commit()
        dbcon.close()


class subtitles:
    def __init__(self, *args, **kwargs):
        from xbmcaddon import Addon
        __scriptname__ = "XBMC Subtitles Login"
        __version__ = Addon().getAddonInfo('version')  # Module version
        BASE_URL_XMLRPC = u"http://api.opensubtitles.org/xml-rpc"

        self.server = _xmlrpclib.ServerProxy(BASE_URL_XMLRPC, verbose=0)
        login = self.server.LogIn(Addon().getSetting('subtitles.os_user'), Addon().getSetting('subtitles.os_pass'), "en", "%s_v%s" % (__scriptname__.replace(" ", "_"), __version__))
        if login["status"] == "200 OK":
            self.osdb_token = login["token"]

    def get(self, name, imdb, season, episode):
        season = str(season)
        episode = str(episode)
        try:
            langDict = {'Afrikaans': 'afr', 'Albanian': 'alb', 'Arabic': 'ara', 'Armenian': 'arm', 'Basque': 'baq', 'Bengali': 'ben', 'Bosnian': 'bos', 'Breton': 'bre', 'Bulgarian': 'bul', 'Burmese': 'bur', 'Catalan': 'cat', 'Chinese': 'chi', 'Croatian': 'hrv', 'Czech': 'cze', 'Danish': 'dan', 'Dutch': 'dut', 'English': 'eng', 'Esperanto': 'epo', 'Estonian': 'est', 'Finnish': 'fin', 'French': 'fre', 'Galician': 'glg', 'Georgian': 'geo', 'German': 'ger', 'Greek': 'ell', 'Hebrew': 'heb', 'Hindi': 'hin', 'Hungarian': 'hun', 'Icelandic': 'ice', 'Indonesian': 'ind', 'Italian': 'ita', 'Japanese': 'jpn', 'Kazakh': 'kaz', 'Khmer': 'khm', 'Korean': 'kor', 'Latvian': 'lav', 'Lithuanian': 'lit', 'Luxembourgish': 'ltz', 'Macedonian': 'mac', 'Malay': 'may', 'Malayalam': 'mal', 'Manipuri': 'mni', 'Mongolian': 'mon', 'Montenegrin': 'mne', 'Norwegian': 'nor', 'Occitan': 'oci', 'Persian': 'per', 'Polish': 'pol', 'Portuguese': 'por,pob', 'Portuguese(Brazil)': 'pob,por', 'Romanian': 'rum', 'Russian': 'rus', 'Serbian': 'scc', 'Sinhalese': 'sin', 'Slovak': 'slo', 'Slovenian': 'slv', 'Spanish': 'spa', 'Swahili': 'swa', 'Swedish': 'swe', 'Syriac': 'syr', 'Tagalog': 'tgl', 'Tamil': 'tam', 'Telugu': 'tel', 'Thai': 'tha', 'Turkish': 'tur', 'Ukrainian': 'ukr', 'Urdu': 'urd'}
            codePageDict = {'ara': 'cp1256', 'ar': 'cp1256', 'ell': 'cp1253', 'el': 'cp1253', 'heb': 'cp1255', 'he': 'cp1255', 'tur': 'cp1254', 'tr': 'cp1254', 'rus': 'cp1251', 'ru': 'cp1251'}

            # opensubtitles.org
            os_user = control.getSetting('subtitles.os_user')
            os_pass = control.getSetting('subtitles.os_pass')
            os_useragent = 'TemporaryUserAgent'

            langs = []
            try:
                try: langs = langDict[control.getSetting('subtitles.lang.1')].split(',')
                except: langs.append(langDict[control.getSetting('subtitles.lang.1')])
            except: pass

            try:
                try: langs = langs + langDict[control.getSetting('subtitles.lang.2')].split(',')
                except: langs.append(langDict[control.getSetting('subtitles.lang.2')])
            except: pass

            try: subLang = xbmc.Player().getSubtitles()
            except: subLang = ''
            if subLang == langs[0]: raise Exception()

            imdbid = re.sub(r'[^0-9]', '', imdb)
            if season == 'None' or episode == 'None':
                result = self.server.SearchSubtitles(self.osdb_token, [{'sublanguageid': langs[0], 'imdbid': imdbid}])['data']
                if result == []: result = self.server.SearchSubtitles(self.osdb_token, [{'sublanguageid': langs[1], 'imdbid': imdbid}])['data']
            else:
                result = self.server.SearchSubtitles(self.osdb_token, [{'sublanguageid': langs[0], 'imdbid': imdbid, 'season': season, 'episode': episode}])['data']
                if result == []: result = self.server.SearchSubtitles(self.osdb_token, [{'sublanguageid': langs[1], 'imdbid': imdbid, 'season': season, 'episode': episode}])['data']
                # fmt = ['hdtv']

            filter = []
            result = [i for i in result if i['SubSumCD'] == '1']

            for userrank in ['OS Legend','Administrator','Translator','Platinum member','Gold member','Silver member', 'Bronze member','trusted','']:
                for i in result:
                    if i['UserRank'] == userrank.lower():
                        filter.append(i)

            try: lang = xbmc.convertLanguage(filter[0]['SubLanguageID'], xbmc.ISO_639_1)
            except: lang = filter[0]['SubLanguageID']

            subtitle = control.translatePath('special://temp/')
            subtitle = os.path.join(subtitle, 'TemporarySubs.%s.srt' % lang)

            ZipDownloadID = filter[0]['ZipDownloadLink'].split('/')[-1]
            ZipDownloadLink = 'https://dl.opensubtitles.org/en/download/sub/%s' % ZipDownloadID

            import requests, zipfile

            r = requests.get(ZipDownloadLink)
            zf = zipfile.ZipFile(_io(r.content))
            content = ''
            for name in zf.namelist():
                if not name.endswith('.srt'): continue
                content = zf.read(name)

            codepage = codePageDict.get(lang, '')
            if codepage and control.getSetting('subtitles.utf') == 'true':
                try:
                    content_encoded = codecs.decode(content, codepage)
                    content = codecs.encode(content_encoded, 'utf-8')
                except:
                    pass

            output = open(subtitle, 'wb')
            output.write(content)
            output.close()

            control.sleep(1)
            xbmc.Player().setSubtitles(subtitle)
        except:
            pass


class bookmarks:
    def get(self, name, year='0'):
        from resources.lib import bookmarkDB
        offset = '0'
        try:
            if not control.getSetting('bookmarks') == 'true': raise Exception()

            idFile = hashlib.md5()
            for i in name:
                try:
                    idFile.update(str(i).encode('utf-8'))
                except:
                    idFile.update(str(i))
            for i in year:
                try:
                    idFile.update(str(i).encode('utf-8'))
                except:
                    idFile.update(str(i))
            idFile = str(idFile.hexdigest())

            match = bookmarkDB.get_query(idFile, 'bookmarks.pcl')

            # dbcon = database.connect(control.bookmarksFile)
            # dbcur = dbcon.cursor()
            # dbcur.execute("CREATE TABLE IF NOT EXISTS bookmark (""idFile TEXT, ""timeInSeconds TEXT, ""UNIQUE(idFile)"");")
            # dbcur.execute("SELECT * FROM bookmark WHERE idFile = '%s'" % idFile)
            # match = dbcur.fetchone()
            # dbcon.commit()
            # dbcon.close()

            if match: self.offset = str(match[1])
            if self.offset == '0': raise Exception()
            minutes, seconds = divmod(float(self.offset), 60)
            hours, minutes = divmod(minutes, 60)
            label = '%02d:%02d:%02d' % (hours, minutes, seconds)
            label = py2_encode("Fortsetzen ab : %s" % label)

            if control.getSetting('bookmarks.auto') == 'false':
                try:
                    yes = control.dialog.contextmenu([label, "Vom Anfang abspielen", ])
                except:
                    yes = control.yesnoDialog(label, '', '', str(name), "Fortsetzen",
                                              "Vom Anfang abspielen")
                if yes:
                    bookmarkDB.remove_query(idFile, 'bookmarks')
                    self.offset = '0'

            return self.offset
        except:
            return offset


    def reset(self, currentTime, totalTime, name, year='0'):
        from resources.lib import bookmarkDB
        try:
            #if not control.getSetting('bookmarks') == 'true': raise Exception()
            if control.getSetting('bookmarks') == 'true' and int(currentTime) > 180:
                timeInSeconds = str(currentTime)
                idFile = hashlib.md5()
                for i in name:
                    try:
                        idFile.update(str(i).encode('utf-8'))
                    except:
                        idFile.update(str(i))
                for i in year:
                    try:
                        idFile.update(str(i).encode('utf-8'))
                    except:
                        idFile.update(str(i))
                idFile = str(idFile.hexdigest())

                if (currentTime / totalTime) >= .92:
                    bookmarkDB.remove_query(idFile, 'bookmarks')
                else:
                    bookmarkDB.save_query(idFile, timeInSeconds, 'bookmarks')

                # dbcon = database.connect(control.bookmarksFile)
                # dbcur = dbcon.cursor()
                # dbcur.execute("CREATE TABLE IF NOT EXISTS bookmark (""idFile TEXT, ""timeInSeconds TEXT, ""UNIQUE(idFile)"");")
                # if (currentTime / totalTime) <= .92:
                #     dbcur.execute("DELETE FROM bookmark WHERE idFile = '%s'" % idFile)
                #     dbcur.execute("INSERT INTO bookmark Values (?, ?)", (idFile, timeInSeconds))
                # else:
                #     dbcur.execute("DELETE FROM bookmark WHERE idFile = '%s'" % idFile)
                # dbcon.commit()
                # dbcon.close()

        except:
            pass

