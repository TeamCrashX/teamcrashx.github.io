# -*- coding: utf-8 -*-
"""

    Copyright (C) 2014-2016 bromix (plugin.video.youtube)
    Copyright (C) 2016-2025 plugin.video.youtube

    SPDX-License-Identifier: GPL-2.0-only
    See LICENSES/GPL-2.0-only for more information.
"""

from __future__ import absolute_import, division, unicode_literals

from weakref import ref

from ..abstract_settings import AbstractSettings
from ... import logging
from ...compatibility import xbmcaddon
from ...constants import ADDON_ID, BOOL_FROM_STR
from ...utils.system_version import current_system_version


class SettingsProxy(object):
    """Kodi settings adapter safe for an embedded add-on engine.

    The bundled YouTube engine expects its own typed settings schema.  Inside
    xShip those IDs are intentionally not part of the visible settings file.
    Kodi 21's typed Settings API raises and logs an exception for every missing
    or legacy-typed ID.  Use the backwards-compatible string API and convert
    values locally so the engine can use its defaults without polluting or
    delaying playback.
    """
    def __init__(self, instance):
        self.ref = instance

    @staticmethod
    def _raw(instance, setting):
        try:
            return instance.getSetting(setting)
        except Exception:
            return ''

    def get_bool(self, setting, *args, **kwargs):
        value = self._raw(self.ref, setting).strip().lower()
        return value in ('true', '1', 'yes', 'on')

    def set_bool(self, setting, value, *args, **kwargs):
        try:
            return self.ref.setSetting(setting, 'true' if value else 'false')
        except Exception:
            return False

    def get_int(self, setting, *args, **kwargs):
        try:
            return int(float(self._raw(self.ref, setting) or 0))
        except (TypeError, ValueError):
            return 0

    def set_int(self, setting, value, *args, **kwargs):
        try:
            return self.ref.setSetting(setting, str(int(value)))
        except Exception:
            return False

    def get_str(self, setting, *args, **kwargs):
        return self._raw(self.ref, setting)

    def set_str(self, setting, value, *args, **kwargs):
        try:
            return self.ref.setSetting(setting, '' if value is None else str(value))
        except Exception:
            return False

    def get_str_list(self, setting):
        value = self._raw(self.ref, setting)
        return value.split(',') if value else []

    def set_str_list(self, setting, value):
        return self.set_str(setting, ','.join(value or ()))


class XbmcPluginSettings(AbstractSettings):
    log = logging.getLogger(__name__)

    _instances = set()
    _proxy = None

    def __init__(self, xbmc_addon=None):
        self.flush(xbmc_addon, fill=True)

    def flush(self, xbmc_addon=None, fill=False, flush_all=True):
        if not xbmc_addon:
            if fill:
                xbmc_addon = xbmcaddon.Addon(ADDON_ID)
            else:
                if self.__class__._instances:
                    if flush_all:
                        self.__class__._instances.clear()
                    else:
                        self.__class__._instances.discard(self._proxy.ref)
                del self._proxy.ref
                self._proxy.ref = None
                del self._proxy
                self._proxy = None
                return
        else:
            fill = False

        self._cache = {}
        if current_system_version.compatible(21):
            self._proxy = SettingsProxy(xbmc_addon)
            # set methods in new Settings class are documented as returning a
            # bool, True if value was set, False otherwise, similar to how the
            # old set setting methods of the Addon class function. Except they
            # don't actually return anything...
            # Ignore return value until bug is fixed in Kodi
            self._check_set = False
        else:
            if fill and not current_system_version.compatible(19):
                self.__class__._instances.add(xbmc_addon)
            self._proxy = SettingsProxy(xbmc_addon)

        self._echo_level = self.log_level()

    def get_bool(self, setting, default=None, echo_level=2):
        if setting in self._cache:
            return self._cache[setting]

        error = False
        try:
            value = bool(self._proxy.get_bool(setting))
        except (TypeError, ValueError) as exc:
            error = exc
            try:
                value = self.get_string(setting, echo_level=0)
                value = BOOL_FROM_STR.get(value, default)
            except TypeError as exc:
                error = exc
                value = default
        except RuntimeError as exc:
            error = exc
            value = default

        if echo_level and self._echo_level:
            self.log.debug_trace('Get setting {name!r}:'
                                 ' {value!r} (bool, {state})',
                                 name=setting,
                                 value=value,
                                 state=(error if error else 'success'),
                                 stacklevel=echo_level)
        self._cache[setting] = value
        return value

    def set_bool(self, setting, value, echo_level=2):
        try:
            error = not self._proxy.set_bool(setting, value)
            if error and self._check_set:
                error = 'failed'
            else:
                error = False
                self._cache[setting] = value
        except (RuntimeError, TypeError) as exc:
            error = exc

        if echo_level and self._echo_level:
            self.log.debug_trace('Set setting {name!r}:'
                                 ' {value!r} (bool, {state})',
                                 name=setting,
                                 value=value,
                                 state=(error if error else 'success'),
                                 stacklevel=echo_level)
        return not error

    def get_int(self, setting, default=-1, process=None, echo_level=2):
        if setting in self._cache:
            return self._cache[setting]

        error = False
        try:
            value = int(self._proxy.get_int(setting))
            if process:
                value = process(value)
        except (TypeError, ValueError) as exc:
            error = exc
            try:
                value = self.get_string(setting, echo_level=0)
                value = int(value)
            except (TypeError, ValueError) as exc:
                error = exc
                value = default
        except RuntimeError as exc:
            error = exc
            value = default

        if echo_level and self._echo_level:
            self.log.debug_trace('Get setting {name!r}:'
                                 ' {value!r} (int, {state})',
                                 name=setting,
                                 value=value,
                                 state=(error if error else 'success'),
                                 stacklevel=echo_level)
        self._cache[setting] = value
        return value

    def set_int(self, setting, value, echo_level=2):
        try:
            error = not self._proxy.set_int(setting, value)
            if error and self._check_set:
                error = 'failed'
            else:
                error = False
                self._cache[setting] = value
        except (RuntimeError, TypeError) as exc:
            error = exc

        if echo_level and self._echo_level:
            self.log.debug_trace('Set setting {name!r}:'
                                 ' {value!r} (int, {state})',
                                 name=setting,
                                 value=value,
                                 state=(error if error else 'success'),
                                 stacklevel=echo_level)
        return not error

    def get_string(self, setting, default='', echo_level=2):
        if setting in self._cache:
            return self._cache[setting]

        error = False
        try:
            value = self._proxy.get_str(setting) or default
        except (RuntimeError, TypeError) as exc:
            error = exc
            value = default

        if echo_level and self._echo_level:
            log_setting = {setting: value}
            self.log.debug_trace('Get setting {setting!q} (str, {state})',
                                 setting=log_setting,
                                 state=(error if error else 'success'),
                                 stacklevel=echo_level)
        self._cache[setting] = value
        return value

    def set_string(self, setting, value, echo_level=2):
        try:
            error = not self._proxy.set_str(setting, value)
            if error and self._check_set:
                error = 'failed'
            else:
                error = False
                self._cache[setting] = value
        except (RuntimeError, TypeError) as exc:
            error = exc

        if echo_level and self._echo_level:
            log_setting = {setting: value}
            self.log.debug_trace('Set setting {setting!q} (str, {state})',
                                 setting=log_setting,
                                 state=(error if error else 'success'),
                                 stacklevel=echo_level)
        return not error

    def get_string_list(self, setting, default=None, echo_level=2):
        if setting in self._cache:
            return self._cache[setting]

        error = False
        try:
            value = self._proxy.get_str_list(setting)
            if not isinstance(value, list):
                value = [] if default is None else default
        except (RuntimeError, TypeError) as exc:
            error = exc
            value = [] if default is None else default

        if echo_level and self._echo_level:
            self.log.debug_trace('Get setting {name!r}:'
                                 ' {value} (list[str], {state})',
                                 name=setting,
                                 value=value,
                                 state=(error if error else 'success'),
                                 stacklevel=echo_level)
        self._cache[setting] = value
        return value

    def set_string_list(self, setting, value, echo_level=2):
        try:
            error = not self._proxy.set_str_list(setting, value)
            if error and self._check_set:
                error = 'failed'
            else:
                error = False
                self._cache[setting] = value
        except (RuntimeError, TypeError) as exc:
            error = exc

        if echo_level and self._echo_level:
            self.log.debug_trace('Set setting {name!r}:'
                                 ' {value} (list[str], {state})',
                                 name=setting,
                                 value=value,
                                 state=(error if error else 'success'),
                                 stacklevel=echo_level)
        return not error
