# -*- coding: utf-8 -*-
"""

    Copyright (C) 2017-2025 plugin.video.youtube

    SPDX-License-Identifier: GPL-2.0-only
    See LICENSES/GPL-2.0-only for more information.
"""

from __future__ import absolute_import, division, unicode_literals

import re
import os

from plugin.youtube.provider import Provider
from plugin.kodion.context import XbmcContext


def _get_core_components(addon_id=None):
    # The upstream engine expects its JSON stores to exist. Initialise harmless
    # anonymous stores inside xShip so no plugin.video.youtube installation is needed.
    try:
        import xbmcvfs
        base = xbmcvfs.translatePath('special://profile/addon_data/%s/' % (addon_id or 'plugin.video.xship'))
        if not os.path.isdir(base):
            os.makedirs(base, exist_ok=True)
        import json, uuid
        access_path = os.path.join(base, 'access_manager.json')
        valid_access = {
            'access_manager': {
                'users': {'0': {
                    'access_token': '', 'refresh_token': '', 'token_expires': -1,
                    'last_key_hash': '', 'name': 'Default', 'id': uuid.uuid4().hex,
                    'watch_later': 'WL', 'watch_history': 'HL'
                }},
                'current_user': 0, 'last_origin': addon_id or 'plugin.video.xship',
                'developers': {}
            }
        }
        try:
            with open(access_path, 'r', encoding='utf-8') as fh:
                existing = json.load(fh)
            if not isinstance(existing, dict) or not isinstance(existing.get('access_manager'), dict):
                raise ValueError
        except Exception:
            with open(access_path, 'w', encoding='utf-8') as fh:
                json.dump(valid_access, fh)
        api_path = os.path.join(base, 'api_keys.json')
        valid_api = {
            'keys': {
                'user': {
                    'api_key': '',
                    'client_id': '',
                    'client_secret': ''
                },
                'developer': {}
            }
        }
        try:
            with open(api_path, 'r', encoding='utf-8') as fh:
                existing_api = json.load(fh)
            if (not isinstance(existing_api, dict)
                    or not isinstance(existing_api.get('keys'), dict)
                    or not isinstance(existing_api['keys'].get('user'), dict)):
                raise ValueError
        except Exception:
            with open(api_path, 'w', encoding='utf-8') as fh:
                json.dump(valid_api, fh)
    except Exception:
        pass
    provider = Provider()
    if addon_id is not None:
        context = XbmcContext(plugin_id=addon_id)
    else:
        context = XbmcContext()
    client = provider.get_client(context=context)

    return provider, context, client


def resolve(video_id, sort=True, addon_id=None):
    """

    :param video_id: video id / video url
    :param sort: sort results by quality highest->lowest
    :param addon_id: addon id associated with developer keys to use for requests
    :type video_id: str
    :type sort: bool
    :type addon_id: str
    :return: all video items (resolved urls and metadata) for the given video id
    :rtype: list of dict
    """
    provider, context, client = _get_core_components(addon_id)
    matched_id = None
    streams = None

    patterns = [r'(?P<video_id>[\w-]{11})',
                r'(?:http)*s*:*[/]{0,2}(?:w{3}\.|m\.)*youtu(?:\.be/|be\.com/'
                r'(?:embed/|watch/|v/|.*?[?&/]v=))(?P<video_id>[\w-]{11}).*']

    for pattern in patterns:
        v_id = re.search(pattern, video_id)
        if v_id:
            matched_id = v_id.group('video_id')
            break

    if matched_id:
        streams, _ = client.load_stream_info(video_id=matched_id)

    if sort and streams:
        streams = sorted(streams, key=lambda x: x.get('sort', (0, 0)))

    return streams
