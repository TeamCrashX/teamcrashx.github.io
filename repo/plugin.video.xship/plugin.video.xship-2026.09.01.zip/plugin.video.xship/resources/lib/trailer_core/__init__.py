# -*- coding: utf-8 -*-
"""Vendored trailer playback components for xShip."""
