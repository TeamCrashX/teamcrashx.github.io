
# kinokiste
# 2026-04-10

import json
import requests as _requests
from scrapers.modules import cleantitle
from resources.lib.utils import isBlockedHoster
from resources.lib.control import getSetting
from resources.lib.requestHandler import cRequestHandler

SITE_IDENTIFIER = 'kinokiste'
SITE_DOMAIN     = 'kinokiste.eu'
SITE_NAME       = SITE_IDENTIFIER.upper()

class source:
    def __init__(self):
        self.priority  = 1
        self.language  = ['de']
        self.domain    = getSetting('provider.' + SITE_IDENTIFIER + '.domain', SITE_DOMAIN)
        self.base_link = 'https://' + self.domain
        self.sources   = []

    def _fetch(self, url):
        try:
            oRequest = cRequestHandler(url, caching=True)
            oRequest.cacheTime = 60 * 60 * 6
            oRequest.addHeaderEntry('Origin',           self.base_link)
            oRequest.addHeaderEntry('Referer',          self.base_link + '/')
            oRequest.addHeaderEntry('Accept',           'application/json, text/plain, */*')
            oRequest.addHeaderEntry('Accept-Language',  'de-DE,de;q=0.9,en-US;q=0.8,en;q=0.7')
            oRequest.addHeaderEntry('X-Requested-With', 'XMLHttpRequest')
            return oRequest.request()
        except:
            return ''

    def _load_all(self):
        url  = self.base_link + '/data/browse/?lang=all&order_by=new&page=1&limit=0'
        data = self._fetch(url)
        if not data:
            return []
        try:
            obj = json.loads(data)
            return obj.get('movies', [])
        except:
            return []

    def _get_streams(self, _id, season=0, episode=0):
        url  = self.base_link + '/data/watch/?_id=%s' % _id
        data = self._fetch(url)
        if not data:
            return
        try:
            obj = json.loads(data)
        except:
            return
        for stream in obj.get('streams', []):
            if season > 0 and str(stream.get('e', '')) != str(episode):
                continue
            sUrl     = stream.get('stream', '')
            sQuality = stream.get('release', 'SD') or 'SD'
            if not sUrl:
                continue
            isBlocked, hoster, url, prioHoster = isBlockedHoster(sUrl, isResolve=True)
            if isBlocked:
                continue
            self.sources.append({
                'source':     hoster,
                'quality':    sQuality,
                'language':   'de',
                'url':        url,
                'direct':     True,
                'prioHoster': prioHoster,
            })

    def run(self, titles, year, season=0, episode=0, imdb='', hostDict=None):
        try:
            t      = set([cleantitle.get(i) for i in set(titles) if i])
            years  = [str(year - 1), str(year), str(year + 1)]
            movies = self._load_all()

            if not movies:
                return self.sources

            for movie in movies:
                if '_id' not in movie:
                    continue
                sTitle = movie.get('title', '')
                sYear  = str(movie.get('year', ''))

                if season > 0:
                    base    = sTitle.rsplit('-', 1)[0].strip() if '-' in sTitle else sTitle
                    sSeason = sTitle.rsplit('-', 1)[1].strip() if '-' in sTitle else ''
                    if cleantitle.get(base) in t and str(season) in sSeason:
                        self._get_streams(str(movie['_id']), season, episode)
                        if self.sources:
                            break
                else:
                    if cleantitle.get(sTitle) in t and sYear in years:
                        self._get_streams(str(movie['_id']))
                        if self.sources:
                            break

        except:
            pass
        return self.sources

    def resolve(self, url):
        return url
