# filmpro.py
# 2024-06-02
# edit 2026-04-04 


import re
import html as _html
from urllib.parse import urlparse                        

from resources.lib.utils import isBlockedHoster
from resources.lib.requestHandler import cRequestHandler
from scrapers.modules import cleantitle
from scrapers.modules.tools import cParser
from resources.lib.control import getSetting, quote_plus

SITE_IDENTIFIER = 'filmpro'
SITE_DOMAIN     = 'filmpalast.one'
SITE_NAME       = SITE_IDENTIFIER.upper()

_MEINECLOUD = 'https://meinecloud.click'
_SEARCH_TPL = 'https://{domain}/?story={q}&do=search&subaction=search'


class source:
    def __init__(self):
        self.priority  = 1
        self.language  = ['de']
        self.domain    = getSetting('provider.' + SITE_IDENTIFIER + '.domain', SITE_DOMAIN)
        self.base_link = 'https://' + self.domain

    def _fetch(self, url, cache_hours=24, referer=None):
        
        oReq = cRequestHandler(url, bypass_dns=True, ssl_verify=False)
        oReq.cacheTime = 60 * 60 * cache_hours
        oReq.addHeaderEntry('Referer', referer or self.base_link + '/')
        # KEIN addHeaderEntry('User-Agent', ...) – RandomUA() übernimmt das
        return oReq.request() or ''

    @staticmethod
    def _quality(raw):
        q = raw.strip().upper()
        if '4K' in q or '2160' in q: return '4K'
        if '1080' in q:               return '1080p'
        if '720'  in q:               return '720p'
        if 'CAM'  in q or 'TS' in q: return 'CAM'
        if 'SD'   in q or 'LD' in q: return 'SD'
        return 'HD'

    @staticmethod
    def _clean(s):
        s = _html.unescape(s)
        s = re.sub(r'\s*[–\-]\s*Der\s+Film\s*$',  '', s, flags=re.IGNORECASE)
        s = re.sub(r'\s*[–\-]\s*Die\s+Serie\s*$', '', s, flags=re.IGNORECASE)
        return cleantitle.get(s)

    def _search(self, titles, year):
        t     = [self._clean(i) for i in titles if i]
        years = (str(year), str(int(year) + 1), str(int(year) - 1))
        pattern = (
            r'href="(https?://[^"]+/stream/[^"]+)"[^>]*>'
            r'.*?class="Title">([^<]+)</h3>'
            r'\s*<span class="Year">(\d+)</span>'
            r'.*?class="Qlty">([^<]+)</span>'
        )
        for title in titles:
            try:
                sHtml = self._fetch(
                    _SEARCH_TPL.format(domain=self.domain, q=quote_plus(title)),
                    cache_hours=48, referer=self.base_link + '/'
                )
                if not sHtml:
                    continue
                isMatch, aResults = cParser.parse(sHtml, pattern)
                if not isMatch:
                    continue
                for sUrl, sTitle, sYear, sQlty in aResults:
                    if sYear not in years:
                        continue
                    if self._clean(sTitle) not in t:
                        continue
                    return sUrl, self._quality(sQlty)
            except Exception:
                pass
        return '', 'HD'

    def _append_source(self, sources, link, quality):
        """Gemeinsame Hilfsmethode: isBlockedHoster prüfen und Source anhängen."""
        try:
            isBlocked, hoster, sUrl, prioHoster = isBlockedHoster(
                link, isResolve=False
            )
            if isBlocked:
                # resolveurl kennt diesen Hoster nicht → prioHoster=999
                # sourcesResolve versucht es dann mit include_popups=True
                hoster = urlparse(link).hostname or link
                sources.append({
                    'source':     hoster,
                    'quality':    quality,
                    'language':   'de',
                    'url':        link,
                    'direct':     False,
                    'prioHoster': 999,
                })
            else:
                sources.append({
                    'source':     hoster,
                    'quality':    quality,
                    'language':   'de',
                    'url':        link,
                    'direct':     False,
                    'prioHoster': prioHoster,
                })
        except Exception:
            pass

    def run(self, titles, year, season=0, episode=0, imdb='', hostDict=None):
        sources = []
        try:

            # ---- Filme ------------------------------------------------
            if season == 0:
                if not imdb:
                    return sources

                sHtml = self._fetch(
                    '%s/movie/%s' % (_MEINECLOUD, imdb),
                    cache_hours=48,
                    referer=self.base_link + '/'
                )
                if not sHtml:
                    return sources

                quality = 'HD'
                isM, qList = cParser.parse(
                    sHtml, r'class="_player-quality_link[^"]*"[^>]*>\s*([^\s<]+)'
                )
                if isM and qList:
                    quality = self._quality(qList[0])

                isMatch, dlinks = cParser.parse(sHtml, r'data-link="([^"]+)"')
                if not isMatch:
                    return sources

                for link in dlinks:
                    if not link or 'meinecloud' in link:
                        continue
                    if link.startswith('//'):
                        link = 'https:' + link
                    if not link.startswith('http'):
                        continue
                    self._append_source(sources, link, quality)

            # ---- Serien -----------------------------------------------
            else:
                page_url, quality = self._search(titles, year)
                if not page_url:
                    return sources

                sHtml = self._fetch(page_url, cache_hours=24,
                                    referer=self.base_link + '/')
                if not sHtml:
                    return sources

                pattern = r'data-num="%sx%s".*?"mirrors">(.*?)</div' % (season, episode)
                isMatch, dataLinks = cParser.parse(sHtml, pattern)
                if not isMatch or not dataLinks:
                    return sources

                isMatch, aResults = cParser.parse(dataLinks[0], r'(https?://[^\s"\'<>]+)')
                if not isMatch:
                    return sources

                for link in aResults:
                    self._append_source(sources, link, quality or 'HD')

        except Exception:
            pass

        return sources

    def resolve(self, url):
        return url
