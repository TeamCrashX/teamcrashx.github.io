
# streamcloud
# 2023-08-01
# edit 2026.04.10 

from resources.lib.utils import isBlockedHoster
from scrapers.modules.tools import cParser
from resources.lib.requestHandler import cRequestHandler
from scrapers.modules import cleantitle
from resources.lib.control import getSetting

SITE_IDENTIFIER = 'streamcloud'
SITE_DOMAIN     = 'streamcloud.uno'
SITE_NAME       = SITE_IDENTIFIER.upper()

class source:
    def __init__(self):
        self.priority  = 1
        self.language  = ['de']
        self.domain    = getSetting('provider.' + SITE_IDENTIFIER + '.domain', SITE_DOMAIN)
        self.base_link = 'https://' + self.domain
        self.search_link = self.base_link + '/index.php?story=%s&do=search&subaction=search'
        self.sources   = []

    def _add_source(self, sUrl, quality, found_urls):
        if not sUrl or sUrl in found_urls: return
        if 'youtube' in sUrl: return
        if sUrl.startswith('//'): sUrl = 'https:' + sUrl
        found_urls.add(sUrl)
        isBlocked, hoster, url, prioHoster = isBlockedHoster(sUrl)
        if isBlocked or not url: return
        self.sources.append({'source': hoster, 'quality': quality, 'language': 'de', 'url': url, 'direct': True, 'prioHoster': prioHoster})

    def run(self, titles, year, season=0, episode=0, imdb=''):
        try:
            found_urls = set()

            if season == 0:
                # Schritt 1: Filmseite auf streamcloud.uno suchen (ohne Cache — frisches HTML)
                sFilmUrl = ''
                t     = set([cleantitle.get(i) for i in set(titles) if i])
                years = [str(year - 1), str(year), str(year + 1)]

                for sSearchText in titles:
                    try:
                        oRequest = cRequestHandler(self.search_link % sSearchText, caching=True)
                        sHtmlContent = oRequest.request()
                        pattern = r'class="thumb".*?title="([^"]+).*?href="([^"]+).*?_year">([^<]+)'
                        isMatch, aResult = cParser.parse(sHtmlContent, pattern)
                        if not isMatch: continue
                        for sName, sUrl, sYear in aResult:
                            if cleantitle.get(sName) in t and sYear.strip() in years:
                                sFilmUrl = sUrl
                                break
                        if sFilmUrl: break
                    except:
                        continue

                if not sFilmUrl: return self.sources

                # Schritt 2: Filmseite ohne Cache laden (cache busting via timestamp)
                import time as _time
                sBustUrl = sFilmUrl + ('&' if '?' in sFilmUrl else '?') + '_t=%d' % int(_time.time())
                oRequest2 = cRequestHandler(sBustUrl, caching=False)
                oRequest2.addHeaderEntry('Referer', self.base_link + '/')
                sDetail = oRequest2.request()

                # Schritt 3: iframe src extrahieren
                isMatchIframe, sIframeContainer = cParser.parseSingleResult(sDetail, r'<iframe.*?allowfull')
                if isMatchIframe:
                    isMatchSrc, aSrc = cParser.parse(sIframeContainer, r'src="([^"]+)')
                    if isMatchSrc and aSrc:
                        sIframeUrl = aSrc[0]
                        if sIframeUrl.startswith('//'): sIframeUrl = 'https:' + sIframeUrl

                        # Schritt 4: iframe-Inhalt laden mit Referer (cache busting)
                        sIframeUrlBust = sIframeUrl + ('&' if '?' in sIframeUrl else '?') + '_t=%d' % int(_time.time())
                        oRequest3 = cRequestHandler(sIframeUrlBust, caching=False)
                        oRequest3.addHeaderEntry('Referer', sFilmUrl)
                        sIframeContent = oRequest3.request()

                        # Schritt 5: data-link parsen
                        isMatch, aLinks = cParser.parse(sIframeContent, r'data-link="([^"]+)')
                        if isMatch:
                            for sUrl in aLinks:
                                if not sUrl or 'embed-.html' in sUrl: continue
                                self._add_source(sUrl, '720p', found_urls)

            else:
                # Serien
                oRequest = cRequestHandler(self.search_link % imdb, caching=True)
                sHtmlContent = oRequest.request()
                pattern = r'class="thumb".*?title="([^"]+).*?href="([^"]+).*?_year">([^<]+)'
                isMatch, aResult = cParser.parse(sHtmlContent, pattern)
                if not isMatch: return self.sources

                sName, sUrl, sYear = aResult[0]
                oRequest2 = cRequestHandler(sUrl, caching=False)
                sHtmlContent = oRequest2.request()
                pattern = r'%sx%s\s.*?/>' % (str(season), str(episode))
                isMatch, sLinkContainer = cParser.parseSingleResult(sHtmlContent, pattern)
                if not isMatch: return self.sources
                pattern = r'href="([^"]+)'
                isMatch, aResult = cParser.parse(sLinkContainer, pattern)
                if not isMatch: return self.sources
                for sUrl in aResult:
                    if sUrl.startswith('/'): sUrl = 'https:' + sUrl
                    isBlocked, hoster, url, prioHoster = isBlockedHoster(sUrl)
                    if isBlocked: continue
                    if url:
                        self.sources.append({'source': hoster, 'quality': '720p', 'language': 'de', 'url': url, 'direct': True, 'prioHoster': prioHoster})

        except:
            pass
        return self.sources

    def resolve(self, url):
        return url
