# topstreamfilm
# edit 2026.05.07


from resources.lib.utils import isBlockedHoster
import re
import html
from urllib.parse import urljoin
from scrapers.modules.tools import cParser
from resources.lib.requestHandler import cRequestHandler
from scrapers.modules import cleantitle
from resources.lib.control import getSetting, quote_plus
from resources.lib import log_utils

SITE_IDENTIFIER = 'topstreamfilm'
SITE_DOMAIN = 'topstreamfilm.live'
SITE_NAME = SITE_IDENTIFIER.upper()


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['de']
        self.domain = getSetting('provider.' + SITE_IDENTIFIER + '.domain', SITE_DOMAIN)
        self.base_link = 'https://' + self.domain
        self.search_link = self.base_link + '/index.php?do=search&subaction=search&story=%s'

        self.sources = []

    def _years(self, year):
        try:
            y = int(year)
            return (y, y + 1, y - 1, 0)
        except:
            return (0,)

    def _clean_result_title(self, title):
        try:
            title = html.unescape(title).replace('&#8211;', '-').strip()
            # Topstreamfilm haengt haeufig "- Der Film" bzw. "– Der Film" an.
            title = re.split(r'\s*[–-]\s*Der\s+Film\s*$', title, flags=re.I)[0].strip()
            # Falls danach noch ein Zusatz nach Gedankenstrich steht, den Haupttitel nutzen.
            if '–' in title:
                title = title.split('–')[0].strip()
            return title
        except:
            return title

    def _full_url(self, url):
        try:
            url = html.unescape(url.strip())
            if url.startswith('//'):
                return 'https:' + url
            return urljoin(self.base_link + '/', url)
        except:
            return url

    def _request(self, url, cache=True):
        """Kleine Request-Hilfe, damit Cache-Zeit und Fehlerhandling einheitlich sind."""
        try:
            oRequest = cRequestHandler(url)
            if cache:
                oRequest.cacheTime = 0 if not cache else 60 * 60 * 3
            else:
                oRequest.cacheTime = 0
            return oRequest.request()
        except:
            return ''

    def _add_source(self, sUrl, quality='HD', seen=None):
        try:
            if not sUrl:
                return
            sUrl = html.unescape(self._full_url(sUrl.strip()))
            if seen is not None:
                if sUrl in seen:
                    return
                seen.add(sUrl)
            # Leere/irrelevante Player-URLs vermeiden.
            if re.search(r'/embed[^/]*\.html$', sUrl) or sUrl.endswith('/embed'):
                return
            if 'youtube' in sUrl.lower():
                return
            # Fix 1: engine/ajax ist kein Hosterlink
            if 'engine/ajax' in sUrl:
                return
            # Fix 2: interne TopStreamFilm-Links ignorieren
            if self.domain in sUrl:
                return

            isBlocked, hoster, url, prioHoster = isBlockedHoster(sUrl)
            if isBlocked or not url:
                return
            self.sources.append({
                'source': hoster,
                'quality': quality,
                'language': 'de',
                'url': url,
                'direct': True,
                'prioHoster': prioHoster
            })
        except:
            return

    def _extract_links_from_topstream_detail(self, sHtmlContent, page_url=None, seen=None, depth=0):
        """Hosterlinks aus TopStreamFilm-Detail-/Playerseiten sammeln.

        TopStreamFilm liefert Links je nach Seite unterschiedlich aus:
        - data-link / data-url / data-src
        - iframe src
        - direkte http(s)-src/href Einträge
        - interne Player-/Ajax-URLs, hinter denen erst der echte Hoster steckt
        """
        try:
            if seen is None:
                seen = set()
            if not sHtmlContent:
                return

            candidates = []
            patterns = [
                r'data-link\s*=\s*["\']([^"\']+)',
                r'\blink\s*=\s*["\']([^"\']+)',
                r'data-url\s*=\s*["\']([^"\']+)',
                r'data-src\s*=\s*["\']([^"\']+)',
                r'<iframe[^>]+src\s*=\s*["\']([^"\']+)',
                r'<source[^>]+src\s*=\s*["\']([^"\']+)',
                r'\bsrc\s*=\s*["\'](https?://[^"\']+)',
                r'\bhref\s*=\s*["\'](https?://[^"\']+)',
                r'window\.open\s*\(\s*["\']([^"\']+)',
            ]
            for pattern in patterns:
                try:
                    for sUrl in re.findall(pattern, sHtmlContent, re.DOTALL | re.I):
                        candidates.append(sUrl)
                except:
                    pass

            # JavaScript-escapes und einfache base64-codierte Linkfelder abfangen.
            try:
                encoded = re.findall(r'(?:link|url|src)["\']?\s*[:=]\s*["\']([A-Za-z0-9+/=]{30,})["\']', sHtmlContent, re.DOTALL | re.I)
                if encoded:
                    import base64
                    for value in encoded:
                        try:
                            decoded = base64.b64decode(value).decode('utf-8', 'ignore')
                            if decoded.startswith('http'):
                                candidates.append(decoded)
                        except:
                            pass
            except:
                pass

            # Erst echte externe Hoster hinzufügen.
            for sUrl in candidates:
                try:
                    sUrl = self._full_url(sUrl)
                    if not sUrl or sUrl in seen:
                        continue
                    low = sUrl.lower()
                    if any(x in low for x in ['youtube.', 'facebook.', 'twitter.', 'instagram.', '.jpg', '.png', '.webp', '.gif', '.css', '.js']):
                        continue

                    # Interne TopStreamFilm-Player/Ajax-Seiten separat tiefer öffnen.
                    if self.domain in low or 'topstreamfilm.' in low:
                        continue
                    self._add_source(sUrl, 'HD', seen)
                except:
                    pass

            # Interne Player-/Ajax-URLs öffnen und darin erneut suchen.
            # Tiefe begrenzen, damit Kodi nicht in Schleifen läuft.
            if depth >= 2:
                return

            internal_patterns = [
                r'\bhref\s*=\s*["\']([^"\']*(?:embed|player|stream|watch|ajax|controller)[^"\']*)',
                r'\bsrc\s*=\s*["\']([^"\']*(?:embed|player|stream|watch|ajax|controller)[^"\']*)',
                r'data-(?:href|url|src)\s*=\s*["\']([^"\']*(?:embed|player|stream|watch|ajax|controller)[^"\']*)',
                r'["\']([^"\']*/engine/ajax/[^"\']*)["\']',
                r'["\']([^"\']*/ajax/[^"\']*)["\']',
            ]
            internal = []
            for pattern in internal_patterns:
                try:
                    internal.extend(re.findall(pattern, sHtmlContent, re.DOTALL | re.I))
                except:
                    pass

            # Häufige DLE/TopStreamFilm Ajax-Controller aus vorhandenen data-id/id-Attributen probieren.
            try:
                ids = re.findall(r'data-(?:id|movie|news-id)\s*=\s*["\']?(\d+)', sHtmlContent, re.I)
                for item_id in ids[:8]:
                    internal.append('/engine/ajax/controller.php?mod=movie&news_id=%s' % item_id)
                    internal.append('/engine/ajax/controller.php?mod=video&news_id=%s' % item_id)
                    internal.append('/engine/ajax/playlists.php?news_id=%s' % item_id)
            except:
                pass

            for sUrl in internal:
                try:
                    sUrl = self._full_url(sUrl)
                    if not sUrl or sUrl in seen:
                        continue
                    seen.add(sUrl)
                    sNextHtml = self._request(sUrl, cache=False)
                    if sNextHtml:
                        self._extract_links_from_topstream_detail(sNextHtml, sUrl, seen, depth + 1)
                except:
                    pass
        except:
            return

    def _search_topstream_movie(self, titles, year):
        """Filme finden: 1. Kategorie-Seiten (Kino/Neu) 2. Suchseite als Fallback."""
        try:
            wanted_titles = set([cleantitle.get(i) for i in set(titles) if i])
            years = self._years(year)
            links = []

            # === Schritt 1: Kategorie-Seiten durchsuchen ===
            # Kinoseite zuerst (aktuellste Filme), dann allgemeine Filme-Seite
            category_urls = [
                self.base_link + '/kinofilme/',
                self.base_link + '/beliebte-filme-online/',
                self.base_link + '/filme-online-sehen/',
            ]
            pattern_cat = r'<li[^>]+class="[^"]*TPostMv[^"]*"[^>]*>.*?<a href="([^"]+)".*?<h3[^>]+class="[^"]*Title[^"]*"[^>]*>(.*?)</h3>.*?<span[^>]+class="(?:Year|Date[^"]*?)"[^>]*>(\d{4})</span>'

            for cat_url in category_urls:
                try:
                    sHtmlContent = self._request(cat_url, cache=True)
                    if not sHtmlContent:
                        continue
                    isMatch, aResult = cParser.parse(sHtmlContent, pattern_cat)
                    if not isMatch:
                        continue
                    for sUrl, sName, sYear in aResult:
                        sName = re.sub(r'<.*?>', '', sName)
                        sName = html.unescape(sName).strip()
                        title_part = self._clean_result_title(sName)
                        try:
                            result_year = int(sYear)
                        except:
                            result_year = 0
                        ct = cleantitle.get(title_part)
                        if ct in wanted_titles:
                            if result_year in years:
                                links.insert(0, self._full_url(sUrl))
                            else:
                                links.append(self._full_url(sUrl))
                    if links:
                        break
                except Exception as e:
                    log_utils.log('[topstreamfilm] Kategorie Exception: %s' % str(e), log_utils.LOGWARNING)
                    continue

            # === Schritt 2: Suchseite als Fallback ===
            if not links:
                for sSearchText in titles:
                    try:
                        if not sSearchText:
                            continue
                        search_url = self.search_link % quote_plus(sSearchText)
                        sHtmlContent = self._request(search_url, cache=False)
                        if not sHtmlContent:
                            continue

                        isMatch, aResult = cParser.parse(sHtmlContent, pattern_cat)
                        if not isMatch:
                            pattern2 = r'href="(https?://[^"]+/kostenlos/[^"]+)"[^>]*>(?:(?!</a>).)*?<h[23][^>]*>(.*?)</h[23]>.*?(\d{4})</span>'
                            isMatch, aResult = cParser.parse(sHtmlContent, pattern2)
                        if not isMatch:
                            continue

                        for sUrl, sName, sYear in aResult:
                            sName = re.sub(r'<.*?>', '', sName)
                            sName = html.unescape(sName).strip()
                            title_part = self._clean_result_title(sName)
                            try:
                                result_year = int(sYear)
                            except:
                                result_year = 0
                            ct = cleantitle.get(title_part)
                            if ct in wanted_titles:
                                if result_year in years:
                                    links.insert(0, self._full_url(sUrl))
                                else:
                                    links.append(self._full_url(sUrl))

                        if links:
                            break
                    except Exception as e:
                        log_utils.log('[topstreamfilm] Suche Exception: %s' % str(e), log_utils.LOGWARNING)
                        continue

            if not links:
                return

            seen = set()
            for link in set(links):
                try:
                    sHtmlContent = self._request(link, cache=False)
                    if not sHtmlContent:
                        continue

                    # 1. #streams Block direkt auslesen (Dropload etc.)
                    streams_match = re.search(r'id="streams">(.*?)</div>', sHtmlContent, re.DOTALL)
                    if streams_match:
                        streams_block = streams_match.group(1)
                        stream_links = re.findall(r'<a href="([^"]+)"', streams_block)
                        stream_qualities = re.findall(r'<mark>([^<]+)</mark>', streams_block)
                        for idx, sUrl in enumerate(stream_links):
                            quality = stream_qualities[idx] if idx < len(stream_qualities) else 'HD'
                            self._add_source(sUrl, quality, seen)

                    # 2. IMDB-ID aus iframe/script src extrahieren (meinecloud-Pattern)
                    imdb_ids = re.findall(r'meinecloud\.click/(?:movie|ddl)/(tt\d+)', sHtmlContent)
                    if imdb_ids:
                        imdb_id = imdb_ids[0]
                        self._search_meinecloud_movie(imdb_id)
                    else:
                        # Fallback: generischer Link-Extraktor
                        self._extract_links_from_topstream_detail(sHtmlContent, seen)
                except Exception as e:
                    log_utils.log('[topstreamfilm] Detail Exception: %s' % str(e), log_utils.LOGWARNING)
                    continue
        except Exception as e:
            log_utils.log('[topstreamfilm] _search_topstream_movie Exception: %s' % str(e), log_utils.LOGWARNING)
            return

    def _search_meinecloud_movie(self, imdb):
        """meinecloud.click: Filmseite ohne Cache, iframe mit Referer laden."""
        try:
            if not imdb:
                return

            found_urls = set()
            movie_url = 'https://meinecloud.click/movie/%s' % imdb

            # Schritt 1: /movie/ Seite ohne Cache laden (cache busting via timestamp)
            try:
                import time as _time
                _t = int(_time.time())
                movie_url_bust = movie_url + '?_t=%d' % _t
                oRequest = cRequestHandler(movie_url_bust, caching=False)
                sHtmlContent = oRequest.request()

                # iframe src extrahieren
                isMatchIframe, sIframeContainer = cParser.parseSingleResult(sHtmlContent, r'<iframe.*?allowfull')
                if isMatchIframe:
                    isMatchSrc, aSrc = cParser.parse(sIframeContainer, r'src="([^"]+)')
                    if isMatchSrc and aSrc:
                        sIframeUrl = aSrc[0]
                        if sIframeUrl.startswith('//'): sIframeUrl = 'https:' + sIframeUrl
                        # iframe-Inhalt mit Referer laden (cache busting)
                        sIframeUrlBust = sIframeUrl + ('&' if '?' in sIframeUrl else '?') + '_t=%d' % _t
                        oRequest2 = cRequestHandler(sIframeUrlBust, caching=False)
                        oRequest2.addHeaderEntry('Referer', movie_url)
                        sIframeContent = oRequest2.request()
                        isMatch, aResult = cParser.parse(sIframeContent, r'data-link="([^"]+)')
                        if isMatch:
                            for sUrl in aResult:
                                self._add_source(sUrl, '720p', found_urls)

                # Fallback: data-link direkt in /movie/ suchen
                if not found_urls:
                    isMatch2, aResult2 = cParser.parse(sHtmlContent, r'data-link="([^"]+)')
                    if isMatch2:
                        for sUrl in aResult2:
                            self._add_source(sUrl, '720p', found_urls)
            except Exception as e:
                log_utils.log('[topstreamfilm] meinecloud /movie/ Exception: %s' % str(e), log_utils.LOGWARNING)

            # Schritt 2: /ddl/ mit Cache laden (window.open-Links)
            try:
                oRequest = cRequestHandler('https://meinecloud.click/ddl/%s' % imdb, caching=True)
                sHtmlContent = oRequest.request()
                pattern = r"window\.open.*?'([^']+).*?mark>([^<]+)"
                isMatch, aResult = cParser.parse(sHtmlContent, pattern)
                if isMatch:
                    for sUrl, sQuality in aResult:
                        if not sUrl or 'embed-.html' in sUrl or sUrl.endswith('/embed'):
                            continue
                        self._add_source(sUrl, sQuality.strip(), found_urls)
                isMatch2, aResult2 = cParser.parse(sHtmlContent, r'data-link="([^"]+)')
                if isMatch2:
                    for sUrl in aResult2:
                        if not sUrl or 'embed-.html' in sUrl or sUrl.endswith('/embed'):
                            continue
                        self._add_source(sUrl, 'HD', found_urls)
            except Exception as e:
                log_utils.log('[topstreamfilm] meinecloud /ddl/ Exception: %s' % str(e), log_utils.LOGWARNING)
        except Exception as e:
            log_utils.log('[topstreamfilm] _search_meinecloud_movie Exception: %s' % str(e), log_utils.LOGWARNING)
            return

    def run(self, titles, year, season=0, episode=0, imdb='', hostDict=None):
        try:
            # =================================================================
            # === FILME: TopStreamFilm-Titelsuche + meinecloud-Fallback      ===
            # =================================================================
            if season == 0:
                self._search_topstream_movie(titles, year)
                # Fallback nur nutzen, wenn TopStreamFilm nichts geliefert hat.
                if not self.sources:
                    self._search_meinecloud_movie(imdb)
                return self.sources

            # =================================================================
            # === SERIEN: direkt ueber topstreamfilm.live                   ===
            # =================================================================
            t = set([cleantitle.get(i) for i in set(titles) if i])
            links = []

            for sSearchText in titles:
                try:
                    url = self.search_link % quote_plus(sSearchText)
                    sHtmlContent = self._request(url, cache=False)

                    # TPostMv-Pattern aus der Such-Liste
                    # Pattern 1: TPostMv Struktur (Startseite/Kategorie)
                    pattern = r'<li[^>]+class="[^"]*TPostMv[^"]*"[^>]*>.*?<a href="([^"]+)".*?<h3[^>]+class="[^"]*Title[^"]*"[^>]*>(.*?)</h3>.*?<span[^>]+class="(?:Year|Date[^"]*?)"[^>]*>(\d{4})</span>'
                    isMatch, aResult = cParser.parse(sHtmlContent, pattern)
                    # Pattern 2: DLE Suchseiten-Fallback (direkt auf /kostenlos/ URLs)
                    if not isMatch:
                        pattern = r'href="(https?://[^"]+/kostenlos/[^"]+)"[^>]*>(?:(?!</a>).)*?<h[23][^>]*>(.*?)</h[23]>.*?(\d{4})</span>'
                        isMatch, aResult = cParser.parse(sHtmlContent, pattern)
                    if not isMatch:
                        continue

                    for sUrl, sName, sYear in aResult:
                        # Fix 6: HTML-Tags aus Titel entfernen
                        sName = re.sub(r'<.*?>', '', sName)
                        sName = html.unescape(sName).strip()
                        title_part = self._clean_result_title(sName)

                        if cleantitle.get(title_part) in t:
                            links.append({'url': self._full_url(sUrl), 'name': title_part, 'year': sYear})

                    if len(links) > 0:
                        break

                except:
                    continue

            if len(links) == 0:
                return self.sources

            # === Detail-Seite: Season/Episode auslesen ===
            for link in links:
                try:
                    sHtmlContent = self._request(link['url'], cache=False)

                    # Season-Block rausschneiden: id="season-N" ... bis naechster tab-pane ODER Ende
                    season_pattern = r'id="season-' + str(season) + r'"(.*?)(?:id="season-\d+"|</div>\s*</div>\s*</div>)'
                    season_match = re.search(season_pattern, sHtmlContent, re.DOTALL)
                    if not season_match:
                        # Fallback: ohne Lookahead, nimm ab id="season-N" alles bis Ende
                        season_pattern_fb = r'id="season-' + str(season) + r'"(.*)$'
                        season_match = re.search(season_pattern_fb, sHtmlContent, re.DOTALL)
                        if not season_match:
                            continue
                    season_block = season_match.group(1) if season_match.lastindex else season_match.group(0)

                    # Jetzt im Season-Block die <li>-Bloecke pro Episode finden
                    # data-num="SxE" identifiziert Episode, data-link sind die Hoster-URLs
                    # Struktur: <li> <a data-num="1x3" ...> <div class="mirrors"> <a data-link="..."><a data-link="...">
                    episode_pattern = r'data-num="' + str(season) + 'x' + str(episode) + r'"(.*?)</li>'
                    ep_match = re.search(episode_pattern, season_block, re.DOTALL)
                    if not ep_match:
                        continue
                    ep_block = ep_match.group(1)

                    # Alle data-link aus dem Episode-Block ziehen (inkl. mirrors).
                    # Falls TopStreamFilm andere Attribute/iframe nutzt, denselben robusten Extractor verwenden.
                    seen = set()
                    isMatch, aLinks = cParser.parse(ep_block, r'data-link="([^"]+)')
                    if isMatch:
                        for sUrl in aLinks:
                            self._add_source(sUrl, 'HD', seen)
                    else:
                        self._extract_links_from_topstream_detail(ep_block, link['url'], seen)

                except:
                    continue

            return self.sources

        except Exception as e:
            log_utils.log('[topstreamfilm] run() Exception: %s' % str(e), log_utils.LOGWARNING)
            return self.sources

    def resolve(self, url):
        try:
            return url
        except:
            return
