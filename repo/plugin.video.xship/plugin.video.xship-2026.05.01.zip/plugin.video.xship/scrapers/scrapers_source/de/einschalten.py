# einschalten
# 2024-09-05
# edit 2026.05.07 — Umbau auf JSON-API /api/movies

import json
from resources.lib.utils import isBlockedHoster
from resources.lib.requestHandler import cRequestHandler
from resources.lib.control import getSetting, quote_plus
from scrapers.modules import cleantitle
from resources.lib import log_utils

SITE_IDENTIFIER = 'einschalten'
SITE_DOMAIN     = 'einschalten.in'
SITE_NAME       = SITE_IDENTIFIER.upper()

class source:
    def __init__(self):
        self.priority  = 1
        self.language  = ['de']
        self.domain    = getSetting('provider.' + SITE_IDENTIFIER + '.domain', SITE_DOMAIN)
        self.base_link = 'https://' + self.domain
        self.api_link  = self.base_link + '/api/movies'
        self.sources   = []

    def _fetch(self, url):
        try:
            oRequest = cRequestHandler(url, caching=True)
            oRequest.cacheTime = 60 * 60 * 6
            oRequest.addHeaderEntry('Accept',       'application/json, text/plain, */*')
            oRequest.addHeaderEntry('Referer',      self.base_link + '/')
            oRequest.addHeaderEntry('Origin',       self.base_link)
            return oRequest.request()
        except Exception as e:
            log_utils.log('[%s] _fetch Fehler: %s' % (SITE_NAME, str(e)), log_utils.LOGWARNING)
            return ''

    @staticmethod
    def _quality(release):
        r = str(release).upper()
        if '2160' in r or '4K' in r:  return '4K'
        if '1080' in r:                return '1080p'
        if '720' in r:                 return '720p'
        if 'SD' in r or '480' in r:   return 'SD'
        return 'HD'

    def run(self, titles, year, season=0, episode=0, imdb='', hostDict=None):
        # einschalten.in hat nur Filme, keine Serien
        if season > 0:
            return self.sources
        try:
            t     = set([cleantitle.get(i) for i in set(titles) if i])
            years = (str(year), str(year - 1), str(year + 1))

            movie_id = None
            for sSearchText in titles:
                try:
                    url  = self.api_link + '?search=%s' % quote_plus(sSearchText)
                    data = self._fetch(url)
                    if not data:
                        continue
                    obj  = json.loads(data)
                    items = obj.get('data', []) if isinstance(obj, dict) else obj
                    for item in items:
                        sTitle = item.get('title', '')
                        sYear  = str(item.get('releaseDate', ''))[:4]
                        if cleantitle.get(sTitle) in t and sYear in years:
                            movie_id = item.get('id')
                            log_utils.log('[%s] Treffer: "%s" (%s) id=%s' % (
                                SITE_NAME, sTitle, sYear, movie_id), log_utils.LOGINFO)
                            break
                    if movie_id:
                        break
                except Exception as e:
                    log_utils.log('[%s] Suche Fehler: %s' % (SITE_NAME, str(e)), log_utils.LOGWARNING)
                    continue

            if not movie_id:
                return self.sources

            # Stream-URL holen
            watch_url = self.api_link + '/%s/watch' % movie_id
            data = self._fetch(watch_url)
            if not data:
                return self.sources

            try:
                jResult = json.loads(data)
            except Exception:
                return self.sources

            # API kann einzelnes Objekt oder Liste zurückgeben
            streams = jResult if isinstance(jResult, list) else [jResult]
            for stream in streams:
                streamUrl   = stream.get('streamUrl', '')
                releaseName = stream.get('releaseName', '')
                if not streamUrl:
                    continue
                quality = self._quality(releaseName)
                isBlocked, hoster, url, prioHoster = isBlockedHoster(streamUrl)
                if isBlocked or not url:
                    continue
                self.sources.append({
                    'source':     hoster,
                    'quality':    quality,
                    'language':   'de',
                    'url':        url,
                    'direct':     True,
                    'prioHoster': prioHoster
                })

        except Exception as e:
            log_utils.log('[%s] run() Fehler: %s' % (SITE_NAME, str(e)), log_utils.LOGWARNING)

        return self.sources

    def resolve(self, url):
        return url
