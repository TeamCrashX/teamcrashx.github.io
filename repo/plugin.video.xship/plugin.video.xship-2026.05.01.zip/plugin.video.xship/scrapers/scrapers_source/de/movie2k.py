# movie2k.py  (xShip Quellen-Scraper)
# 2026-04-10  

# edit 2026.05.07
import json
from scrapers.modules import cleantitle
from resources.lib.utils import isBlockedHoster
from resources.lib.control import getSetting
from resources.lib.requestHandler import cRequestHandler
from resources.lib import log_utils

SITE_IDENTIFIER = 'movie2k'
SITE_DOMAIN     = 'movie2k.ch'
SITE_NAME       = SITE_IDENTIFIER.upper()

class source:
    def __init__(self):
        self.priority  = 1
        self.language  = ['de']
        self.domain    = getSetting('provider.' + SITE_IDENTIFIER + '.domain', SITE_DOMAIN)
        self.base_link = 'https://' + self.domain
        self.sources   = []

    def _fetch(self, url):
        try:
            oRequest = cRequestHandler(url, caching=True)
            oRequest.cacheTime = 60 * 60 * 6
            oRequest.addHeaderEntry('Origin',           self.base_link)
            oRequest.addHeaderEntry('Referer',          self.base_link + '/')
            oRequest.addHeaderEntry('Accept',           'application/json, text/plain, */*')
            oRequest.addHeaderEntry('Accept-Language',  'de-DE,de;q=0.9,en-US;q=0.8,en;q=0.7')
            oRequest.addHeaderEntry('X-Requested-With', 'XMLHttpRequest')
            return oRequest.request()
        except Exception as e:
            log_utils.log('[%s] _fetch Fehler: %s' % (SITE_NAME, str(e)[:200]), log_utils.LOGWARNING)
            return ''

    def _load_all(self, media_type='movies'):
        url  = self.base_link + '/data/browse/?lang=all&order_by=new&page=1&limit=0&type=%s' % media_type
        data = self._fetch(url)
        if not data:
            log_utils.log('[%s] _load_all: keine Daten' % SITE_NAME, log_utils.LOGWARNING)
            return []
        try:
            obj    = json.loads(data)
            movies = obj.get('movies', []) or obj.get('shows', [])
            log_utils.log('[%s] _load_all: %d Eintraege geladen' % (SITE_NAME, len(movies)), log_utils.LOGINFO)
            return movies
        except Exception as e:
            log_utils.log('[%s] _load_all JSON-Fehler: %s | Antwort: %s' % (SITE_NAME, str(e), data[:200]), log_utils.LOGWARNING)
            return []

    @staticmethod
    def _quality(release):
        r = str(release).upper()
        if '4K' in r or '2160' in r: return '4K'
        if '1080' in r:               return '1080p'
        if '720' in r:                return '720p'
        if '.TS.' in r or 'CAM' in r: return 'CAM'
        if 'SD' in r or '480' in r:   return 'SD'
        return 'HD'

    def _get_streams(self, _id, season=0, episode=0):
        url  = self.base_link + '/data/watch/?_id=%s' % _id
        data = self._fetch(url)
        if not data:
            log_utils.log('[%s] _get_streams: keine Daten fuer _id=%s' % (SITE_NAME, _id), log_utils.LOGWARNING)
            return
        try:
            obj = json.loads(data)
        except Exception as e:
            log_utils.log('[%s] _get_streams JSON-Fehler: %s | Antwort: %s' % (SITE_NAME, str(e), data[:200]), log_utils.LOGWARNING)
            return

        log_utils.log('[%s] _get_streams: title="%s" imdb=%s' % (
            SITE_NAME, obj.get('title',''), obj.get('imdb_id','')), log_utils.LOGINFO)

        _skip = ('veev.to', 'veevcdn', 'vide0.net', 'vidsonic.net',
                 'vidara.to', 'vidara.so', 'vidara.si',
                 'vinovo.to', 'vinovo.si', 'bonuscaf.com', 'playmogo.com',
                 'streamtape')

        streams = obj.get('streams', [])
        log_utils.log('[%s] _get_streams: %d Streams' % (SITE_NAME, len(streams)), log_utils.LOGINFO)

        seen = set()
        for stream in streams:
            if season > 0 and str(stream.get('e', '')) != str(episode):
                continue
            sUrl     = stream.get('stream', '')
            sQuality = self._quality(stream.get('release', ''))
            if not sUrl or not sUrl.startswith('http'):
                continue
            if any(x in sUrl for x in _skip):
                continue
            if any(x in sUrl for x in (self.domain, 'movie2k')):
                continue
            if 'embed-.html' in sUrl or sUrl.endswith('/embed'):
                continue
            if sUrl in seen:
                continue
            seen.add(sUrl)
            isBlocked, hoster, url, prioHoster = isBlockedHoster(sUrl, isResolve=False)
            if isBlocked or not url:
                continue
            log_utils.log('[%s] Stream: %s [%s]' % (SITE_NAME, sUrl, sQuality), log_utils.LOGINFO)
            self.sources.append({
                'source':     hoster,
                'quality':    sQuality,
                'language':   'de',
                'url':        sUrl,
                'direct':     False,
                'prioHoster': prioHoster,
            })

    def run(self, titles, year, season=0, episode=0, imdb=''):
        log_utils.log('[%s] run() start: titles=%s year=%s season=%s episode=%s imdb=%s' % (
            SITE_NAME, titles, year, season, episode, imdb), log_utils.LOGINFO)
        try:
            t          = set([cleantitle.get(i) for i in set(titles) if i])
            years      = [str(int(year) - 1), str(int(year)), str(int(year) + 1)]
            media_type = 'tvseries' if season > 0 else 'movies'
            movies     = self._load_all(media_type)

            if not movies:
                return self.sources

            for movie in movies:
                if '_id' not in movie:
                    continue
                sTitle = movie.get('title', '')
                sYear  = str(movie.get('year', ''))

                if season > 0:
                    base    = sTitle.rsplit('-', 1)[0].strip() if '-' in sTitle else sTitle
                    sSeason = sTitle.rsplit('-', 1)[1].strip() if '-' in sTitle else ''
                    if cleantitle.get(base) in t and str(season) in sSeason:
                        self._get_streams(str(movie['_id']), season, episode)
                        if self.sources:
                            break
                else:
                    if cleantitle.get(sTitle) in t and sYear in years:
                        log_utils.log('[%s] Treffer: "%s" (%s) _id=%s' % (
                            SITE_NAME, sTitle, sYear, movie['_id']), log_utils.LOGINFO)
                        self._get_streams(str(movie['_id']))
                        if self.sources:
                            break

        except Exception as e:
            log_utils.log('[%s] run() Fehler: %s' % (SITE_NAME, str(e)[:150]), log_utils.LOGWARNING)

        log_utils.log('[%s] run() end: %d Quellen' % (SITE_NAME, len(self.sources)), log_utils.LOGINFO)
        return self.sources

    def resolve(self, url):
        return url
