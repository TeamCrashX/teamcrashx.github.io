# fhdfilme
# edit 2026.04.10

import re
from resources.lib.utils import isBlockedHoster
from scrapers.modules.tools import cParser
from resources.lib.requestHandler import cRequestHandler
from resources.lib.control import getSetting, quote_plus as quote
from scrapers.modules import cleantitle

SITE_IDENTIFIER = 'fhdfilme'
SITE_DOMAIN     = 'hdfilme.win'
SITE_DOMAIN_MY  = 'hdfilme.my'
SITE_NAME       = SITE_IDENTIFIER.upper()


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['de']
        self.domain    = getSetting('provider.' + SITE_IDENTIFIER + '.domain', SITE_DOMAIN)
        self.base_link = 'https://' + self.domain
        self.base_my   = 'https://' + SITE_DOMAIN_MY
        self.search_link = self.base_link + '/index.php?do=search&do=search&subaction=search&search_start=1&full_search=0&result_from=1&titleonly=3&story=%s'
        self.search_my   = self.base_my   + '/?story=%s&do=search&subaction=search'
        self.sources  = []

    def _add(self, sUrl, quality, seen):
        if not sUrl:
            return
        if sUrl.startswith('//'):
            sUrl = 'https:' + sUrl
        elif sUrl.startswith('/'):
            return
        if not sUrl.startswith('http'):
            return
        if 'youtube' in sUrl:
            return
        last = sUrl.rstrip('/').split('/')[-1]
        if not last or len(last) < 3:
            return
        if re.search(r'/embed[^/]*\.html$', sUrl):
            return
        if sUrl in seen:
            return
        seen.add(sUrl)
        isBlocked, hoster, url, prioHoster = isBlockedHoster(sUrl)
        if isBlocked or not url:
            return
        self.sources.append({
            'source':     hoster,
            'quality':    quality,
            'language':   'de',
            'url':        url,
            'direct':     True,
            'prioHoster': prioHoster
        })

    def run(self, titles, year, season=0, episode=0, imdb='', hostDict=None):
        try:
            seen = set()

            # ── Filme ────────────────────────────────────────────────────────
            if season == 0:

                # Methode 1: hdfilme.my → Filmseite → iframe → data-link
                # iframe-Methode
                try:
                    t     = set([cleantitle.get(i) for i in set(titles) if i])
                    years = (year, year + 1, year - 1, 0)

                    for sSearchText in titles:
                        try:
                            oReq = cRequestHandler(self.search_my % quote(sSearchText))
                            oReq.cacheTime = 60 * 60 * 6
                            sHtml = oReq.request()
                            if not sHtml:
                                continue

                            # Suchergebnis-Pattern für hdfilme.my
                            pattern = r'class="item relative mt-3">.*?href="([^"]+).*?title="([^"]+).*?data-src="([^"]+)(.*?)</div></div>'
                            isMatch, aResult = cParser.parse(sHtml, pattern)
                            if not isMatch:
                                continue

                            for sUrl, sName, sThumbnail, sDummy in aResult:
                                yr_m = re.search(r'mt-1">[^<]*<span>([\d]{4})</span>', sDummy)
                                sYear = int(yr_m.group(1)) if yr_m else 0
                                if sYear not in years:
                                    continue
                                if cleantitle.get(sName.strip()) not in t:
                                    continue
                                # Filmseite laden → iframe src suchen
                                try:
                                    oReq2 = cRequestHandler(sUrl)
                                    oReq2.cacheTime = 60 * 60 * 6
                                    sFilmHtml = oReq2.request()
                                    isIframe, iframeSrc = cParser.parseSingleResult(
                                        sFilmHtml, r'<iframe\s[^>]*src="([^"]+)')
                                    if isIframe:
                                        oReq3 = cRequestHandler(iframeSrc)
                                        oReq3.addHeaderEntry('Referer', sUrl)
                                        oReq3.cacheTime = 60 * 60 * 2
                                        sIframeHtml = oReq3.request()
                                        isMatch2, aLinks = cParser.parse(
                                            sIframeHtml, r'data-link="([^"]+)')
                                        if isMatch2:
                                            for sLink in aLinks:
                                                self._add(sLink, '720p', seen)
                                except Exception:
                                    pass
                            if self.sources:
                                break
                        except Exception:
                            continue
                except Exception:
                    pass

                # Methode 2: meinecloud.click/movie/IMDB → data-link
                if imdb:
                    try:
                        oReq = cRequestHandler('https://meinecloud.click/movie/%s' % imdb, caching=True)
                        sHtml = oReq.request()
                        isMatch, aResult = cParser.parse(sHtml, r'data-link="([^"]+)')
                        if isMatch:
                            for sUrl in aResult:
                                self._add(sUrl, '720p', seen)
                    except Exception:
                        pass

                    # Methode 3: meinecloud.click/ddl/IMDB → window.open
                    try:
                        oReq = cRequestHandler('https://meinecloud.click/ddl/%s' % imdb, caching=True)
                        sHtml = oReq.request()
                        isMatch, aResult = cParser.parse(
                            sHtml, r"window\.open.*?'([^']+).*?mark>([^<]+)")
                        if isMatch:
                            for sUrl, sQuality in aResult:
                                self._add(sUrl, sQuality.strip(), seen)
                    except Exception:
                        pass

                return self.sources

            # ── Serien ───────────────────────────────────────────────────────
            t     = set([cleantitle.get(i) for i in set(titles) if i])
            links = []
            for sSearchText in titles:
                try:
                    oReq = cRequestHandler(self.search_link % quote(sSearchText))
                    sHtml = oReq.request()
                    pattern = r'class="movie-title"\s+title="([^"]+)"\s+href="([^"]+)".*?<span>(\d{4})</span>'
                    isMatch, aResult = cParser.parse(sHtml, pattern)
                    if not isMatch:
                        continue
                    for sName, sUrl, sYear in aResult:
                        if cleantitle.get(sName.strip()) in t:
                            links.append(sUrl)
                    if links:
                        break
                except Exception:
                    continue

            for url in links:
                try:
                    oReq = cRequestHandler(url)
                    sHtml = oReq.request()
                    pattern = r'id="se-ac-%s"[^>]*>(.*?)</div>' % str(season)
                    isMatch, sSeasonBlock = cParser.parseSingleResult(sHtml, pattern)
                    if not isMatch:
                        continue
                    block_pattern = r'%sx%s\s+Episode\s+\d+\s*[–-]?\s*(.*?)<br\s*/?>' % (str(season), str(episode))
                    isMatch, aEpBlock = cParser.parseSingleResult(sSeasonBlock, block_pattern)
                    if not isMatch:
                        continue
                    isMatch, aResult = cParser.parse(aEpBlock, r'<a[^>]+href="([^"]+)"[^>]*>([^<]+)</a>')
                    if not isMatch:
                        continue
                    for sUrl, sName in aResult:
                        if 'youtube' in sUrl or 'Player' in sName:
                            continue
                        if sUrl.startswith('/'):
                            sUrl = self.base_link + sUrl
                        self._add(sUrl, 'HD', seen)
                except Exception:
                    continue

        except Exception:
            pass

        return self.sources

    def resolve(self, url):
        return url
