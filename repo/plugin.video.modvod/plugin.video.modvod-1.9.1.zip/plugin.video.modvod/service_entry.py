# -*- coding: utf-8 -*-
from __future__ import absolute_import, division, unicode_literals

import zlib, base64
"""Service entry point"""

if __name__ == '__main__':
    from lib.service import run
    run()
