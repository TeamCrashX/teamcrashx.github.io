# -*- coding: utf-8 -*-
# Python 3

# Always pay attention to the translations in the menu!
# HTML LangzeitCache hinzugefügt
# showGenre:     48 Stunden
# showYears:     48 Stunden
# showEpisodes:   4 Stunden

from resources.lib.handler.ParameterHandler import ParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.tools import logger, cParser
from resources.lib.gui.guiElement import cGuiElement
from resources.lib.config import cConfig
from resources.lib.gui.gui import cGui

SITE_IDENTIFIER = 'streamcloud'
SITE_NAME = 'Streamcloud'
SITE_ICON = 'streamcloud.png'
SITE_FANART = cConfig().getAddonInfo('path') + '/resources/art/sites/' + SITE_ICON

# Global search function is thus deactivated!
if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'false':
    SITE_GLOBAL_SEARCH = False
    logger.info('-> [SitePlugin]: globalSearch for %s is deactivated.' % SITE_NAME)

# Domain Abfrage
DOMAIN = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '.domain', 'streamcloud.my') # Domain Auswahl über die xStream Einstellungen möglich
STATUS = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '_status') # Status Code Abfrage der Domain
ACTIVE = cConfig().getSetting('plugin_' + SITE_IDENTIFIER) # Ob Plugin aktiviert ist oder nicht

URL_MAIN = 'https://' + DOMAIN + '/'
# URL_MAIN = 'https://streamcloud.my/'
URL_MAINPAGE = URL_MAIN + 'streamcloud/'
URL_MOVIES = URL_MAIN + 'filme-stream/'
URL_KINO = URL_MAIN + 'kinofilme/'
URL_FAVOURITE_MOVIE_PAGE = URL_MAIN + 'beliebte-filme/'
URL_SERIES = URL_MAIN + 'serien/'
URL_NEW = URL_MAIN + 'neue-filme/'
URL_SEARCH = URL_MAIN + 'index.php?story=%s&do=search&subaction=search'

SCRAPER_SETTINGS = f'''
            <group id="plugin_streamcloud" label="30725">
                <setting id="plugin_streamcloud" type="boolean" label="30050" help="30411">
                    <level>0</level>
                    <default>True</default>
                    <control type="toggle"/>
                </setting>
                <setting id="global_search_streamcloud" type="boolean" label="30052">
                    <level>0</level>
                    <default>False</default>
                    <dependencies>
                        <dependency type="enable" operator="!is" setting="plugin_streamcloud">False</dependency>
                    </dependencies>
                    <control type="toggle"/>
                </setting>
                <setting id="plugin_streamcloud_checkDomain" type="boolean" label="30277">
                    <visible>false</visible>
                    <default>True</default>
                    <dependencies>
                        <dependency type="enable" operator="!is" setting="plugin_streamcloud">false</dependency>
                        <dependency type="visible" operator="!is" setting="plugin_streamcloud">false</dependency>
                    </dependencies>
                    <control type="toggle"/>
                </setting>
                <setting id="plugin_streamcloud.domain" type="string" label="30278" help="">
                    <level>0</level>
                    <default>streamcloud.my</default>
                    <constraints>
                        <allowempty>true</allowempty>
                    </constraints>
                    <dependencies>
                        <dependency type="enable" operator="!is" setting="plugin_streamcloud">false</dependency>
                        <dependency type="visible" operator="!is" setting="plugin_streamcloud">false</dependency>
                    </dependencies>
                    <control type="edit" format="string">
                        <heading>30278</heading>
                    </control>
                </setting>
                <setting id="plugin_streamcloud_status" type="string" label="Dummy" help="">
                    <visible>false</visible>
                    <default>true</default>
                    <control type="toggle"/>
                </setting>
            </group>
'''

#ToDo Serien auch auf reinen Filmseiten, prüfen ob Filterung möglich
def load(): # Menu structure of the site plugin
    logger.info('Load %s' % SITE_NAME)
    params = ParameterHandler()
    params.setParam('sUrl', URL_KINO)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30501), SITE_IDENTIFIER, 'showEntries'), params)  # Current films in the cinema
    params.setParam('sUrl', URL_NEW)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30500), SITE_IDENTIFIER, 'showEntries'), params)  # New Movies
    #params.setParam('sUrl', URL_FAVOURITE_MOVIE_PAGE)
    #cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30521), SITE_IDENTIFIER, 'showEntries'), params)  # Favorite Movies #ToDo Auskommentiert da URL auf Webseite fehlerhaft, zukünftig prüfen ob Fehler behoben
    #params.setParam('sUrl', URL_MOVIES)
    #cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30502), SITE_IDENTIFIER, 'showEntries'), params)  # Movies #ToDo Auskommentiert da URL auf Webseite fehlerhaft, zukünftig prüfen ob Fehler behoben
    params.setParam('sUrl', URL_MAINPAGE)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30507), SITE_IDENTIFIER, 'showGenre'), params)    # Categories
    params.setParam('sUrl', URL_MAINPAGE)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30508), SITE_IDENTIFIER, 'showYears'), params)    # Year
    params.setParam('sUrl', URL_MAINPAGE)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30538), SITE_IDENTIFIER, 'showCountry'), params)  # Country
    params.setParam('sUrl', URL_SERIES)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30511), SITE_IDENTIFIER, 'showSeries'), params)  # Series
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30520), SITE_IDENTIFIER, 'showSearch'), params)   # Search
    cGui().setEndOfDirectory()


def showGenre(entryUrl=False):
    params = ParameterHandler()
    if not entryUrl: entryUrl = params.getValue('sUrl')
    oRequest = cRequestHandler(entryUrl)
    if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
        oRequest.cacheTime = 60 * 60 * 48  # 48 Stunden
    sHtmlContent = oRequest.request()
    pattern = '>Genres<.*?</div></div>'
    isMatch, sHtmlContainer = cParser.parseSingleResult(sHtmlContent, pattern)
    if isMatch:
        isMatch, aResult = cParser.parse(sHtmlContainer, 'href="([^"]+).*?>([^<]+)')
    if not isMatch:
        cGui().showInfo()
        return

    for sUrl, sName in aResult:
        if sUrl.startswith('/'):
            sUrl = URL_MAIN + sUrl
        params.setParam('sUrl', sUrl)
        cGui().addFolder(cGuiElement(sName, SITE_IDENTIFIER, 'showEntries'), params)
    cGui().setEndOfDirectory()


def showYears(entryUrl=False):
    params = ParameterHandler()
    if not entryUrl: entryUrl = params.getValue('sUrl')
    oRequest = cRequestHandler(entryUrl)
    if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
        oRequest.cacheTime = 60 * 60 * 48  # 48 Stunden
    sHtmlContent = oRequest.request()
    pattern = '>Ers.*?</div></div>'
    isMatch, sHtmlContainer = cParser.parseSingleResult(sHtmlContent, pattern)
    if isMatch:
        isMatch, aResult = cParser.parse(sHtmlContainer, 'href=\'([^\']+).*?>([^<]+)')
    if not isMatch:
        cGui().showInfo()
        return
    for sUrl, sName in aResult:
        if sUrl.startswith('/'):
            sUrl = URL_MAIN + sUrl
        params.setParam('sUrl', sUrl)
        cGui().addFolder(cGuiElement(sName, SITE_IDENTIFIER, 'showEntries'), params)
    cGui().setEndOfDirectory()


def showCountry(entryUrl=False): #ToDo Sortierung A-Z bei Ländern
    params = ParameterHandler()
    if not entryUrl: entryUrl = params.getValue('sUrl')
    oRequest = cRequestHandler(entryUrl)
    if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
        oRequest.cacheTime = 60 * 60 * 48  # 48 Stunden
    sHtmlContent = oRequest.request()
    pattern = '">Land.*?</div></div>'
    isMatch, sHtmlContainer = cParser.parseSingleResult(sHtmlContent, pattern)
    if isMatch:
        isMatch, aResult = cParser.parse(sHtmlContainer, 'href="([^"]+).*?>([^<]+)')
    if not isMatch:
        cGui().showInfo()
        return

    for sUrl, sName in aResult:
        if sUrl.startswith('/'):
            sUrl = URL_MAIN + sUrl
        params.setParam('sUrl', sUrl)
        cGui().addFolder(cGuiElement(sName, SITE_IDENTIFIER, 'showEntries'), params)
    cGui().setEndOfDirectory()


def showEntries(entryUrl=False, sGui=False, sSearchText=False, sSearchPageText = False):
    oGui = sGui if sGui else cGui()
    params = ParameterHandler()
    isTvshow = False
    if not entryUrl: entryUrl = params.getValue('sUrl')
    oRequest = cRequestHandler(entryUrl, ignoreErrors=(sGui is not False))
    if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
        oRequest.cacheTime = 60 * 60 * 6  # HTML Cache Zeit 6 Stunden
    sHtmlContent = oRequest.request()
    pattern = 'class="thumb".*?title="([^"]+).*?href="([^"]+).*?src="([^"]+).*?_year">([^<]+)'
    isMatch, aResult = cParser.parse(sHtmlContent, pattern)
    if not isMatch:
        if not sGui: oGui.showInfo()
        return

    # Auf 16 Eintraege begrenzen
    if sSearchText:
        aResult = [r for r in aResult if cParser.search(sSearchText, r[0])]
    aResult = aResult[:16]
    total = len(aResult)
    for sName, sUrl, sThumbnail, sYear in aResult:
        sYear = sYear.strip()
        if sThumbnail.startswith('/'):
            sThumbnail = URL_MAIN + sThumbnail[1:]
        elif not sThumbnail.startswith('http'):
            sThumbnail = URL_MAIN + sThumbnail

        # Titelformat: Name - (Jahr)
        sDisplayTitle = sName.strip()
        if sYear and len(sYear) == 4:
            sDisplayTitle += ' - (%s)' % sYear

        # Startwert: Staffel im Namen → wahrscheinlich Serie
        isTvshow = 'taffel' in sName.lower() or 'staffel' in sName.lower()
        # Detail-Request (gecacht 7 Tage) für Desc, Fanart, Genre-Erkennung
        sDesc = ''
        try:
            sDetailUrl = sUrl if sUrl.startswith('http') else URL_MAIN + sUrl.lstrip('/')
            oDetailReq = cRequestHandler(sDetailUrl, ignoreErrors=True)
            oDetailReq.cacheTime = 60 * 60 * 24 * 7
            sDetailHtml = oDetailReq.request()
            if sDetailHtml:
                isDesc2, sDesc = cParser.parseSingleResult(sDetailHtml, r'itemprop="description">([^<]+)')
                isFanart, sFanart = cParser.parseSingleResult(sDetailHtml, r'property="og:image"[^>]*content="([^"]+)"')
                if isFanart and sFanart.startswith('/'):
                    sFanart = URL_MAIN + sFanart.lstrip('/')
                isRating, sRating = cParser.parseSingleResult(sDetailHtml, r'itemprop="ratingValue">([0-9.]+)')
                # Genre-Erkennung: Serien haben data-num (Episoden) oder Genre=Serie
                isGenreSerien = cParser.parseSingleResult(sDetailHtml, r'[Ss]erien|[Ss]erie|data-num=')[0]
                isEpisodes = cParser.parseSingleResult(sDetailHtml, r'data-num="')[0]
                if isGenreSerien or isEpisodes:
                    isTvshow = True
                # show_id vorhanden → DLE-Engine → meinecloud möglich
                isShowId = cParser.parseSingleResult(sDetailHtml, r'var show_id\s*=\s*(\d+)')[0]
                if isShowId:
                    isTvshow = True
        except Exception:
            sDetailHtml = ''
            isFanart = False
            isRating = False
            sRating = ''
            sFanart = ''

        sFunc = 'showEpisodes' if isTvshow else 'showHosters'
        oGuiElement = cGuiElement(sDisplayTitle, SITE_IDENTIFIER, sFunc)
        oGuiElement.setMediaType('tvshow' if isTvshow else 'movie')
        oGuiElement.setThumbnail(sThumbnail)
        oGuiElement.setFanart(sThumbnail)
        if sYear and len(sYear) == 4:
            oGuiElement.setYear(sYear)
        try:
            if sDesc:
                oGuiElement.setDescription(sDesc.strip())
            if isFanart and sFanart.startswith('http'):
                oGuiElement.setFanart(sFanart)
            if isRating:
                oGuiElement.addItemValue('rating', sRating)
        except Exception:
            pass
        params.setParam('entryUrl', sUrl)
        params.setParam('sName', sName)
        params.setParam('sThumbnail', sThumbnail)
        params.setParam('sYear', sYear)
        oGui.addFolder(oGuiElement, params, isTvshow, total)

    if not sGui and not sSearchText and not sSearchPageText:
        isMatchNextPage, sNextUrl = cParser.parseSingleResult(sHtmlContent, 'href="([^"]+)">Next')
        # Start Page Function
        isMatchSiteSearch, sHtmlContainer = cParser.parseSingleResult(sHtmlContent, 'class="wp-pagenavi(.*?)Next')
        if isMatchSiteSearch:
            isMatch, aResult = cParser.parse(sHtmlContainer,'<span>([\d]+)</span>.*?nav_ext">.*?">([\d]+)</a>.*?href="([^"]+)')
            for sPageActive, sPageLast, sNextPage in (aResult or []):
                # sPageName = '[I]Seitensuche starten  >>> [/I] Seite ' + str(sPageActive) + ' von ' + str(sPageLast) + ' Seiten  [I]<<<[/I]'
                sPageName = cConfig().getLocalizedString(30284) + str(sPageActive) + cConfig().getLocalizedString(
                    30285) + str(sPageLast) + cConfig().getLocalizedString(30286)
                params.setParam('sNextPage', sNextPage)
                params.setParam('sPageLast', sPageLast)
                oGui.searchNextPage(sPageName, SITE_IDENTIFIER, 'showSearchPage', params)
            # End Page Function

        if isMatchNextPage:
            params.setParam('sUrl', sNextUrl)
            oGui.addNextPage(SITE_IDENTIFIER, 'showEntries', params)

        oGui.setView('movies')
        oGui.setEndOfDirectory()


def showSeries(entryUrl=False, sGui=False, sSearchText=False): # Neu eingebaut da auf der Webseite nicht erkennbar ist was Serien sind und was nicht
    oGui = sGui if sGui else cGui()
    params = ParameterHandler()
    isTvshow = True
    if not entryUrl: entryUrl = params.getValue('sUrl')
    oRequest = cRequestHandler(entryUrl, ignoreErrors=(sGui is not False))
    if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
        oRequest.cacheTime = 60 * 60 * 6  # HTML Cache Zeit 6 Stunden
    sHtmlContent = oRequest.request()
    pattern = 'class="thumb".*?title="([^"]+).*?href="([^"]+).*?src="([^"]+).*?_year">([^<]+)'
    isMatch, aResult = cParser.parse(sHtmlContent, pattern)
    if not isMatch:
        if not sGui: oGui.showInfo()
        return

    total = len(aResult)
    for sName, sUrl, sThumbnail, sYear in aResult:
        if sSearchText and not cParser.search(sSearchText, sName):
            continue
        if sThumbnail[0] == '/':
            sThumbnail = sThumbnail[1:]
        oGuiElement = cGuiElement(sName, SITE_IDENTIFIER, 'showEpisodes')
        oGuiElement.setThumbnail(URL_MAIN + sThumbnail)
        oGuiElement.setMediaType('tvshow')
        #oGuiElement.setYear(sYear) #ToDo sYear erzeugt falschen Suchstring in tmdb.py (jahr in name)
        params.setParam('entryUrl', sUrl)
        params.setParam('sName', sName)
        params.setParam('sThumbnail', sThumbnail)
        params.setParam('sYear', sYear)

        oGui.addFolder(oGuiElement, params, isTvshow, total)

    if not sGui and not sSearchText:
        isMatchNextPage, sNextUrl = cParser.parseSingleResult(sHtmlContent, '"nav_ext.*?>\d[1-9]+<.*?href="([^"]+).*?</div>')
        if isMatchNextPage:
            params.setParam('sUrl', sNextUrl)
            oGui.addNextPage(SITE_IDENTIFIER, 'showSeries', params)
        oGui.setView('tvshows')
        oGui.setEndOfDirectory()


def showEpisodes():
    params = ParameterHandler()
    entryUrl = params.getValue('entryUrl')
    sThumbnail = params.getValue('sThumbnail')
    sHtmlContent = cRequestHandler(entryUrl, caching=True).request() or ''

    # Methode 1: meinecloud (show_id vorhanden → DLE-Engine)
    isShowId, sShowId = cParser.parseSingleResult(sHtmlContent, r'var show_id\s*=\s*(\d+)')
    isImdb, sImdbId = cParser.parseSingleResult(sHtmlContent, r"var imdb\s*=\s*'(tt\d+)'")

    if isShowId and isImdb:
        # Staffeln via meinecloud Playerseite ermitteln
        sImdbNum = sImdbId.replace('tt', '')
        # Erst Staffel 1 laden um Episodenzahl zu ermitteln
        sMcUrl = 'https://meinecloud.click/serial/%s?s=1&e=1' % sImdbNum
        sMcHtml = cRequestHandler(sMcUrl, caching=True).request() or ''
        isEps, aEpLinks = cParser.parse(sMcHtml, r'data-link=["\']([^"\'>]+)["\']')
        if isEps and aEpLinks:
            # Staffeln aus Sidebar
            # Staffelnummern aus Sidebar-Text extrahieren (S1, S2...) - NICHT data-season (interne DB-ID)
            isSeasons, aSeasonLabels = cParser.parse(sMcHtml, r'_stab[^>]*>\s*S(\d+)\s*<')
            if not isSeasons or not aSeasonLabels:
                # Fallback: Anzahl der data-season Attribute zählen und 1-basiert nummerieren
                isSeasons2, aSeasonIds = cParser.parse(sMcHtml, r'data-season=["\']?(\d+)["\']?')
                aSeasonLabels = [str(i+1) for i in range(len(aSeasonIds))] if isSeasons2 else ['1']
            params.setParam('sImdbNum', sImdbNum)
            params.setParam('sShowId', sShowId)
            total = len(aSeasonLabels)
            seen = set()
            for sSeason in aSeasonLabels:
                if sSeason in seen: continue
                seen.add(sSeason)
                oGuiElement = cGuiElement('Staffel ' + sSeason, SITE_IDENTIFIER, 'showEpisodesForSeason')
                oGuiElement.setThumbnail(sThumbnail)
                oGuiElement.setMediaType('season')
                params.setParam('season', sSeason)
                cGui().addFolder(oGuiElement, params, True, total)
            cGui().setView('seasons')
            cGui().setEndOfDirectory()
            return

    # Methode 2: data-num (alte streamcloud Methode)
    isMatch, aResult = cParser.parse(sHtmlContent, r'data-num="([^"]+)')
    if not isMatch or not aResult:
        cGui().showInfo()
        return
    total = len(aResult)
    for sName in aResult:
        oGuiElement = cGuiElement(sName, SITE_IDENTIFIER, 'showHosters')
        oGuiElement.setThumbnail(sThumbnail)
        oGuiElement.setMediaType('episode')
        params.setParam('entryUrl', entryUrl)
        params.setParam('episode', sName)
        cGui().addFolder(oGuiElement, params, False, total)
    cGui().setView('episodes')
    cGui().setEndOfDirectory()


def showEpisodesForSeason():
    params = ParameterHandler()
    entryUrl = params.getValue('entryUrl')
    sThumbnail = params.getValue('sThumbnail')
    sSeason = params.getValue('season')
    sImdbNum = params.getValue('sImdbNum')

    sMcUrl = 'https://meinecloud.click/serial/%s?s=%s&e=1' % (sImdbNum, sSeason)
    sMcHtml = cRequestHandler(sMcUrl, caching=True).request() or ''
    isEps, aEpLinks = cParser.parse(sMcHtml, r'data-link=["\']([^"\'>]+)["\']')
    if not isEps or not aEpLinks:
        cGui().showInfo()
        return

    total = len(aEpLinks)
    for i, _ in enumerate(aEpLinks):
        sEpNum = str(i + 1)
        oGuiElement = cGuiElement('Episode ' + sEpNum, SITE_IDENTIFIER, 'showEpisodeHosters')
        oGuiElement.setThumbnail(sThumbnail)
        oGuiElement.setMediaType('episode')
        params.setParam('entryUrl', entryUrl)
        params.setParam('sImdbNum', sImdbNum)
        params.setParam('season', sSeason)
        params.setParam('episode', sEpNum)
        cGui().addFolder(oGuiElement, params, False, total)
    cGui().setView('episodes')
    cGui().setEndOfDirectory()


def showEpisodeHosters():
    hosters = []
    params = ParameterHandler()
    sSeason = params.getValue('season')
    sEpisode = params.getValue('episode')
    sImdbNum = params.getValue('sImdbNum')
    sQuality = '720'

    if sImdbNum:
        sMcUrl = 'https://meinecloud.click/serial/%s?s=%s&e=%s' % (sImdbNum, sSeason, sEpisode)
        sMcHtml = cRequestHandler(sMcUrl, caching=False).request() or ''
        isLinks, aLinks = cParser.parse(sMcHtml, r'data-link=["\']([^"\'>]+)["\']')
        if isLinks and aLinks:
            try:
                idx = int(sEpisode) - 1
                sDataLink = aLinks[idx] if idx < len(aLinks) else aLinks[0]
            except Exception:
                sDataLink = aLinks[0]
            if sDataLink:
                if sDataLink.startswith('//'):
                    sDataLink = 'https:' + sDataLink
                sName = cParser.urlparse(sDataLink).split('.')[0].strip() or 'dr0pstream'
                hosters.append({'link': sDataLink, 'name': sName,
                                'displayedName': '%s [I][%sp][/I]' % (sName, sQuality),
                                'quality': sQuality})
    if hosters:
        hosters.append('getHosterUrl')
    return hosters


def showHosters():
    hosters = []
    sUrl = ParameterHandler().getValue('entryUrl')
    sHtmlContent = cRequestHandler(sUrl, caching=False).request()
    if ParameterHandler().exist('episode'): #kommt aus showSeries
        episode = ParameterHandler().getValue('episode')
        pattern = 'data-num="{0}".*?allowfull'.format(episode)
        isMatch, sHtmlContent = cParser.parseSingleResult(sHtmlContent, pattern)
    else:
        pattern = '<iframe.*?allowfull'
        isMatch, sHtmlContainer = cParser.parseSingleResult(sHtmlContent, pattern)
        if isMatch:
            isMatch, aResult = cParser.parse(sHtmlContainer, 'src="([^"]+)')
            try:
                sUrl = aResult[0]
            except:
                pass
        if not isMatch:
            cGui().showInfo()
            return
        sHtmlContent = cRequestHandler(sUrl).request()

    isMatch, aResult = cParser.parse(sHtmlContent, 'data-link="([^"]+)')
    if isMatch:
        sQuality = '720'
        for sUrl in aResult:
            if 'youtube' in sUrl:
                continue
            elif sUrl.startswith('//'):
                sUrl = 'https:' + sUrl
            sName = cParser.urlparse(sUrl).split('.')[0].strip()
            if cConfig().isBlockedHoster(sName)[0]: continue  # Hoster aus settings.xml oder deaktivierten Resolver ausschließen
            hoster = {'link': sUrl, 'name': sName, 'displayedName': '%s [I][%sp][/I]' % (sName, sQuality), 'quality': sQuality}
            hosters.append(hoster)
    if hosters:
        hosters.append('getHosterUrl')
    return hosters


def getHosterUrl(sUrl=False):
    if sUrl and 'meinecloud.click/serial' in sUrl:
        try:
            sHtml = cRequestHandler(sUrl, caching=False).request() or ''
            for pat in [
                r'["\'](https?://[^"\']+\.m3u8[^"\']*)["\'\s]',
                r'["\'](https?://[^"\']+\.mp4[^"\']*)["\'\s]',
                r'file\s*:\s*["\'](https?://[^"\'>]+)["\'\s]',
            ]:
                isM, aR = cParser.parse(sHtml, pat)
                if isM and aR:
                    return [{'streamUrl': aR[0], 'resolved': True}]
        except Exception:
            pass
    return [{'streamUrl': sUrl, 'resolved': False}]


def showSearch():
    sSearchText = cGui().showKeyBoard(sHeading=cConfig().getLocalizedString(30287))
    if not sSearchText: return
    _search(False, sSearchText)
    cGui().setEndOfDirectory()


def _search(oGui, sSearchText):
    showEntries(URL_SEARCH % cParser.quotePlus(sSearchText), oGui, sSearchText)


def showSearchPage(): # Suche für die Page Funktion
    params = ParameterHandler()
    sNextPage = params.getValue('sNextPage') # URL mit nächster Seite
    sPageLast = params.getValue('sPageLast') # Anzahl gefundener Seiten
    #sHeading = 'Bitte eine Zahl zwischen 1 und ' + str(sPageLast) + ' wählen.'
    sHeading = cConfig().getLocalizedString(30282) + str(sPageLast)
    sSearchPageText = cGui().showKeyBoard(sHeading=sHeading)
    if not sSearchPageText: return
    sNextSearchPage = sNextPage.split('page/')[0].strip() + 'page/' + sSearchPageText + '/'
    showEntries(sNextSearchPage)
    cGui().setEndOfDirectory()