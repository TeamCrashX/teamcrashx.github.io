# -*- coding: utf-8 -*-
# Python 3
# Always pay attention to the translations in the menu!
# HTML LangzeitCache hinzugefügt
# showValue:     48 Stunden
# showEntries:    6 Stunden
#
# Meinecloud-Serienstruktur:
#   API → player_url = https://meinecloud.click/serial/{imdb_num}
#   Diese Seite enthält die Staffel/Folgen-Navigation.
#   Episoden-URLs: https://meinecloud.click/serial/{imdb_num}/{staffel}/{folge}
#   showSeasons → scrapt Staffeln von der serial-Seite
#   showEpisodes → scrapt Folgen der gewählten Staffel
#   showHosters  → scrapt data-link aus der Episode-URL


from resources.lib.handler.ParameterHandler import ParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.tools import logger, cParser
from resources.lib.gui.guiElement import cGuiElement
from resources.lib.config import cConfig
from resources.lib.gui.gui import cGui

SITE_IDENTIFIER = 'fhdfilme'
SITE_NAME = 'FHD Filme'
SITE_ICON = 'fhdfilme.png'
SITE_FANART = cConfig().getAddonInfo('path') + '/resources/art/sites/' + SITE_ICON

if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'false':
    SITE_GLOBAL_SEARCH = False
    logger.info('-> [SitePlugin]: globalSearch for %s is deactivated.' % SITE_NAME)

DOMAIN = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '.domain', 'hdfilme.win')
STATUS = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '_status')
ACTIVE = cConfig().getSetting('plugin_' + SITE_IDENTIFIER)

URL_MAIN = 'https://' + DOMAIN
URL_NEW = URL_MAIN + '/filme1/'
URL_KINO = URL_MAIN + '/kinofilme/'
URL_MOVIES = URL_MAIN
URL_SERIES = URL_MAIN + '/serien/'
URL_SEARCH = URL_MAIN + '/?story=%s&do=search&subaction=search'

# Meinecloud-Basis-URL für Serien
MEINECLOUD_API  = 'https://meinecloud.click/serials.php?task=check&id_imdb=%s'
MEINECLOUD_BASE = 'https://meinecloud.click'

SCRAPER_SETTINGS = f'''
            <group id="plugin_fhdfilme" label="30720">
                <setting id="plugin_fhdfilme" type="boolean" label="30050" help="30411">
                    <level>0</level>
                    <default>True</default>
                    <control type="toggle"/>
                </setting>
                <setting id="global_search_fhdfilme" type="boolean" label="30052">
                    <level>0</level>
                    <default>True</default>
                    <dependencies>
                        <dependency type="enable" operator="!is" setting="plugin_fhdfilme">False</dependency>
                    </dependencies>
                    <control type="toggle"/>
                </setting>
                <setting id="plugin_fhdfilme_checkDomain" type="boolean" label="30277">
                    <visible>false</visible>
                    <default>True</default>
                    <dependencies>
                        <dependency type="enable" operator="!is" setting="plugin_fhdfilme">false</dependency>
                        <dependency type="visible" operator="!is" setting="plugin_fhdfilme">false</dependency>
                    </dependencies>
                    <control type="toggle"/>
                </setting>
                <setting id="plugin_fhdfilme.domain" type="string" label="30278" help="">
                    <level>0</level>
                    <default>hdfilme.win</default>
                    <constraints>
                        <allowempty>true</allowempty>
                    </constraints>
                    <dependencies>
                        <dependency type="enable" operator="!is" setting="plugin_fhdfilme">false</dependency>
                        <dependency type="visible" operator="!is" setting="plugin_fhdfilme">false</dependency>
                    </dependencies>
                    <control type="edit" format="string">
                        <heading>30278</heading>
                    </control>
                </setting>
                <setting id="plugin_fhdfilme_status" type="string" label="Dummy" help="">
                    <visible>false</visible>
                    <default>true</default>
                    <control type="toggle"/>
                </setting>
            </group>
'''


def load():
    logger.info('Load %s' % SITE_NAME)
    params = ParameterHandler()
    params.setParam('sUrl', URL_NEW)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30500), SITE_IDENTIFIER, 'showEntries'), params)
    params.setParam('sUrl', URL_KINO)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30501), SITE_IDENTIFIER, 'showEntries'), params)
    params.setParam('sUrl', URL_MOVIES)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30502), SITE_IDENTIFIER, 'showEntries'), params)
    params.setParam('sUrl', URL_SERIES)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30511), SITE_IDENTIFIER, 'showEntries'), params)
    params.setParam('Value', 'Jahres')
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30508), SITE_IDENTIFIER, 'showValue'), params)
    params.setParam('Value', 'Genre')
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30506), SITE_IDENTIFIER, 'showValue'), params)
    params.setParam('Value', 'Land')
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30538), SITE_IDENTIFIER, 'showValue'), params)
    cGui().addFolder(cGuiElement(cConfig().getLocalizedString(30520), SITE_IDENTIFIER, 'showSearch'), params)
    cGui().setEndOfDirectory()


def showValue():
    params = ParameterHandler()
    oRequest = cRequestHandler(URL_MAIN)
    if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
        oRequest.cacheTime = 60 * 60 * 48
    sHtmlContent = oRequest.request()
    sValue = params.getValue('Value')
    pattern = r'>' + sValue + r'<.*?class="dropdown-content[^"]*"[^>]*>(.*?)</div>'
    isMatch, sHtmlContainer = cParser.parseSingleResult(sHtmlContent, pattern)
    if isMatch:
        isMatch, aResult = cParser.parse(sHtmlContainer, 'href="([^"]+).*?>([^<]+)')
        for sUrl, sName in aResult:
            if sUrl.startswith('/'):
                sUrl = URL_MAIN + sUrl
            params.setParam('sUrl', sUrl)
            cGui().addFolder(cGuiElement(sName, SITE_IDENTIFIER, 'showEntries'), params)
    if not isMatch:
        cGui().showInfo()
        return
    cGui().setEndOfDirectory()


def showEntries(entryUrl=False, sGui=False, sSearchText=False, sSearchPageText=False):
    oGui = sGui if sGui else cGui()
    params = ParameterHandler()
    isTvshow = False
    if not entryUrl:
        entryUrl = params.getValue('sUrl')
    oRequest = cRequestHandler(entryUrl, ignoreErrors=(sGui is not False))
    if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
        oRequest.cacheTime = 60 * 60 * 6
    sHtmlContent = oRequest.request()
    pattern = r'class="item relative mt-3">.*?href="([^"]+)"[^>]*title="([^"]+)".*?data-src="([^"]+)".*?<div class="meta[^"]*">(.*?)</div>'
    isMatch, aResult = cParser.parse(sHtmlContent, pattern)
    if not isMatch:
        if not sGui:
            oGui.showInfo()
        return

    aResult = aResult[:16]
    total = len(aResult)

    from resources.lib.tmdb import cTMDB
    oTMDB = cTMDB()

    for sUrl, sName, sThumbnail, sDummy in aResult:
        if sSearchText and not cParser.search(sSearchText, sName):
            continue

        isYear, sYear = cParser.parseSingleResult(sDummy, '<span>(\d{4})</span>')
        isDuration, sDuration = cParser.parseSingleResult(sDummy, '<span>(\d+)\s*min</span>')

        if '/serien/' in sUrl:
            isTvshow = True
        elif isDuration and int(sDuration) <= 70:
            isTvshow = True
        else:
            isTvshow = False

        if not sThumbnail.startswith('http'):
            sThumbnail = URL_MAIN + sThumbnail
        sThumbnail = sThumbnail.replace('//hdfilme.my/', '//' + DOMAIN + '/')

        sEntryUrl = sUrl if sUrl.startswith('http') else URL_MAIN + sUrl

        oGuiElement = cGuiElement(sName, SITE_IDENTIFIER, 'showSeasons' if isTvshow else 'showHosters')
        oGuiElement.setMediaType('tvshow' if isTvshow else 'movie')
        oGuiElement.setThumbnail(sThumbnail)
        if isYear:
            oGuiElement.setYear(sYear)
        if isDuration:
            oGuiElement.addItemValue('duration', sDuration)

        try:
            sDetailHtml = cRequestHandler(sEntryUrl, caching=True, ignoreErrors=True).request()
            if sDetailHtml:
                isDesc, sDesc = cParser.parseSingleResult(sDetailHtml, 'property="og:description"[^>]*content="([^"]+)"')
                if not isDesc:
                    isDesc, sDesc = cParser.parseSingleResult(sDetailHtml, '<meta name="description"[^>]*content="([^"]+)"')
                if isDesc and sDesc.strip():
                    oGuiElement.setDescription(sDesc.strip())
                isPoster, sPoster = cParser.parseSingleResult(sDetailHtml, 'property="og:image"[^>]*content="([^"]+)"')
                if isPoster and sPoster.startswith('http'):
                    oGuiElement.setThumbnail(sPoster)
                    oGuiElement.setFanart(sPoster)
                isImdb, sImdb = cParser.parseSingleResult(sDetailHtml, "var imdb\s*=\s*'(tt\d+)'")
                params.setParam('sImdb', sImdb if isImdb else '')
                if isYear:
                    meta = oTMDB.getMetaData(sName, sYear, isTvshow)
                    if meta:
                        if meta.get('overview'):
                            oGuiElement.setDescription(meta['overview'])
                        if meta.get('vote_average'):
                            oGuiElement.addItemValue('rating', str(meta['vote_average']))
                        if meta.get('backdrop_path'):
                            oGuiElement.setFanart('https://image.tmdb.org/t/p/w1280' + meta['backdrop_path'])
                        if meta.get('poster_path'):
                            oGuiElement.setThumbnail('https://image.tmdb.org/t/p/w500' + meta['poster_path'])
        except Exception:
            params.setParam('sImdb', '')

        params.setParam('entryUrl', sEntryUrl)
        params.setParam('sName', sName)
        params.setParam('sThumbnail', oGuiElement.getThumbnail() or sThumbnail)
        oGui.addFolder(oGuiElement, params, isTvshow, total)

    if not sGui and not sSearchText and not sSearchPageText:
        isMatchNextPage, sNextUrl = cParser.parseSingleResult(sHtmlContent, 'nav_ext">.*?next">.*?href="([^"]+)')
        isMatchSiteSearch, sHtmlContainer = cParser.parseSingleResult(sHtmlContent, 'class="pages">(.*?)<svg')
        if isMatchSiteSearch:
            isMatch, aResult = cParser.parse(sHtmlContainer, '<span>([\d]+)</span>.*?">([\d]+)</a></div>.*?href="([^"]+)')
            for sPageActive, sPageLast, sNextPage in (aResult or []):
                sPageName = cConfig().getLocalizedString(30284) + str(sPageActive) + cConfig().getLocalizedString(30285) + str(sPageLast) + cConfig().getLocalizedString(30286)
                params.setParam('sNextPage', sNextPage)
                params.setParam('sPageLast', sPageLast)
                oGui.searchNextPage(sPageName, SITE_IDENTIFIER, 'showSearchPage', params)
        if isMatchNextPage:
            params.setParam('sUrl', sNextUrl)
            oGui.addNextPage(SITE_IDENTIFIER, 'showEntries', params)
        oGui.setView('tvshows' if isTvshow else 'movies')
        oGui.setEndOfDirectory()


def _getMcSerialUrl(sImdb):
    """
    Holt die Meinecloud serial-URL für eine IMDB-ID.
    Rückgabe: URL wie 'https://meinecloud.click/serial/14824792' oder ''.
    """
    try:
        import json
        oReq = cRequestHandler(MEINECLOUD_API % sImdb, caching=False)
        sResp = oReq.request()
        if sResp:
            oData = json.loads(sResp)
            if oData.get('exists') and oData.get('player_url'):
                return oData['player_url']
    except Exception as e:
        logger.info('[fhdfilme] _getMcSerialUrl Fehler: %s' % str(e))
    return ''


def showSeasons():
    """
    Meinecloud URL-Schema: /serial/{id}/{ep_nr}  (zweiteilig, keine Staffelnummer in URL).
    Staffeln werden über HTML-Attribute identifiziert (z.B. data-season, li.season-tab).
    Episoden-Links haben data-link direkt im gleichen Element.
    """
    params = ParameterHandler()
    sUrl = params.getValue('entryUrl')
    sThumbnail = params.getValue('sThumbnail')
    sName = params.getValue('sName')
    sImdb = params.getValue('sImdb')

    oRequest = cRequestHandler(sUrl)
    if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
        oRequest.cacheTime = 60 * 60 * 6
    sHtmlContent = oRequest.request()

    if not sImdb:
        isImdb, sImdb = cParser.parseSingleResult(sHtmlContent, "var imdb\s*=\s*'(tt\d+)'")
        if not isImdb:
            sImdb = ''

    isDesc, sDesc = cParser.parseSingleResult(sHtmlContent, 'property="og:description"[^>]*content="([^"]+)"')

    if sImdb:
        sMcSerialUrl = _getMcSerialUrl(sImdb)
        if sMcSerialUrl:
            try:
                oMcReq = cRequestHandler(sMcSerialUrl, caching=False)
                oMcReq.addHeaderEntry('Referer', URL_MAIN + '/')
                sMcHtml = oMcReq.request()
                if sMcHtml:
                    logger.info('[fhdfilme] Meinecloud HTML (erste 2000 Zeichen): %s' % sMcHtml[:2000])

                    # Versuch 1: Staffel-Tabs mit data-id oder ähnlichem
                    # Typische Meinecloud-Struktur: <li data-id="1">Staffel 1</li>
                    # oder <a href="#season-1">S1</a>
                    isMatch, aSeasons = cParser.parse(sMcHtml, r'data-id=["\']?(\d+)["\']?')

                    if not isMatch or not aSeasons:
                        # Versuch 2: Staffel-Buttons/Tabs mit Text "S1", "S2"
                        isMatch, aSeasons = cParser.parse(sMcHtml, r'>S(\d+)<')

                    if not isMatch or not aSeasons:
                        # Versuch 3: data-season Attribute
                        isMatch, aSeasons = cParser.parse(sMcHtml, r'data-season=["\']?(\d+)["\']?')

                    if not isMatch or not aSeasons:
                        # Versuch 4: season in URL /serial/{id}/{s}/{e} dreiteilig
                        sSerialId = sMcSerialUrl.rstrip('/').split('/')[-1]
                        isMatch, aPairs = cParser.parse(sMcHtml, r'/serial/' + sSerialId + r'/(\d+)/\d+')
                        if isMatch and aPairs:
                            aSeasons = aPairs

                    if isMatch and aSeasons:
                        seen = set()
                        aUniqueSeasons = []
                        for s in aSeasons:
                            if s not in seen:
                                seen.add(s)
                                aUniqueSeasons.append(s)
                        try:
                            aUniqueSeasons.sort(key=lambda x: int(x))
                        except Exception:
                            pass

                        # Nur sinnvolle Staffelnummern (1-50)
                        aUniqueSeasons = [s for s in aUniqueSeasons if s.isdigit() and 1 <= int(s) <= 50]

                        if aUniqueSeasons:
                            total = len(aUniqueSeasons)
                            for sSeason in aUniqueSeasons:
                                oGuiElement = cGuiElement('Staffel ' + sSeason, SITE_IDENTIFIER, 'showEpisodes')
                                oGuiElement.setTVShowTitle(sName)
                                oGuiElement.setSeason(sSeason)
                                oGuiElement.setMediaType('season')
                                oGuiElement.setThumbnail(sThumbnail)
                                if isDesc:
                                    oGuiElement.setDescription(sDesc)
                                params.setParam('sImdb', sImdb)
                                params.setParam('sMcSerialUrl', sMcSerialUrl)
                                params.setParam('sMcSeasonUrl', '')
                                cGui().addFolder(oGuiElement, params, True, total)
                            cGui().setView('seasons')
                            cGui().setEndOfDirectory()
                            return

                    # Keine Staffeln erkannt → eine Staffel, direkt Episoden
                    oGuiElement = cGuiElement('Staffel 1', SITE_IDENTIFIER, 'showEpisodes')
                    oGuiElement.setTVShowTitle(sName)
                    oGuiElement.setSeason('1')
                    oGuiElement.setMediaType('season')
                    oGuiElement.setThumbnail(sThumbnail)
                    if isDesc:
                        oGuiElement.setDescription(sDesc)
                    params.setParam('sImdb', sImdb)
                    params.setParam('sMcSerialUrl', sMcSerialUrl)
                    params.setParam('sMcSeasonUrl', '')
                    cGui().addFolder(oGuiElement, params, True, 1)
                    cGui().setView('seasons')
                    cGui().setEndOfDirectory()
                    return
            except Exception as e:
                logger.info('[fhdfilme] showSeasons Fehler: %s' % str(e))

    # Fallback: Accordion
    pattern = 'class="su-accordion collapse show"(.*?)<br>'
    isMatch, sHtmlContainer = cParser.parseSingleResult(sHtmlContent, pattern)
    if isMatch:
        isMatch, aResult = cParser.parse(sHtmlContainer, '#se-ac-(\d+)')
        if not aResult:
            isMatch = False
    if isMatch:
        total = len(aResult)
        for sSeason in aResult:
            oGuiElement = cGuiElement('Staffel ' + str(sSeason), SITE_IDENTIFIER, 'showEpisodes')
            oGuiElement.setTVShowTitle(sName)
            oGuiElement.setSeason(sSeason)
            oGuiElement.setMediaType('season')
            oGuiElement.setThumbnail(sThumbnail)
            if isDesc:
                oGuiElement.setDescription(sDesc)
            params.setParam('sMcSeasonUrl', '')
            params.setParam('sMcSerialUrl', '')
            cGui().addFolder(oGuiElement, params, True, total)
    if not isMatch:
        cGui().showInfo()
        return
    cGui().setView('seasons')
    cGui().setEndOfDirectory()


def showEpisodes():
    """
    Episoden einer Staffel aus der Meinecloud-Hauptseite.
    Das genaue Filterkriterium (data-season, URL-Segment) hängt vom HTML ab.
    """
    params = ParameterHandler()
    sUrl = params.getValue('entryUrl')
    sThumbnail = params.getValue('sThumbnail')
    sSeason = params.getValue('season')
    sShowName = params.getValue('TVShowTitle') or params.getValue('sName')
    sImdb = params.getValue('sImdb')
    sMcSerialUrl = params.getValue('sMcSerialUrl')

    if sMcSerialUrl:
        try:
            oMcReq = cRequestHandler(sMcSerialUrl, caching=False)
            oMcReq.addHeaderEntry('Referer', URL_MAIN + '/')
            sMcHtml = oMcReq.request()
            if sMcHtml:
                sSerialId = sMcSerialUrl.rstrip('/').split('/')[-1]

                # Versuch 1: data-link mit data-season Filter
                # z.B. <a data-season="1" data-link="http://..." href="/serial/id/ep">Folge 1</a>
                pattern = r'data-season=["\']?' + sSeason + r'["\']?[^>]*data-link=["\']([^"\']+)["\']'
                isMatch, aLinks = cParser.parse(sMcHtml, pattern)

                # Versuch 2: Umgekehrte Attributreihenfolge
                if not isMatch or not aLinks:
                    pattern = r'data-link=["\']([^"\']+)["\'][^>]*data-season=["\']?' + sSeason + r'["\']?'
                    isMatch, aLinks = cParser.parse(sMcHtml, pattern)

                # Versuch 3: href=/serial/{id}/{s}/{e} dreiteilig
                if not isMatch or not aLinks:
                    pattern = r'href=["\']?/serial/' + sSerialId + '/' + sSeason + r'/(\d+)["\']?'
                    isEpMatch, aEpNums = cParser.parse(sMcHtml, pattern)
                    if isEpMatch and aEpNums:
                        seen = set()
                        aUnique = []
                        for ep in aEpNums:
                            if ep not in seen:
                                seen.add(ep)
                                aUnique.append(ep)
                        aUnique.sort(key=lambda x: int(x))
                        total = len(aUnique)
                        for sEpisode in aUnique:
                            sMcEpUrl = '%s/%s/%s' % (sMcSerialUrl, sSeason, sEpisode)
                            oGuiElement = cGuiElement('Folge ' + sEpisode, SITE_IDENTIFIER, 'showHosters')
                            oGuiElement.setThumbnail(sThumbnail)
                            oGuiElement.setTVShowTitle(sShowName)
                            oGuiElement.setSeason(sSeason)
                            oGuiElement.setEpisode(sEpisode)
                            oGuiElement.setMediaType('episode')
                            params.setParam('sImdb', sImdb)
                            params.setParam('sMcSerialUrl', sMcSerialUrl)
                            params.setParam('sMcPlayerUrl', sMcEpUrl)
                            params.setParam('entryUrl', sUrl)
                            params.setParam('season', sSeason)
                            params.setParam('episode', sEpisode)
                            cGui().addFolder(oGuiElement, params, False, total)
                        cGui().setView('episodes')
                        cGui().setEndOfDirectory()
                        return

                # Versuch 4: Alle data-links (eine Staffel → alle sind diese Staffel)
                if not isMatch or not aLinks:
                    pattern = r'data-link=["\']([^"\']+)["\']'
                    isMatch, aLinks = cParser.parse(sMcHtml, pattern)

                if isMatch and aLinks:
                    seen = set()
                    aUnique = []
                    for lnk in aLinks:
                        if lnk not in seen:
                            seen.add(lnk)
                            aUnique.append(lnk)
                    total = len(aUnique)
                    for i, sLink in enumerate(aUnique, 1):
                        if sLink.startswith('//'):
                            sLink = 'https:' + sLink
                        sEpisode = str(i)
                        oGuiElement = cGuiElement('Folge ' + sEpisode, SITE_IDENTIFIER, 'showHosters')
                        oGuiElement.setThumbnail(sThumbnail)
                        oGuiElement.setTVShowTitle(sShowName)
                        oGuiElement.setSeason(sSeason)
                        oGuiElement.setEpisode(sEpisode)
                        oGuiElement.setMediaType('episode')
                        params.setParam('sImdb', sImdb)
                        params.setParam('sMcSerialUrl', sMcSerialUrl)
                        params.setParam('sMcPlayerUrl', sLink)  # direkt der Link
                        params.setParam('entryUrl', sUrl)
                        params.setParam('season', sSeason)
                        params.setParam('episode', sEpisode)
                        cGui().addFolder(oGuiElement, params, False, total)
                    cGui().setView('episodes')
                    cGui().setEndOfDirectory()
                    return
        except Exception as e:
            logger.info('[fhdfilme] showEpisodes Fehler: %s' % str(e))

    # Fallback: Accordion
    oRequest = cRequestHandler(sUrl)
    if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'true':
        oRequest.cacheTime = 60 * 60 * 4
    sHtmlContent = oRequest.request()
    pattern = '#se-ac-%s(.*?)</div></div>' % sSeason
    isMatch, sHtmlContainer = cParser.parseSingleResult(sHtmlContent, pattern)
    if isMatch:
        isMatch, aResult = cParser.parse(sHtmlContainer, 'Episode\s(\d+)')
        if not aResult:
            isMatch = False
    if isMatch:
        total = len(aResult)
        for sEpisode in aResult:
            oGuiElement = cGuiElement('Folge ' + str(sEpisode), SITE_IDENTIFIER, 'showHosters')
            oGuiElement.setThumbnail(sThumbnail)
            oGuiElement.setTVShowTitle(sShowName)
            oGuiElement.setSeason(sSeason)
            oGuiElement.setEpisode(sEpisode)
            oGuiElement.setMediaType('episode')
            params.setParam('entryUrl', sUrl)
            params.setParam('season', sSeason)
            params.setParam('episode', sEpisode)
            params.setParam('sMcPlayerUrl', '')
            cGui().addFolder(oGuiElement, params, False, total)
    if not isMatch:
        cGui().showInfo()
        return
    cGui().setView('episodes')
    cGui().setEndOfDirectory()


def showHosters():
    """
    Hoster für Film oder Episode.
    
    Episoden: sMcPlayerUrl ist bereits der direkte Hoster-Link
    (z.B. https://dr0pstream.com/e/xyz) - direkt weitergeben.
    
    Filme: Meinecloud-Hauptseite → data-link scrapen.
    Fallback: Seiten-iframe → data-link.
    """
    hosters = []
    params = ParameterHandler()
    sUrl = params.getValue('entryUrl')
    sImdb = params.getValue('sImdb')
    sMcPlayerUrl = params.getValue('sMcPlayerUrl')

    # --- 1. Episode: sMcPlayerUrl ist der direkte Hoster-Link ---
    if sMcPlayerUrl and sMcPlayerUrl.startswith('http'):
        sName = cParser.urlparse(sMcPlayerUrl).split('.')[0].strip()
        if not cConfig().isBlockedHoster(sName)[0]:
            logger.info('[fhdfilme] %s' % sMcPlayerUrl)
            hosters.append({
                'link': sMcPlayerUrl,
                'name': sName,
                'displayedName': '%s [I][720p][/I]' % sName,
                'quality': '720'
            })
            hosters.append('getHosterUrl')
            return hosters

    # --- 2. Film: Meinecloud-Hauptseite → data-link ---
    sHtmlContent = cRequestHandler(sUrl, caching=False).request()
    if not sImdb:
        isImdb, sImdb = cParser.parseSingleResult(sHtmlContent, "var imdb\s*=\s*'(tt\d+)'")
        if not isImdb:
            sImdb = ''

    if sImdb:
        sMcUrl = _getMcSerialUrl(sImdb)
        if sMcUrl:
            try:
                oMcReq = cRequestHandler(sMcUrl, caching=False)
                oMcReq.addHeaderEntry('Referer', URL_MAIN + '/')
                sMcHtml = oMcReq.request()
                if sMcHtml:
                    isQuality, sQuality = cParser.parseSingleResult(sMcHtml, '(\d{3,4})p')
                    if not isQuality:
                        sQuality = '720'
                    isMatch, aLinks = cParser.parse(sMcHtml, 'data-link=["\']([^"\']+)["\']')
                    if isMatch and aLinks:
                        seen = set()
                        for sLink in aLinks:
                            if sLink in seen or 'youtube' in sLink:
                                continue
                            seen.add(sLink)
                            if sLink.startswith('//'):
                                sLink = 'https:' + sLink
                            sName = cParser.urlparse(sLink).split('.')[0].strip()
                            if cConfig().isBlockedHoster(sName)[0]:
                                continue
                            logger.info('[fhdfilme] %s' % sLink)
                            hosters.append({
                                'link': sLink,
                                'name': sName,
                                'displayedName': '%s [I][%sp][/I]' % (sName, sQuality),
                                'quality': sQuality
                            })
                        if hosters:
                            hosters.append('getHosterUrl')
                            return hosters
            except Exception as e:
                logger.info('[fhdfilme] showHosters Film Fehler: %s' % str(e))

    # --- 3. Fallback: Seiten-iframe → data-link ---
    pattern = '<iframe\sw.*?src="([^"]+)'
    isMatch, hUrl = cParser.parseSingleResult(sHtmlContent, pattern)
    if isMatch:
        sHtmlContainer = cRequestHandler(hUrl).request()
        isMatch, aLinks = cParser.parse(sHtmlContainer, 'data-link=["\']([^"\']+)["\']')
        if isMatch:
            seen = set()
            for sLink in aLinks:
                if sLink in seen or 'youtube' in sLink:
                    continue
                seen.add(sLink)
                if sLink.startswith('//'):
                    sLink = 'https:' + sLink
                sName = cParser.urlparse(sLink).split('.')[0].strip()
                if cConfig().isBlockedHoster(sName)[0]:
                    continue
                hosters.append({
                    'link': sLink,
                    'name': sName,
                    'displayedName': '%s [I][720p][/I]' % sName,
                    'quality': '720'
                })
    if hosters:
        hosters.append('getHosterUrl')
    return hosters


def getHosterUrl(sUrl=False):
    return [{'streamUrl': sUrl, 'resolved': False}]


def showSearch():
    sSearchText = cGui().showKeyBoard(sHeading=cConfig().getLocalizedString(30281))
    if not sSearchText:
        return
    _search(False, sSearchText)
    cGui().setEndOfDirectory()


def _search(oGui, sSearchText):
    showEntries(URL_SEARCH % cParser.quotePlus(sSearchText), oGui, sSearchText)


def showSearchPage():
    params = ParameterHandler()
    sNextPage = params.getValue('sNextPage')
    sPageLast = params.getValue('sPageLast')
    sHeading = cConfig().getLocalizedString(30282) + str(sPageLast)
    sSearchPageText = cGui().showKeyBoard(sHeading=sHeading)
    if not sSearchPageText:
        return
    sNextSearchPage = sNextPage.split('page/')[0].strip() + 'page/' + sSearchPageText + '/'
    showEntries(sNextSearchPage)
    cGui().setEndOfDirectory()
