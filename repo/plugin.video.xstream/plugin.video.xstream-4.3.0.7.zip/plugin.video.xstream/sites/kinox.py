# -*- coding: utf-8 -*-
# Python 3
# Always pay attention to the translations in the menu!

from resources.lib.handler.ParameterHandler import ParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.tools import logger, cParser
from resources.lib.gui.guiElement import cGuiElement
from resources.lib.gui.gui import cGui
from resources.lib.config import cConfig
from urllib.error import HTTPError
from urllib.request import build_opener
from json import loads

SITE_IDENTIFIER = 'kinox'
SITE_NAME = 'KinoX'
SITE_ICON = 'kinox.png'
SITE_FANART = cConfig().getAddonInfo('path') + '/resources/art/sites/' + SITE_ICON

# Global search deaktivieren falls gewünscht
if cConfig().getSetting('global_search_' + SITE_IDENTIFIER) == 'false':
    SITE_GLOBAL_SEARCH = False
    logger.info('-> [SitePlugin]: globalSearch for %s is deactivated.' % SITE_NAME)

# Domain-Konfiguration
DOMAIN = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '.domain', 'kinoz.to')
STATUS = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '_status')
ACTIVE = cConfig().getSetting('plugin_' + SITE_IDENTIFIER)

URL_MAIN               = 'https://' + DOMAIN
URL_NEWS               = URL_MAIN + '/index.php'
URL_CINEMA_PAGE        = URL_MAIN + '/Kino-Filme.html'
URL_GENRE_PAGE         = URL_MAIN + '/Genre.html'
URL_MOVIE_PAGE         = URL_MAIN + '/Movies.html'
URL_SERIE_PAGE         = URL_MAIN + '/Series.html'
URL_DOCU_PAGE          = URL_MAIN + '/Documentations.html'
URL_FAVOURITE_MOVIE_PAGE = URL_MAIN + '/Popular-Movies.html'
URL_FAVOURITE_SERIE_PAGE = URL_MAIN + '/Popular-Series.html'
URL_FAVOURITE_DOCU_PAGE  = URL_MAIN + '/Popular-Documentations.html'
URL_LATEST_MOVIE_PAGE  = URL_MAIN + '/Latest-Movies.html'
URL_LATEST_SERIE_PAGE  = URL_MAIN + '/Latest-Series.html'
URL_LATEST_DOCU_PAGE   = URL_MAIN + '/Latest-Documentations.html'
URL_SEARCH             = URL_MAIN + '/Search.html?q=%s'
URL_MIRROR             = URL_MAIN + '/aGET/Mirror/'
URL_EPISODE_URL        = URL_MAIN + '/aGET/MirrorByEpisode/'
URL_AJAX               = URL_MAIN + '/aGET/List/'

# ISO-639-1 Sprachzuordnung
_LANGUAGE_MAP = {
    '1': 'DE', '2': 'EN', '4': 'ZA', '5': 'ES', '6': 'FR',
    '7': 'TR', '8': 'JA', '9': 'AR', '11': 'IT', '12': 'HR',
    '13': 'SR', '14': 'BS', '15': 'DE / EN', '16': 'NL',
    '17': 'KO', '24': 'EL', '25': 'RU', '26': 'HI',
}

SCRAPER_SETTINGS = '''
            <group id="plugin_kinox" label="30708">
                <setting id="plugin_kinox" type="boolean" label="30050" help="30411">
                    <level>0</level>
                    <default>True</default>
                    <control type="toggle"/>
                </setting>
                <setting id="global_search_kinox" type="boolean" label="30052">
                    <level>0</level>
                    <default>True</default>
                    <dependencies>
                        <dependency type="enable" operator="!is" setting="plugin_kinox">False</dependency>
                    </dependencies>
                    <control type="toggle"/>
                </setting>
                <setting id="plugin_kinox_checkDomain" type="boolean" label="30277">
                    <visible>false</visible>
                    <default>True</default>
                    <dependencies>
                        <dependency type="enable" operator="!is" setting="plugin_kinox">false</dependency>
                        <dependency type="visible" operator="!is" setting="plugin_kinox">false</dependency>
                    </dependencies>
                    <control type="toggle"/>
                </setting>
                <setting id="plugin_kinox.domain" type="string" label="30278" help="">
                    <level>0</level>
                    <default>kinoz.to</default>
                    <constraints>
                        <allowempty>true</allowempty>
                    </constraints>
                    <dependencies>
                        <dependency type="enable" operator="!is" setting="plugin_kinox">false</dependency>
                        <dependency type="visible" operator="!is" setting="plugin_kinox">false</dependency>
                    </dependencies>
                    <control type="edit" format="string">
                        <heading>30278</heading>
                    </control>
                </setting>
                <setting id="plugin_kinox_status" type="string" label="Dummy" help="">
                    <visible>false</visible>
                    <default>true</default>
                    <control type="toggle"/>
                </setting>
            </group>
'''


# ---------------------------------------------------------------------------
# Hilfsfunktionen (privat)
# ---------------------------------------------------------------------------

def __createLanguage(sLangID):
    """Gibt das ISO-639-1-Kürzel für eine Sprach-ID zurück."""
    return _LANGUAGE_MAP.get(str(sLangID), sLangID)


def __checkSubLanguage(sTitle):
    """Trennt Untertitel-Info aus dem Titel (z.B. '*german subbed*')."""
    if ' subbed*' not in sTitle:
        return [sTitle, '']
    parts = sTitle.split(' *')
    subLang = parts[-1].split('subbed*')[0].strip()
    title = ' '.join(parts[:-1]).strip()
    return [title, 'de'] if subLang == 'german' else [title, subLang]


def __getPreferredLanguage():
    """Baut den Cookie-String für die bevorzugte Sprache."""
    sLanguage = cConfig().getSetting('prefLanguage')
    if sLanguage == '1':   # Deutsch bevorzugt
        return 'ListNeededLanguage=25%2C24%2C26%2C2%2C5%2C6%2C7%2C8%2C11%2C15%2C16%2C9%2C12%2C13%2C14%2C17%2C4'
    elif sLanguage == '2': # Englisch bevorzugt
        return 'ListNeededLanguage=25%2C24%2C26%2C5%2C6%2C7%2C8%2C11%2C15%2C16%2C9%2C12%2C13%2C14%2C17%2C4%2C1'
    return ''


def __getHtmlContent(sUrl=None, ignoreErrors=False):
    """Lädt HTML-Inhalt einer URL mit den korrekten Cookies und Headern."""
    parms = ParameterHandler()
    if sUrl is None:
        if not parms.exist('sUrl'):
            logger.error('There is no url we can request.')
            return False
        sUrl = parms.getValue('sUrl')
    sPrefLang = __getPreferredLanguage()
    oRequest = cRequestHandler(sUrl, ignoreErrors=ignoreErrors)
    oRequest.addHeaderEntry('Cookie', sPrefLang + 'ListDisplayYears=Always;')
    oRequest.addHeaderEntry('Referer', URL_MAIN)
    return oRequest.request()


def __createDisplayStart(iPage):
    """Berechnet den Paginierungs-Offset (30 Einträge pro Seite)."""
    return (30 * int(iPage)) - 30


def __createMenuEntry(oGui, sFunction, sLabel, dOutputParameter):
    """Fügt einen Menüeintrag mit den gegebenen Parametern hinzu."""
    parms = ParameterHandler()
    try:
        for param, value in dOutputParameter.items():
            parms.setParam(param, value)
    except Exception as e:
        logger.error("Can't add parameter to menu entry '%s': %s" % (sLabel, e))
    oGuiElement = cGuiElement()
    oGuiElement.setSiteName(SITE_IDENTIFIER)
    oGuiElement.setFunction(sFunction)
    oGuiElement.setTitle(sLabel)
    oGui.addFolder(oGuiElement, parms)


def __isSerie(sHtmlContent):
    """Prüft anhand des SeasonSelection-Elements ob es sich um eine Serie handelt."""
    aResult = cParser.parse(sHtmlContent, 'id="SeasonSelection" rel="([^"]+)"')
    return aResult[0] is True


def __createMovieTitle(sHtmlContent):
    """Extrahiert den Titel aus der Detailseite."""
    aResult = cParser.parse(sHtmlContent, '<h1><span style="display: inline-block">(.*?)</h1>')
    if aResult[0]:
        return str(aResult[1][0])
    return False


def __getTmdbPoster(sTitle, sYear='', sMediaType='movie'):
    """
    Sucht auf TMDb nach einem hochauflösenden Poster (bis zu 1000x1500px).
    Benötigt einen kostenlosen API-Key von https://www.themoviedb.org/settings/api

    Gibt die Poster-URL zurück oder None wenn kein Ergebnis / kein API-Key.
    Poster-Größen: w92, w154, w185, w342, w500, w780, original
    """
    try:
        sTmdbKey = '86dd18b04874d9c94afadde7993d94e3'

        # Titel bereinigen: Jahreszahl und Sonderzeichen entfernen
        import re
        sCleanTitle = re.sub(r'\s*\(\d{4}\)', '', sTitle).strip()
        sCleanTitle = re.sub(r'\s*\*[^*]+\*', '', sCleanTitle).strip()  # subbed-Tags entfernen

        # Suchtyp bestimmen
        sType = 'tv' if sMediaType == 'series' else 'movie'

        # TMDb Suche
        from urllib.parse import quote_plus
        sSearchUrl = (
            'https://api.themoviedb.org/3/search/%s'
            '?api_key=%s&query=%s&language=de-DE'
            % (sType, sTmdbKey, quote_plus(sCleanTitle))
        )
        if sYear:
            sSearchUrl += '&year=' + str(sYear)

        oRequest = cRequestHandler(sSearchUrl, ignoreErrors=True)
        sResponse = oRequest.request()
        if not sResponse:
            return None

        oData = loads(sResponse)
        aResults = oData.get('results', [])
        if not aResults:
            return None

        # Erstes Ergebnis nehmen, Poster in w500 (500px breit, ~750px hoch)
        sPosterPath = aResults[0].get('poster_path', '')
        if not sPosterPath:
            return None

        return 'https://image.tmdb.org/t/p/w500' + sPosterPath

    except Exception as e:
        logger.error('TMDb Poster-Abfrage fehlgeschlagen für "%s": %s' % (sTitle, e))
        return None


def __displayItems(sGui, sHtmlContent):
    """Zeigt Suchergebnisse und News-Items als Ordner an."""
    oGui = sGui if sGui else cGui()
    parms = ParameterHandler()
    # Suche nach Sprache, Typ, URL, Titel und Jahr im HTML
    pattern = (
        r'<td class="Icon"><img width="16" height="11" src="/gr/sys/lng/(\d+)\.png" alt="language"></td>'
        r'.*?title="([^"]+)".*?<td class="Title">.*?<a href="([^"]+)" onclick="return false;">([^<]+)</a>'
        r' <span class="Year">([0-9]+)</span>'
    )
    aResult = cParser.parse(sHtmlContent, pattern)
    if not aResult[0]:
        logger.error('Could not find any items in displayItems')
        return
    total = len(aResult[1])
    for aEntry in aResult[1]:
        sTitle, subLang = __checkSubLanguage(aEntry[3])
        sLang = __createLanguage(aEntry[0])
        sUrl = URL_MAIN + aEntry[2]
        mediaType = aEntry[1]
        if mediaType in ('movie', 'cinema'):
            mediaType = 'movie'
        elif mediaType == 'series':
            mediaType = 'series'
        else:
            mediaType = 'documentation'
        oGuiElement = cGuiElement(sTitle, SITE_IDENTIFIER, 'parseMovieEntrySite')
        oGuiElement.setLanguage(sLang)
        oGuiElement.setSubLanguage(subLang)
        oGuiElement.setYear(aEntry[4])
        # TMDb Poster holen falls API-Key vorhanden
        sTmdbPoster = __getTmdbPoster(sTitle, aEntry[4], mediaType)
        if sTmdbPoster:
            oGuiElement.setThumbnail(sTmdbPoster)
        parms.setParam('sUrl', sUrl)
        parms.setParam('mediaType', mediaType)
        if mediaType == 'series':
            oGuiElement.setMediaType('tvshow')
            oGui.addFolder(oGuiElement, parms, total)
        elif mediaType == 'movie':
            oGuiElement.setMediaType('movie')
            oGui.addFolder(oGuiElement, parms, False, total)
        else:
            oGui.addFolder(oGuiElement, parms, False, total)


def __getAjaxContent(sMediaType, iPage, iMediaTypePageId, metaOn, sCharacter=''):
    """Baut die AJAX-Anfrage für paginierte Listen auf und gibt den Inhalt zurück."""
    import json
    iDisplayStart = __createDisplayStart(iPage)
    sPrefLang = __getPreferredLanguage()
    oRequest = cRequestHandler(URL_AJAX)
    if not iMediaTypePageId:
        additional = json.dumps({"fType": str(sMediaType), "Length": 60, "fLetter": str(sCharacter)})
    else:
        additional = json.dumps({"foo": "bar", str(sMediaType): iMediaTypePageId, "fType": "movie", "fLetter": str(sCharacter)})
    oRequest.addParameters('additional', additional)
    oRequest.addParameters('iDisplayLength', '30')
    oRequest.addParameters('iDisplayStart', iDisplayStart)
    if metaOn and sMediaType != 'documentation':
        oRequest.addParameters('bSortable_0', 'true')
        oRequest.addParameters('bSortable_1', 'true')
        oRequest.addParameters('bSortable_2', 'true')
        oRequest.addParameters('bSortable_3', 'false')
        oRequest.addParameters('bSortable_4', 'false')
        oRequest.addParameters('bSortable_5', 'false')
        oRequest.addParameters('bSortable_6', 'true')
        oRequest.addParameters('iColumns', '7')
        oRequest.addParameters('iSortCol_0', '2')
        oRequest.addParameters('iSortingCols', '1')
        oRequest.addParameters('sColumns', '')
        oRequest.addParameters('sEcho', iPage)
        oRequest.addParameters('sSortDir_0', 'asc')
    else:
        oRequest.addParameters('ListMode', 'cover')
        oRequest.addParameters('Page', str(iPage))
        oRequest.addParameters('Per_Page', '30')
        oRequest.addParameters('per_page', '30')
        oRequest.addParameters('dir', 'desc')
        oRequest.addParameters('sort', 'title')
    sUrl = oRequest.getRequestUri()
    oRequest = cRequestHandler(sUrl)
    oRequest.addHeaderEntry('Cookie', sPrefLang + 'ListDisplayYears=Always;')
    return oRequest.request()


# ---------------------------------------------------------------------------
# Öffentliche Plugin-Funktionen
# ---------------------------------------------------------------------------

def load():
    """Hauptmenü des Plugins aufbauen."""
    logger.info('Load %s' % SITE_NAME)
    parms = ParameterHandler()
    oGui = cGui()
    parms.setParam('sUrl', URL_NEWS)
    parms.setParam('page', 1)
    parms.setParam('mediaType', 'news')
    oGui.addFolder(cGuiElement(cConfig().getLocalizedString(30500), SITE_IDENTIFIER, 'showNews'), parms)       # Neu
    parms.setParam('sUrl', URL_MOVIE_PAGE)
    parms.setParam('mediaType', 'movie')
    oGui.addFolder(cGuiElement(cConfig().getLocalizedString(30502), SITE_IDENTIFIER, 'showMovieMenu'), parms)  # Filme
    parms.setParam('sUrl', URL_SERIE_PAGE)
    parms.setParam('mediaType', 'series')
    oGui.addFolder(cGuiElement(cConfig().getLocalizedString(30511), SITE_IDENTIFIER, 'showSeriesMenu'), parms) # Serien
    parms.setParam('sUrl', URL_DOCU_PAGE)
    parms.setParam('mediaType', 'documentation')
    oGui.addFolder(cGuiElement(cConfig().getLocalizedString(30505), SITE_IDENTIFIER, 'showDocuMenu'), parms)   # Dokus
    parms.setParam('sUrl', URL_SEARCH)
    parms.setParam('mediaType', '')
    oGui.addFolder(cGuiElement(cConfig().getLocalizedString(30520), SITE_IDENTIFIER, 'showSearch'), parms)     # Suche
    oGui.setEndOfDirectory()


def showMovieMenu():
    oGui = cGui()
    parms = ParameterHandler()
    oGui.addFolder(cGuiElement(cConfig().getLocalizedString(30501), SITE_IDENTIFIER, 'showCinemaMovies'), parms) # Kinofilme
    oGui.addFolder(cGuiElement(cConfig().getLocalizedString(30517), SITE_IDENTIFIER, 'showCharacters'), parms)   # A-Z
    oGui.addFolder(cGuiElement(cConfig().getLocalizedString(30506), SITE_IDENTIFIER, 'showGenres'), parms)       # Genre
    parms.setParam('sUrl', URL_FAVOURITE_MOVIE_PAGE)
    oGui.addFolder(cGuiElement(cConfig().getLocalizedString(30521), SITE_IDENTIFIER, 'showFavItems'), parms)     # Beliebt
    parms.setParam('sUrl', URL_LATEST_MOVIE_PAGE)
    oGui.addFolder(cGuiElement(cConfig().getLocalizedString(30541), SITE_IDENTIFIER, 'showFavItems'), parms)     # Neu
    oGui.setEndOfDirectory()


def showSeriesMenu():
    oGui = cGui()
    parms = ParameterHandler()
    oGui.addFolder(cGuiElement(cConfig().getLocalizedString(30517), SITE_IDENTIFIER, 'showCharacters'), parms)  # A-Z
    parms.setParam('sUrl', URL_FAVOURITE_SERIE_PAGE)
    oGui.addFolder(cGuiElement(cConfig().getLocalizedString(30519), SITE_IDENTIFIER, 'showFavItems'), parms)    # Beliebt
    parms.setParam('sUrl', URL_LATEST_SERIE_PAGE)
    oGui.addFolder(cGuiElement(cConfig().getLocalizedString(30514), SITE_IDENTIFIER, 'showFavItems'), parms)    # Neu
    oGui.setEndOfDirectory()


def showDocuMenu():
    oGui = cGui()
    parms = ParameterHandler()
    oGui.addFolder(cGuiElement(cConfig().getLocalizedString(30517), SITE_IDENTIFIER, 'showCharacters'), parms)  # A-Z
    parms.setParam('sUrl', URL_FAVOURITE_DOCU_PAGE)
    oGui.addFolder(cGuiElement(cConfig().getLocalizedString(30522), SITE_IDENTIFIER, 'showFavItems'), parms)    # Beliebt
    parms.setParam('sUrl', URL_LATEST_DOCU_PAGE)
    oGui.addFolder(cGuiElement(cConfig().getLocalizedString(30523), SITE_IDENTIFIER, 'showFavItems'), parms)    # Neu
    oGui.setEndOfDirectory()


def showFavItems():
    oGui = cGui()
    sHtmlContent = __getHtmlContent()
    __displayItems(oGui, sHtmlContent)
    oGui.setEndOfDirectory()


def __normalizeHtml(sHtml):
    """
    Entfernt Zeilenumbrüche und normalisiert Whitespace im HTML.
    Notwendig weil cParser.parse() intern kein re.DOTALL verwendet —
    .*? würde sonst an Zeilenumbrüchen stoppen.
    """
    import re
    return re.sub(r'\s+', ' ', sHtml)


def showNews():
    """
    Zeigt die News-Kategorien (Kinofilme, neue Filme, Serien, Dokus) als Ordner.

    FIX 1: Cache wird explizit umgangen (caching=False), da der xStream-Cache
            veraltetes oder anders strukturiertes HTML liefern kann.
    FIX 2: HTML wird normalisiert (Zeilenumbrüche entfernt), da cParser.parse()
            kein re.DOTALL unterstützt und .*? sonst an Newlines stoppt.
    FIX 3: Direktes re.findall mit re.DOTALL als zuverlässige Alternative zu cParser.
    """
    import re
    parms = ParameterHandler()
    sUrl = parms.getValue('sUrl')

    # Cache explizit umgehen — der Cache kann veraltetes HTML enthalten
    oRequest = cRequestHandler(sUrl, caching=False)
    oRequest.addHeaderEntry('Cookie', __getPreferredLanguage() + 'ListDisplayYears=Always;')
    oRequest.addHeaderEntry('Referer', URL_MAIN)
    sHtmlContent = oRequest.request()

    if not sHtmlContent:
        logger.error('showNews: Kein HTML empfangen.')
        cGui().setEndOfDirectory()
        return

    # Mit re.DOTALL direkt parsen — umgeht cParser-Limitierung zuverlässig
    matches = re.findall(
        r'<div class="Opt leftOpt Headlne"><h1>([^<]+)</h1></div>.*?'
        r'<div class="Opt rightOpt Hint">\s*Insgesamt:\s*([^<]+)</div>',
        sHtmlContent, re.DOTALL
    )

    if not matches:
        logger.error('showNews: Keine Kategorien gefunden (auch nach re.DOTALL-Suche).')
        cGui().setEndOfDirectory()
        return

    oGui = cGui()
    for sNewsTitle, sCount in matches:
        sNewsTitle = sNewsTitle.strip()
        sCount = sCount.strip()
        # "Navigation" ist der linke Menüblock der Seite — sinnvoll umbenennen
        displayTitle = 'Frisch aus dem Kino' if sNewsTitle == 'Navigation' else sNewsTitle
        sTitle = '%s (%s)' % (displayTitle, sCount)
        oGuiElement = cGuiElement(sTitle, SITE_IDENTIFIER, 'parseNews')
        parms.addParams({'sUrl': URL_NEWS, 'page': 1, 'mediaType': 'news', 'sNewsTitle': sNewsTitle})
        oGui.addFolder(oGuiElement, parms)
    oGui.setEndOfDirectory()


def parseNews():
    """
    Liest die Einträge einer News-Kategorie.

    Zwei verschiedene HTML-Strukturen auf der Seite:
    - "Frisches aus dem Kino": Cover-Karussell (div.image > a)
    - Alle anderen (Filme, Serien, Dokus): Tabelle mit tr > td.Icon + td.Title

    Echte HTML-Struktur der Tabelle:
      <td class="Icon"><img src="/gr/sys/lng/1.png" ...></td>
      <td class="Title img_preview" rel="/statics/thumbs/....jpg">
        <a href="/Stream/Titel.html" title="Titel" class="OverlayLabel">
          Titel
        </a>
      </td>

    Für Serien (ganze Staffel):
      <span href="/Stream/..." title="..." class="OverlayLabel">
        Titel : <span class="EpisodeDescr">Staffel X</span>
      </span>

    Für einzelne Episoden:
      <a href="/Stream/...,s1e1" ...>Titel : <span class="EpisodeDescr">Staffel 1 Episode 1</span></a>
    """
    import re
    oGui = cGui()
    parms = ParameterHandler()
    sUrl = parms.getValue('sUrl')
    sNewsTitle = parms.getValue('sNewsTitle')

    # Medientyp aus dem Kategorie-Titel ableiten
    if 'Serien' in sNewsTitle and 'Filme' not in sNewsTitle:
        mediaType = 'series'
    elif 'Doku' in sNewsTitle or 'Dokumentation' in sNewsTitle:
        mediaType = 'documentation'
    else:
        mediaType = 'movie'

    # Cache explizit umgehen
    oRequest = cRequestHandler(sUrl, caching=False)
    oRequest.addHeaderEntry('Cookie', __getPreferredLanguage() + 'ListDisplayYears=Always;')
    oRequest.addHeaderEntry('Referer', URL_MAIN)
    sHtmlContent = oRequest.request()

    if not sHtmlContent:
        logger.error("parseNews: Kein HTML empfangen.")
        oGui.setEndOfDirectory()
        return

    # Abschnitt der Kategorie extrahieren
    sNewsTitleEscaped = re.escape(sNewsTitle)
    match = re.search(
        r'<div class="Opt leftOpt Headlne"><h1>' + sNewsTitleEscaped + r'</h1></div>(.*?)<div class="ModuleFooter">',
        sHtmlContent, re.DOTALL
    )
    if not match:
        logger.info("parseNews: Kein Abschnitt für '%s' gefunden." % sNewsTitle)
        oGui.setEndOfDirectory()
        return

    sSection = match.group(1)
    entries = []

    # --- Struktur 1: Tabellen-Einträge (Neue Filme / Serien / Dokus) ---
    # Jede Zeile: <tr ...> mit td.Icon (Sprache) und td.Title (Thumbnail rel, href, Titel)
    rows = re.findall(
        r'<td class="Icon">\s*<img src="/gr/sys/lng/(\d+)\.png"[^>]*>.*?'
        r'<td class="Title[^"]*"\s+rel="([^"]*)">\s*'
        r'<(?:a|span)[^>]*href="([^"]+)"[^>]*>\s*([^<:]+)'   # Titel vor dem ':'
        r'(?:\s*:\s*<span class="EpisodeDescr">\s*([^<]*)</span>)?',  # optionale Staffel/Episode
        sSection, re.DOTALL
    )
    if rows:
        for langId, thumb, href, title, extra in rows:
            sTitle = title.strip()
            if extra:
                sTitle += ' ' + extra.strip()
            sTitle, subLang = __checkSubLanguage(sTitle)
            sEntryUrl = href.split(',')[0]
            entries.append({
                'lang': langId,
                'thumb': URL_MAIN + thumb if thumb.startswith('/') else thumb,
                'url': sEntryUrl,
                'title': sTitle,
                'subLang': subLang
            })

    # --- Struktur 2: Cover-Karussell (Frisches aus dem Kino) ---
    if not entries:
        covers = re.findall(
            r'<div class="image">\s*<a title="([^"]+)" href="([^"]+)">\s*<img src="([^"]+)"',
            sSection, re.DOTALL
        )
        for title, href, imgSrc in covers:
            sTitle, subLang = __checkSubLanguage(title.strip())
            sEntryUrl = href.split(',')[0]
            thumb = URL_MAIN + imgSrc if imgSrc.startswith('/') else imgSrc
            entries.append({
                'lang': '1',
                'thumb': thumb,
                'url': sEntryUrl,
                'title': sTitle,
                'subLang': subLang
            })

    if not entries:
        logger.info("parseNews: Keine Einträge im Abschnitt '%s'." % sNewsTitle)
        oGui.setEndOfDirectory()
        return

    logger.info("parseNews: %d Einträge gefunden für '%s'." % (len(entries), sNewsTitle))
    total = len(entries)
    for entry in entries:
        sLang = __createLanguage(entry['lang'])
        oGuiElement = cGuiElement(entry['title'], SITE_IDENTIFIER, 'parseMovieEntrySite')
        oGuiElement.setLanguage(sLang)
        oGuiElement.setSubLanguage(entry['subLang'])
        # TMDb Poster bevorzugen, KinoX-Thumbnail als Fallback
        sTmdbPoster = __getTmdbPoster(entry['title'], '', mediaType)
        oGuiElement.setThumbnail(sTmdbPoster if sTmdbPoster else entry['thumb'])
        parms.setParam('sUrl', URL_MAIN + entry['url'])
        parms.setParam('mediaType', mediaType)
        if mediaType == 'series':
            oGuiElement.setMediaType('tvshow')
            oGui.addFolder(oGuiElement, parms, total)
        else:
            oGuiElement.setMediaType('movie')
            oGui.addFolder(oGuiElement, parms, False, total)

    oGui.setView('tvshows' if mediaType == 'series' else 'movies')
    oGui.setEndOfDirectory()


def showCharacters():
    """
    Zeigt A-Z-Navigation für Filme/Serien/Dokus.

    FIX: aResult wurde außerhalb des if-Blocks geprüft → möglicher NameError.
    Jetzt korrekte Initialisierung und Prüfung innerhalb des Blocks.
    """
    oGui = cGui()
    parms = ParameterHandler()
    if not (parms.exist('sUrl') and parms.exist('page') and parms.exist('mediaType')):
        logger.error('showCharacters: Fehlende Parameter.')
        oGui.setEndOfDirectory()
        return
    siteUrl = parms.getValue('sUrl')
    sHtmlContent = __getHtmlContent(siteUrl)
    aResult = cParser.parse(sHtmlContent, r'class="LetterMode.*?>([^>]+)</a>')
    if aResult[0]:
        for aEntry in aResult[1]:
            oGuiElement = cGuiElement(aEntry, SITE_IDENTIFIER, 'ajaxCall')
            parms.setParam('character', aEntry[0])
            if parms.exist('mediaTypePageId'):
                parms.setParam('mediaTypePageId', parms.getValue('mediaTypePageId'))
            oGui.addFolder(oGuiElement, parms)
    oGui.setEndOfDirectory()


def showGenres():
    logger.info('load displayGenreSite')
    sHtmlContent = __getHtmlContent(URL_GENRE_PAGE)
    aResult = cParser.parse(sHtmlContent, r'<td class="Title"><a.*?href="/Genre/([^"]+)">([^<]+)</a>.*?Tipp-([0-9]+)\.html">')
    oGui = cGui()
    if aResult[0]:
        for aEntry in aResult[1]:
            __createMenuEntry(oGui, 'showCharacters', aEntry[1], {
                'page': 1, 'mediaType': 'fGenre',
                'mediaTypePageId': aEntry[2], 'sUrl': URL_MOVIE_PAGE
            })
    oGui.setEndOfDirectory()


def showCinemaMovies():
    logger.info('load displayCinemaSite')
    oGui = cGui()
    _cinema(oGui)
    oGui.setView('movies')
    oGui.setEndOfDirectory()


def _cinema(oGui):
    pattern = (
        r'<div class="Opt leftOpt Headlne"><a title="(.*?)" href="(.*?)">.*?src="(.*?)"'
        r'.*?class="Descriptor">(.*?)</div.*?/lng/([0-9]+)\.png".*?IMDb:</b> (.*?) /'
    )
    parms = ParameterHandler()
    sHtmlContent = __getHtmlContent(URL_CINEMA_PAGE)
    aResult = cParser.parse(sHtmlContent, pattern)
    if not aResult[0]:
        return
    total = len(aResult[1])
    for aEntry in aResult[1]:
        oGuiElement = cGuiElement()
        oGuiElement.setSiteName(SITE_IDENTIFIER)
        oGuiElement.setFunction('parseMovieEntrySite')
        oGuiElement.setTitle(aEntry[0])
        oGuiElement.setLanguage(__createLanguage(aEntry[4]))
        oGuiElement.setDescription(aEntry[3])
        oGuiElement.setMediaType('movie')
        # TMDb Poster bevorzugen, KinoX-Thumbnail als Fallback
        sTmdbPoster = __getTmdbPoster(aEntry[0], '', 'movie')
        oGuiElement.setThumbnail(sTmdbPoster if sTmdbPoster else URL_MAIN + str(aEntry[2]))
        oGuiElement.addItemValue('rating', aEntry[5])
        parms.setParam('sUrl', URL_MAIN + str(aEntry[1]))
        oGui.addFolder(oGuiElement, parms, False, total)


def parseMovieEntrySite():
    parms = ParameterHandler()
    if not parms.exist('sUrl'):
        return
    sUrl = parms.getValue('sUrl')
    sHtmlContent = __getHtmlContent(sUrl)
    sMovieTitle = __createMovieTitle(sHtmlContent)
    result = cParser.parse(sHtmlContent, r'<div class="Grahpics">.*?<img src="([^"]+)"')
    thumbnail = URL_MAIN + str(result[1][0]) if result[0] else False
    if __isSerie(sHtmlContent):
        oGui = cGui()
        aSeriesItems = parseSerieSite(sHtmlContent)
        if not aSeriesItems[0]:
            return
        total = len(aSeriesItems[1])
        for aEntry in aSeriesItems[1]:
            seasonNum = str(aEntry)
            guiElement = cGuiElement('%s - Staffel %s' % (sMovieTitle, seasonNum), SITE_IDENTIFIER, 'showEpisodes')
            guiElement.setMediaType('season')
            guiElement.setSeason(seasonNum)
            guiElement.setTVShowTitle(sMovieTitle)
            parms.setParam('Season', seasonNum)
            if thumbnail:
                guiElement.setThumbnail(thumbnail)
            oGui.addFolder(guiElement, parms, total)
        oGui.setView('seasons')
        oGui.setEndOfDirectory()
    else:
        logger.info('parseMovieEntrySite: Movie erkannt')
        return showHosters()


def showEpisodes():
    oGui = cGui()
    parms = ParameterHandler()
    sUrl = parms.getValue('sUrl')
    seasonNum = parms.getValue('Season')
    sHtmlContent = __getHtmlContent(sUrl)
    sMovieTitle = __createMovieTitle(sHtmlContent)
    result = cParser.parse(sHtmlContent, r'<div class="Grahpics">.*?<img src="([^"]+)"')
    thumbnail = URL_MAIN + str(result[1][0]) if result[0] else False
    aSeriesItems = parseSerieEpisodes(sHtmlContent, seasonNum)
    if not aSeriesItems:
        return
    sShowTitle = sMovieTitle.split('(')[0].split('*')[0].strip()
    for item in aSeriesItems:
        oGuiElement = cGuiElement(item['title'], SITE_IDENTIFIER, 'showHosters')
        oGuiElement.setThumbnail(thumbnail)
        oGuiElement.setMediaType('episode')
        oGuiElement.setSeason(item['season'])
        oGuiElement.setEpisode(item['episode'])
        oGuiElement.setTVShowTitle(sShowTitle)
        parms.addParams({'sUrl': item['url'], 'episode': item['episode'], 'season': item['season']})
        oGui.addFolder(oGuiElement, parms, False, len(aSeriesItems))
    oGui.setView('episodes')
    oGui.setEndOfDirectory()


def parseSerieSite(sHtmlContent):
    pattern = r'<option[^>]+value="(\d+)"[^>]+>Staffel.+?</option>'
    return cParser.parse(sHtmlContent, pattern)


def parseSerieEpisodes(sHtmlContent, seasonNum):
    """
    Gibt eine Liste von Episoden-Dicts für eine bestimmte Staffel zurück.

    FIX: sSeriesUrl wurde nur im if-Block gesetzt → möglicher UnboundLocalError.
    Jetzt sichere Initialisierung mit frühem Return.
    """
    aResult = cParser.parse(sHtmlContent, r'id="SeasonSelection" rel="([^"]+)"')
    if not aResult[0]:
        return []
    aSeriesUrls = aResult[1][0].split('&')
    sSeriesUrl = '&' + str(aSeriesUrls[0]) + '&' + str(aSeriesUrls[1])

    pattern = r'<option.*?value="%d" rel="([^"]+)".*?>Staffel.*?</option>' % int(seasonNum)
    aResult = cParser.parse(sHtmlContent, pattern)
    logger.info('parseSerieEpisodes: %s' % str(aResult[1]))
    if not aResult[0]:
        return []

    aSeriesItems = []
    for iEpisodeNum in aResult[1][0].split(','):
        iEpisodeNum = iEpisodeNum.strip()
        sUrl = URL_EPISODE_URL + sSeriesUrl + '&Season=' + str(seasonNum) + '&Episode=' + str(iEpisodeNum)
        aSeriesItems.append({
            'title': 'Folge ' + str(iEpisodeNum),
            'url': sUrl,
            'season': seasonNum,
            'episode': iEpisodeNum,
        })
    return aSeriesItems


def showHosters():
    """
    Liest verfügbare Hoster einer Filmseite aus.

    FIX: sUrl wurde bei fehlendem Parameter undefiniert verwendet.
    Jetzt Early-Return wenn kein sUrl vorhanden.
    """
    parms = ParameterHandler()
    if not parms.exist('sUrl'):
        logger.error('showHosters: Kein sUrl Parameter vorhanden.')
        return []
    sUrl = parms.getValue('sUrl')
    sHtmlContent = __getHtmlContent(sUrl)
    pattern = r'class="MirBtn.*?rel="([^"]+)".*?class="Named">([^<]+)</div>(.*?)</div>'
    aResult = cParser.parse(sHtmlContent, pattern)
    hosters = []
    if not aResult[0]:
        return hosters
    for aEntry in aResult[1]:
        sHoster = aEntry[1]
        if cConfig().isBlockedHoster(sHoster)[0]:
            continue  # Blockierte/deaktivierte Hoster überspringen
        mirrorResult = cParser.parse(aEntry[2], r'<b>Mirror</b>: [0-9]+/([0-9]+)')
        mirrors = int(mirrorResult[1][0]) if mirrorResult[0] else 1
        for i in range(1, mirrors + 1):
            mirrorUrl = URL_MIRROR + cParser.unquotePlus(aEntry[0])
            mirrorName = ''
            if mirrors > 1:
                mirrorName = ' Mirror %d' % i
                mirrorUrl = cParser.replace(r'Mirror=[0-9]+', 'Mirror=' + str(i), mirrorUrl)
            hosters.append({'name': sHoster, 'link': mirrorUrl, 'displayedName': sHoster + mirrorName})
    hosters.append('getHosterUrl')
    return hosters


def getHosterUrl(sUrl=False):
    """
    Löst die eigentliche Stream-URL eines Hosters auf.

    FIX 1: Erster redundanter Request entfernt (Ergebnis wurde sofort verworfen).
    FIX 2: KinoX liefert seit einem Update eine /redirect/-URL zurück.
           Diese wird jetzt per HTTP-Weiterleitung zur echten Hoster-URL aufgelöst.
           Danach wird die Hoster-Seite nach der eigentlichen Stream-URL durchsucht.
    """
    oRequest = cRequestHandler(sUrl, caching=False)
    oRequest.addHeaderEntry('Referer', URL_MAIN)
    sHtmlContent = oRequest.request()

    # FIX: KinoX gibt /redirect/... zurück -> dieser Weiterleitung folgen
    isRedirect, sRedirectPath = cParser.parseSingleResult(sHtmlContent, r'"(/redirect/[^"\\]+)')
    if not isRedirect:
        # Fallback: auch als direkten Text suchen
        isRedirect, sRedirectPath = cParser.parseSingleResult(sHtmlContent, r'(\/redirect\/[a-f0-9]+\?[^\s"\\]+)')
    if isRedirect:
        sRedirectUrl = URL_MAIN + sRedirectPath.rstrip('\\')
        logger.info('getHosterUrl: Folge redirect -> %s' % sRedirectUrl)
        sStreamUrl = _redirectHoster(sRedirectUrl)
        if sStreamUrl and sStreamUrl != sRedirectUrl:
            if sStreamUrl.startswith('//'):
                sStreamUrl = 'https:' + sStreamUrl
            return [{'streamUrl': sStreamUrl, 'resolved': False}]

    # Klassische Auflösung: direkte URL im HTML
    isMatch, sStreamUrl = cParser.parseSingleResult(sHtmlContent, r'a\shref=\\\\".*?(https?:.*?)\\\\"')
    if not isMatch:
        isMatch, sStreamUrl = cParser.parseSingleResult(sHtmlContent, r'<iframe src=[^"]*"([^"]+)')
    if not isMatch:
        # Letzter Versuch: jede https-URL im Response
        isMatch, sStreamUrl = cParser.parseSingleResult(sHtmlContent, r'(https?://[^\s"\'<>\\]+\.(?:mp4|m3u8|mkv)[^\s"\'<>\\]*)')
    if not isMatch:
        logger.error('getHosterUrl: Keine Stream-URL gefunden in: %s' % sHtmlContent[:300])
        return []

    if sStreamUrl.startswith('//'):
        sStreamUrl = 'https:' + sStreamUrl
    if 'streamcrypt.net' in sStreamUrl:
        oRequest = cRequestHandler(sStreamUrl, caching=False)
        oRequest.request()
        sStreamUrl = oRequest.getRealUrl()
    if 'thevideo' in sStreamUrl:
        sStreamUrl = sStreamUrl.replace('embed-', 'stream').replace('html', 'mp4')
        sStreamUrl = _redirectHoster(sStreamUrl)
        return [{'streamUrl': sStreamUrl, 'resolved': True}]
    return [{'streamUrl': sStreamUrl, 'resolved': False}]


def _redirectHoster(url):
    """
    Folgt HTTP-Weiterleitungen manuell und gibt die finale URL zurück.

    FIX 1: Python-2-Kompatibilitäts-Relikt (urllib2-Import) entfernt.
    FIX 2: Alle Exceptions abgefangen statt nur HTTPError, damit ein
           fehlgeschlagener Redirect nicht den ganzen Hoster-Aufruf abbricht.
    """
    opener = build_opener()
    opener.addheaders = [
        ('Referer', URL_MAIN),
        ('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36')
    ]
    try:
        resp = opener.open(url)
        final = resp.geturl()
        logger.info('_redirectHoster: %s -> %s' % (url, final))
        return final if final != url else url
    except HTTPError as e:
        if e.code in (301, 302, 303, 307, 308) or (e.code == 403 and url != e.geturl()):
            return e.geturl()
        logger.error('_redirectHoster HTTPError %d: %s' % (e.code, url))
        return url
    except Exception as e:
        logger.error('_redirectHoster Fehler: %s bei %s' % (str(e), url))
        return url


def ajaxCall():
    """Paginierte AJAX-Liste für Filme/Serien/Dokus."""
    oGui = cGui()
    metaOn = oGui.isMetaOn
    parms = ParameterHandler()
    if not (parms.exist('page') and parms.exist('mediaType')):
        logger.error('ajaxCall: Fehlende Parameter page oder mediaType.')
        return
    iPage = parms.getValue('page')
    sMediaType = parms.getValue('mediaType')
    iMediaTypePageId = parms.getValue('mediaTypePageId') if parms.exist('mediaTypePageId') else False
    sCharacter = parms.getValue('character') if parms.exist('character') else 'A'
    logger.info('ajaxCall: MediaType=%s, Page=%s, MediaTypePageId=%s, Character=%s'
                % (sMediaType, iPage, iMediaTypePageId, sCharacter))
    sHtmlContent = __getAjaxContent(sMediaType, iPage, iMediaTypePageId, metaOn, sCharacter)
    if not sHtmlContent:
        return

    if metaOn and sMediaType != 'documentation':
        aData = loads(sHtmlContent).get('aaData', [])
        total = len(aData)
        for aEntry in aData:
            aResult = cParser.parse(aEntry[2], r'<a href="([^"]+)".*?onclick="return false;">([^<]+)<.*?>([0-9]{4})<')
            if not aResult[0]:
                continue
            sUrl = URL_MAIN + str(aResult[1][0][0])
            sTitle = aResult[1][0][1]
            sYear = str(aResult[1][0][2]).strip()
            sLang = aEntry[0]
            oGuiElement = cGuiElement(sTitle, SITE_IDENTIFIER, 'parseMovieEntrySite')
            oGuiElement.setYear(sYear)
            oGuiElement.setLanguage(sLang)
            # TMDb Poster holen
            sTmdbPoster = __getTmdbPoster(sTitle, sYear, sMediaType)
            if sTmdbPoster:
                oGuiElement.setThumbnail(sTmdbPoster)
            parms.setParam('sUrl', sUrl)
            if sMediaType == 'series':
                oGuiElement.setMediaType('tvshow')
                oGui.addFolder(oGuiElement, parms, total)
            else:
                oGuiElement.setMediaType('movie')
                oGui.addFolder(oGuiElement, parms, False, total)
        # Paginierung
        iTotalCount = 0
        aResult = cParser.parse(sHtmlContent, r'"iTotalDisplayRecords":"([^"]+)')
        if aResult[0]:
            iTotalCount = int(aResult[1][0])
        iNextPage = int(iPage) + 1
        iCurrentDisplayStart = __createDisplayStart(iNextPage)
        if iCurrentDisplayStart < iTotalCount:
            parms = ParameterHandler()
            parms.setParam('page', iNextPage)
            parms.setParam('character', sCharacter)
            parms.setParam('mediaType', sMediaType)
            if iMediaTypePageId:
                parms.setParam('mediaTypePageId', iMediaTypePageId)
            oGui.addNextPage(SITE_IDENTIFIER, 'ajaxCall', parms)
    else:
        aData = loads(sHtmlContent)
        pattern = (
            r'<div class="Opt leftOpt Headlne"><a title="(.*?)" href="(.*?)">.*?src="(.*?)"'
            r'.*?class="Descriptor">(.*?)</div.*?lng/(.*?)\.png'
        )
        aResult = cParser.parse(aData.get('Content', ''), pattern)
        if aResult[0]:
            total = len(aResult[1])
            for aEntry in aResult[1]:
                sMovieTitle, subLang = __checkSubLanguage(aEntry[0])
                lang = __createLanguage(aEntry[4])
                oGuiElement = cGuiElement(sMovieTitle, SITE_IDENTIFIER, 'parseMovieEntrySite')
                oGuiElement.setDescription(aEntry[3])
                # TMDb Poster bevorzugen, KinoX-Thumbnail als Fallback
                sTmdbPoster = __getTmdbPoster(sMovieTitle, '', sMediaType)
                oGuiElement.setThumbnail(sTmdbPoster if sTmdbPoster else URL_MAIN + str(aEntry[2]))
                oGuiElement.setLanguage(lang)
                oGuiElement.setSubLanguage(subLang)
                parms.setParam('sUrl', URL_MAIN + str(aEntry[1]))
                if sMediaType == 'series':
                    oGui.addFolder(oGuiElement, parms, total)
                else:
                    oGui.addFolder(oGuiElement, parms, False, total)
            iTotalCount = int(aData.get('Total', 0))
            iNextPage = int(iPage) + 1
            if __createDisplayStart(iNextPage) < iTotalCount:
                parms = ParameterHandler()
                parms.setParam('page', iNextPage)
                if iMediaTypePageId:
                    parms.setParam('mediaTypePageId', iMediaTypePageId)
                oGui.addNextPage(SITE_IDENTIFIER, 'ajaxCall', parms)

    oGui.setView('tvshows' if sMediaType == 'series' else 'movies')
    oGui.setEndOfDirectory()


def showSearch():
    sSearchText = cGui().showKeyBoard(sHeading=cConfig().getLocalizedString(30281))
    if not sSearchText:
        return
    _search(False, sSearchText)
    cGui().setEndOfDirectory()


def _search(oGui, sSearchText):
    sHtmlContent = __getHtmlContent(URL_SEARCH % cParser.quotePlus(sSearchText), ignoreErrors=(oGui is not False))
    __displayItems(oGui, sHtmlContent)
